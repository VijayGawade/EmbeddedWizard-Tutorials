# Embedded Wizard Studio (EWS) - Step-by-Step HMI Development Guide
## Building an Industrial Multi-Tab & Multi-Page Touch Screen from Scratch

---

### Welcome!
If you have just built a simple "Hello World" app in Embedded Wizard Studio, congratulations! Transitioning from a single text label to a multi-screen, multi-tier industrial touch interface might look intimidating at first glance, but Embedded Wizard is built on very clean, logical principles.

This guide is designed as your **complete, self-contained mentor**. It explains **every single step** in detail, shows you **where to click in the Embedded Wizard IDE**, explains the **significance and philosophy** behind each design decision, and teaches you how all the pieces connect together.

By following this guide, you will be able to build and expand this application piece-by-piece on your own.

---

## Table of Contents
1. [Core Concepts: How Embedded Wizard Thinks](#1-core-concepts-how-embedded-wizard-thinks)
2. [Step 1: Project Setup & Screen Geometry](#step-1-project-setup--screen-geometry)
3. [Step 2: Font Resources & Typography](#step-2-font-resources--typography)
4. [Step 3: Creating Modular Page Components (`Core::Group`)](#step-3-creating-modular-page-components-coregroup)
5. [Step 4: Designing the Main Shell (`Application::Application`)](#step-4-designing-the-main-shell-applicationapplication)
6. [Step 5: Touch Interaction & Event Handling (`Core::SimpleTouchHandler`)](#step-5-touch-interaction--event-handling-coresimpletouchhandler)
7. [Step 6: State Management & The Layout Engine (Chora Code)](#step-6-state-management--the-layout-engine-chora-code)
8. [Step 7: Instantiating and Linking Everything](#step-7-instantiating-and-linking-everything)
9. [Step 8: Testing, Debugging & Prototyping (F5)](#step-8-testing-debugging--prototyping-f5)
10. [Troubleshooting & Common Beginner Gotchas](#troubleshooting--common-beginner-gotchas)

---

## 1. Core Concepts: How Embedded Wizard Thinks

Before touching the IDE, understand these four fundamental building blocks:

### 1.1 The "Brick" Concept
In Embedded Wizard, everything inside a unit is a **Brick** represented visually in the Composer window:
* **Classes (Components)**: Blueprints (like `Core::Group`, `Core::Root`).
* **Objects (Views)**: Live instances of classes (e.g., a `Views::Rectangle` or a `Views::Text`).
* **Resources**: Assets like Fonts (`Resources::Font`) and Bitmaps (`Resources::Bitmap`).
* **Members**: Variables (`var`), Methods (`method`), and Event Listeners (`slot`).

### 1.2 The Display Hierarchy (Tree of Views)
GUI elements form a visual tree:
* At the top sits **`Application::Application`** (derived from `Core::Root`). It represents the entire physical LCD display.
* Inside it are child views: Backgrounds, Header, Tabs, and **Page Components**.
* Z-Order (Drawing Order): In Embedded Wizard, objects placed lower or rightmost in the Composer brick list are drawn **on top** of earlier ones (or controlled via the `StackingPriority` property).

```mermaid
flowchart TD
    Root["Application::Application (Core::Root) [1120x620]"]
    Header["Header Bar (Title, Connection, Status LED)"]
    NavMain["Primary Tabs (Main, Watch All, Parameters, General)"]
    NavSub["Secondary Sub-Tabs Strip (Dynamic)"]
    ContentArea["Active Page Area [1090x440]"]

    Root --> Header
    Root --> NavMain
    Root --> NavSub
    Root --> ContentArea

    ContentArea --> P1["PageMain"]
    ContentArea --> P2["PageWatchAll"]
    ContentArea --> P3["PageParamTemp ... Calib (7 Pages)"]
    ContentArea --> P4["PageGenPresettings ... DateTime (3 Pages)"]
```

### 1.3 Why Modular Pages (`Core::Group`)?
> **Friendly Note - Why not draw everything directly inside `Application`?**
> If you put 12 pages of buttons, graphs, and telemetry cards all inside `Application::Application`, you would have hundreds of overlapping bricks. It would become impossible to edit.
> By creating separate classes derived from **`Core::Group`** (e.g. `PageMain`, `PageWatchAll`, `PageParamTemp`), each page is completely isolated in its own canvas. Inside `Application`, you only need one instance of each page object, and you switch screens simply by toggling:
> `PageMain.Visible = true;` and `PageWatchAll.Visible = false;`!

---

## Step 1: Project Setup & Screen Geometry

### 1.1 The Physical Display Budget
* **Screen Resolution**: `1120` pixels wide by `620` pixels high.
* **Vertical Layout Breakdown**:
  * **`y = 0 to 50`** (Height: 50px): **Header Bar** (Station title, Serial COM status, Online LED).
  * **`y = 58 to 102`** (Height: 44px): **Primary Tab Bar** (4 Main Tabs: Main, Watch All, Parameters, General).
  * **`y = 108 to 154`** (Height: 46px): **Secondary Sub-Menu Bar** (Sub-tabs for Parameters / General).
  * **`y = 160 to 600`** (Height: 440px): **Page Content Canvas** (`1090 x 440` active area).
  * **`y = 600 to 620`** (Height: 20px): Bottom margin padding.

### 1.2 Actions in Embedded Wizard Studio:
1. Open your project `SerialComEWS.ewp`.
2. In the **Browser** window (top-left tree), look at the active **Profile** (e.g., `Win32` or your target MCU profile).
3. In the **Inspector** (right pane), verify:
   * `ScreenSize`: `<1120,620>`
   * `ApplicationClass`: `Application::Application`

---

## Step 2: Font Resources & Typography

### Why Custom Font Resources?
> **Friendly Note - The Embedded Reality:**
> Embedded microcontrollers do not have Windows TrueType fonts installed in Windows system folders. Embedded Wizard compiles TTF fonts into compact, pre-rendered C arrays of bitmap glyphs at build time.
> Therefore, for every text size or weight you want to show, you define a **`Resources::Font`** brick!

### 2.1 The Fonts We Need:
1. `FontTitle` (22px Bold): Screen title in the top header.
2. `FontTab` (18px Bold): 4 Primary navigation tabs.
3. `FontSubTab` (15px Regular): Secondary navigation sub-tabs.
4. `FontCardTitle` (18px Bold): Card header titles on each page.
5. `FontBody` (15px Regular): Body text, labels, telemetry values.
6. `FontValue` (28px Bold): Large real-time telemetry numbers.
7. `FontBadge` (13px Regular): Status badges, small indicators.

### 2.2 How to Create a Font in EWS IDE:
1. In the Browser window, double-click the unit **`Application`** to open its Composer canvas.
2. Open the **Gallery** window (usually on the left or via `View -> Gallery`).
3. Expand the **Resources** folder in the Gallery.
4. Drag a **Font** brick into the `Application` Composer.
5. Rename the brick to **`FontTitle`**.
6. Select `FontTitle`, and in the **Inspector** window (right side), set its attributes:
   * **`FontName`**: `Roboto` (Embedded Wizard has bundled Roboto TTF fonts).
   * **`Height`**: `22`
   * **`Bold`**: `true`
   * **`Quality`**: `High`
   * **`Ranges`**: `0x20-0xFF` *(Crucial: This generates standard ASCII and extended Latin characters from code 32 to 255)*.
7. Repeat this process for `FontTab`, `FontSubTab`, `FontCardTitle`, `FontBody`, `FontValue`, and `FontBadge` using the heights and bold settings listed above.

---

## Step 3: Creating Modular Page Components (`Core::Group`)

We need 12 independent page screens:
* `PageMain` (Dashboard overview)
* `PageWatchAll` (4 Large Live Instrument Cards)
* 7 Parameter Pages: `PageParamTemp`, `PageParamCO2`, `PageParamRH`, `PageParamLight`, `PageParamDevConfig`, `PageParamAlarm`, `PageParamCalib`
* 3 General Pages: `PageGenPresettings`, `PageGenTestCOM`, `PageGenDateTime`

### 3.1 How to Create a Page Class in the IDE:
Let's build `PageMain` as an example (all other pages follow the exact same recipe):
1. In the `Application` Composer, look at the **Gallery** under **Chora** -> drag a **Class** brick onto the canvas.
2. Name the class: **`PageMain`**.
3. With `PageMain` selected, in the **Inspector**, change **`SuperClass`** from `Core::Object` to:
   **`Core::Group`**
   *(Significance: `Core::Group` is the base class for all visual container components that can contain their own child views, rectangles, text, and touch handlers)*.
4. **Double-click** on the `PageMain` class brick. A **new Composer tab** opens up representing the inside of `PageMain`!
5. In the top-left of this new Composer, you will see a brick called **`Bounds`**. In the Inspector, set:
   * `Bounds`: `<0,0,1090,440>` *(Matching the exact page area size)*.

### 3.2 Adding Views Inside `PageMain`:
Inside the `PageMain` Composer:

#### A. Add the Outer Background Panel:
1. From Gallery -> **Views**, drag a **Rectangle** into `PageMain`.
2. Name it `PageBg`.
3. In the Inspector, set:
   * `Bounds`: `<0,0,1090,440>`
   * `Color`: `#161F2EFF` *(Deep industrial dark navy)*
   * `Radius`: `10` *(Smooth rounded corners)*

#### B. Add a Content Card:
1. Drag another **Rectangle** from Gallery -> **Views**.
2. Name it `CardLeft`.
3. In the Inspector, set:
   * `Bounds`: `<20,20,530,420>`
   * `Color`: `#1E2838FF` *(Slightly lighter card background)*
   * `Radius`: `8`

#### C. Add a Card Header Stripe:
1. Drag another **Rectangle**, name it `CardLeftHeader`.
2. In the Inspector:
   * `Bounds`: `<20,20,530,65>`
   * `Color`: `#253248FF`
   * `RadiusTL`: `8`, `RadiusTR`: `8`, `RadiusBL`: `0`, `RadiusBR`: `0`

#### D. Add Card Title Text:
1. From Gallery -> **Views**, drag a **Text** brick.
2. Name it `CardLeftTitle`.
3. In the Inspector, set:
   * `Bounds`: `<35,25,515,60>`
   * `Font`: `Application::FontCardTitle`
   * `String`: `"SYSTEM INFORMATION"`
   * `Color`: `#FFFFFFFF`
   * `Alignment`: `[AlignHorzLeft, AlignVertCenter]`

#### E. Add Body Text Content:
1. Drag another **Text** brick, name it `CardLeftBody`.
2. In the Inspector, set:
   * `Bounds`: `<35,80,515,405>`
   * `Font`: `Application::FontBody`
   * `String`: `"Station ID: Chamber-Node-01\nSerial Link: RS-485 Modbus RTU\nBaud Rate: 115200 bps\nStatus: ONLINE & RUNNING"`
   * `Color`: `#94A3B8FF` *(Clean muted silver/grey)*
   * `Alignment`: `[AlignHorzLeft, AlignVertTop]`
   * `WrapText`: `true`

Repeat this pattern to create right-hand cards, status badges, or telemetry data!

---

## Step 4: Designing the Main Shell (`Application::Application`)

Now return to the top-level **`Application::Application`** class (double-click the `Application` class brick inside the `Application` unit).

### 4.1 Set Root Size:
* Ensure inherited `Bounds` is `<0,0,1120,620>`.

### 4.2 Top Header Bar (`y: 0 to 50`):
1. Add a **Rectangle** `TopBarBg`:
   * `Bounds`: `<0,0,1120,50>`, `Color`: `#111827FF`
2. Add a **Text** `TopBarTitle`:
   * `Bounds`: `<20,0,450,50>`, `Font`: `Application::FontTitle`, `String`: `"SERIAL COMMUNICATIONS HMI"`
3. Add a **Text** `TopBarStatus`:
   * `Bounds`: `<700,0,1100,50>`, `Font`: `Application::FontBody`, `String`: `"PORT: COM1 (RS-485)  |  BAUD: 115200  |  ONLINE"`
   * `Color`: `#38BDF8FF`, `Alignment`: `[AlignHorzRight, AlignVertCenter]`

### 4.3 Primary Navigation Tabs (`y: 58 to 102`):
We have 4 tabs placed horizontally:
* **Main**: `<15, 58, 175, 102>` (Width: 160px)
* **Watch All Values**: `<183, 58, 413, 102>` (Width: 230px)
* **Parameters**: `<421, 58, 651, 102>` (Width: 230px)
* **General**: `<659, 58, 859, 102>` (Width: 200px)

For each tab (e.g. `TabMain`), create three visual elements:
1. **Background Rectangle (`TabMainBg`)**:
   * `Bounds`: `<15, 58, 175, 102>`, `Color`: `#253248FF` (active) or `#1A2230FF` (inactive), `Radius`: `6`
2. **Bottom Accent Line (`TabMainLine`)**:
   * A thin `Views::Rectangle` at `<25, 98, 165, 101>` with `Color`: `#0284C7FF` (Sky Blue) to indicate which tab is currently selected.
3. **Tab Label (`TabMainText`)**:
   * `Views::Text` at `<15, 58, 175, 102>`, `Font`: `Application::FontTab`, `String`: `"Main"`.

---

## Step 5: Touch Interaction & Event Handling (`Core::SimpleTouchHandler`)

### Why `Core::SimpleTouchHandler`?
> **Friendly Note - How Touch Works in Mosaic:**
> Many GUI toolkits force you to use pre-built button widgets with rigid styling.
> Embedded Wizard provides **`Core::SimpleTouchHandler`**, an invisible, highly efficient touch sensor. You can place it directly over *any* graphical shape (rectangles, icons, images) to make that area instantly touch-sensitive!
>
> **Important Rule You Learned**:
> `Core::SimpleTouchHandler` is purely an event listener—it does **NOT** have a `Visible` property! You turn it on or off using **`Enabled = true`** or **`Enabled = false`**.

### 5.1 Adding Touch to a Tab:
1. In Gallery -> **Event Handlers**, drag a **SimpleTouchHandler** into `Application`.
2. Name it: **`TabMainTouch`**.
3. Position its 4 corners over the tab area:
   * `Point4`: `<15, 58>` (Top-Left)
   * `Point3`: `<175, 58>` (Top-Right)
   * `Point2`: `<175, 102>` (Bottom-Right)
   * `Point1`: `<15, 102>` (Bottom-Left)
4. Set `Enabled`: `true`.

### 5.2 Creating the Slot Method (Event Receiver):
1. In Gallery -> **Chora**, drag a **Slot Method** brick into `Application`.
2. Name it: **`onSelectMain`**.
3. In `TabMainTouch` Inspector, set:
   * **`OnPress`**: `onSelectMain`
4. Now, whenever the user taps the "Main" tab, Embedded Wizard automatically triggers `onSelectMain`!

---

## Step 6: State Management & The Layout Engine (Chora Code)

Now we connect the tabs to the pages.

### 6.1 State Variables:
In `Application::Application`, drag 3 **Variable** bricks from Gallery -> **Chora**:
1. `var int32 ActiveMainTab = 0;`
   *(0 = Main, 1 = Watch All, 2 = Parameters, 3 = General)*
2. `var int32 ActiveParamSubTab = 0;`
   *(0 = Temp, 1 = CO2, 2 = RH, 3 = Light, 4 = DevConfig, 5 = Alarm, 6 = Calib)*
3. `var int32 ActiveGenSubTab = 0;`
   *(0 = Presettings, 1 = Test COM, 2 = Date & Time)*

### 6.2 The Master Layout Method (`UpdateLayoutState`):
Drag a **Method** brick into `Application`, name it **`UpdateLayoutState`**, and double-click to open its code editor.

Write the following Chora code:

```chora
// ============================================================================
// 1. UPDATE PRIMARY TABS APPEARANCE
// ============================================================================
TabMainBg.Color     = ( ActiveMainTab == 0 ) ? #253248FF : #1A2230FF;
TabMainLine.Visible = ( ActiveMainTab == 0 );
TabMainText.Color   = ( ActiveMainTab == 0 ) ? #FFFFFFFF : #94A3B8FF;

TabWatchAllBg.Color     = ( ActiveMainTab == 1 ) ? #253248FF : #1A2230FF;
TabWatchAllLine.Visible = ( ActiveMainTab == 1 );
TabWatchAllText.Color   = ( ActiveMainTab == 1 ) ? #FFFFFFFF : #94A3B8FF;

TabParamsBg.Color     = ( ActiveMainTab == 2 ) ? #253248FF : #1A2230FF;
TabParamsLine.Visible = ( ActiveMainTab == 2 );
TabParamsText.Color   = ( ActiveMainTab == 2 ) ? #FFFFFFFF : #94A3B8FF;

TabGeneralBg.Color     = ( ActiveMainTab == 3 ) ? #253248FF : #1A2230FF;
TabGeneralLine.Visible = ( ActiveMainTab == 3 );
TabGeneralText.Color   = ( ActiveMainTab == 3 ) ? #FFFFFFFF : #94A3B8FF;

// ============================================================================
// 2. DYNAMIC SUB-MENU STRIP LOGIC
// ============================================================================
// Show Parameters sub-menu only when Parameters tab (index 2) is active:
var bool showParams = ( ActiveMainTab == 2 );

SubParamBg0.Visible    = showParams;
SubParamText0.Visible  = showParams;
SubParamTouch0.Enabled = showParams; // Only enable touch when visible!
// ... (Repeat for sub-tabs 1 through 6) ...

// Show General sub-menu only when General tab (index 3) is active:
var bool showGeneral = ( ActiveMainTab == 3 );

SubGenBg0.Visible    = showGeneral;
SubGenText0.Visible  = showGeneral;
SubGenTouch0.Enabled = showGeneral;
// ... (Repeat for sub-tabs 1 and 2) ...

// ============================================================================
// 3. SHOW THE ACTIVE PAGE (HIDE ALL OTHERS)
// ============================================================================
PageMain.Visible           = ( ActiveMainTab == 0 );
PageWatchAll.Visible       = ( ActiveMainTab == 1 );
PageParamTemp.Visible      = ( ActiveMainTab == 2 && ActiveParamSubTab == 0 );
PageParamCO2.Visible       = ( ActiveMainTab == 2 && ActiveParamSubTab == 1 );
PageParamRH.Visible        = ( ActiveMainTab == 2 && ActiveParamSubTab == 2 );
PageParamLight.Visible     = ( ActiveMainTab == 2 && ActiveParamSubTab == 3 );
PageParamDevConfig.Visible = ( ActiveMainTab == 2 && ActiveParamSubTab == 4 );
PageParamAlarm.Visible     = ( ActiveMainTab == 2 && ActiveParamSubTab == 5 );
PageParamCalib.Visible     = ( ActiveMainTab == 2 && ActiveParamSubTab == 6 );
PageGenPresettings.Visible = ( ActiveMainTab == 3 && ActiveGenSubTab == 0 );
PageGenTestCOM.Visible     = ( ActiveMainTab == 3 && ActiveGenSubTab == 1 );
PageGenDateTime.Visible    = ( ActiveMainTab == 3 && ActiveGenSubTab == 2 );
```

### 6.3 Wiring the Slot Methods:
In each slot method, simply change the active tab index and call `UpdateLayoutState()`:

* **`onSelectMain`**:
  ```chora
  ActiveMainTab = 0;
  UpdateLayoutState();
  ```
* **`onSelectWatchAll`**:
  ```chora
  ActiveMainTab = 1;
  UpdateLayoutState();
  ```
* **`onSelectParameters`**:
  ```chora
  ActiveMainTab = 2;
  UpdateLayoutState();
  ```
* **`onSelectGeneral`**:
  ```chora
  ActiveMainTab = 3;
  UpdateLayoutState();
  ```
* **`onSelectParamTemp`**:
  ```chora
  ActiveParamSubTab = 0;
  UpdateLayoutState();
  ```
* *(Same for all remaining sub-tab slots)*.

### 6.4 The `Init` Method:
In `Application::Application`, override or add the `Init()` method:
```chora
UpdateLayoutState();
```
*(Significance: When the GUI powers on, `Init()` runs automatically and configures the default active tab and screen!)*

---

## Step 7: Instantiating and Linking Everything

Now, how do the 12 Page Classes you created in Step 3 actually show up inside `Application::Application`?

1. Open the Composer of **`Application::Application`**.
2. Look at the Browser window (tree view on the left). Find your class **`PageMain`**.
3. **Drag and drop** `PageMain` directly from the Browser into the `Application` Composer!
   *(EWS creates an **Object** of type `Application::PageMain` named `PageMain`)*.
4. In the Inspector, set:
   * `Bounds`: `<15, 160, 1105, 600>`
   * `Visible`: `true`
5. Repeat this drag-and-drop for the remaining 11 page classes:
   * `PageWatchAll`
   * `PageParamTemp`, `PageParamCO2`, `PageParamRH`, `PageParamLight`, `PageParamDevConfig`, `PageParamAlarm`, `PageParamCalib`
   * `PageGenPresettings`, `PageGenTestCOM`, `PageGenDateTime`
6. Set all of their bounds to `<15, 160, 1105, 600>`.
7. Set their initial `Visible` properties to `false` (so only `PageMain` is visible on startup).

---

## Step 8: Testing, Debugging & Prototyping (F5)

Embedded Wizard includes a built-in interactive simulator called the **Prototyper**.

1. Press **`F5`** (or **`Ctrl + F5`**) to launch the Prototyper.
2. The 1120x620 HMI window appears on your desktop.
3. Test your work:
   * Click **Parameters** &rarr; Notice the secondary sub-menu appears with 7 tabs (`Temperature`, `CO2`, `RH`, `Light`, `Device Config`, `Alarm`, `Calibration`).
   * Click **CO2** &rarr; The CO2 parameter configuration card displays immediately.
   * Click **General** &rarr; Notice the 7 parameter tabs disappear and 3 new tabs appear (`Presettings`, `Test COM`, `Date & Time`).
   * Click **Watch All Values** &rarr; Shows the 4 instrument cards and Modbus stream monitor.

---

## Troubleshooting & Common Beginner Gotchas

Here are the exact lessons and solutions discovered during the construction of this app:

### 1. `Error: Invalid property name 'Visible' in 'Core::SimpleTouchHandler'`
* **Why it happens**: Unlike visual views (`Views::Rectangle`, `Views::Text`), touch handlers are invisible quad objects. They do not have a `.Visible` property.
* **The Fix**: Use **`.Enabled = true;`** or **`.Enabled = false;`**.

### 2. `EMWI ERROR: code: 180, info1: "FontBody", info2: 128`
* **Why it happens**: Code 180 means FreeType failed to get metrics for a glyph. If you save files without a UTF-8 BOM, Windows loads the file as ANSI (Windows-1252), causing Unicode characters like bullet (`•`) or degree (`°`) to turn into character code 128 (an invalid control code).
* **The Fix**:
  1. Always keep UI text within standard printable ASCII (character codes 32–126).
  2. Use `-` for bullets, and `C` or `deg C` for temperatures.
  3. Ensure `.ewu` files are saved with UTF-8 BOM (`utf-8-sig`).

### 3. Strings with Multi-Line Text in Chora
* **Why it happens**: In Chora code or presets, you cannot press `Enter` in the middle of a string literal.
* **The Fix**: Use literal `\n` escape sequences:
  ```chora
  preset String = "Line 1\nLine 2\nLine 3";
  ```

---

## Next Steps for Expansion

Now that your foundation is in place, you can expand this app piece-by-piece:
1. **Dynamic Data Binding**: Replace the sample strings in `PageWatchAll` with variables linked to your serial communication driver.
2. **Interactive Controls**: Add sliders or up/down increment buttons inside `PageParamTemp` to change setpoint values.
3. **Animations**: Use `Effects::ColorEffect` or `Effects::RectEffect` from the Gallery to add smooth transitions between tabs!
