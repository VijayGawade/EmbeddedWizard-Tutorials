# Local Python Slave Controller simulator for testing HTTP REST and Serial/CAN frames

#!/usr/bin/env python3
"""
Local Multi-Protocol Slave Controller Simulator for Windows Master App Testing
Supports:
  1. HTTP REST API Slave Server on http://127.0.0.1:8080/api/v1/packet
  2. Optional Serial (RS232 / RS485_FullDuplex / SLCAN) listener (if pyserial is installed)
  3. Data Packet Format 1: [?/!]:[aaaa]:[bb]:[ccc...ccc]:[dd]\r
  4. Data Packet Format 2: 29-Bit TF CAN Extended ID (SLCAN T<8-hex-ID><DLC><Data>\r)
"""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

SLAVE_REGISTERS = {
    0x01A4: "00FA",
    0x0200: "0064",
    0x0300: "1234",
}

def compute_crc8(data: bytes) -> int:
    crc = 0x00
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if (crc & 0x80) else ((crc << 1) & 0xFF)
    return crc

def process_format1_frame(raw_frame: str) -> str:
    clean = raw_frame.strip("\r\n")
    parts = clean.split(":")
    if len(parts) != 5:
        return "!:FFFF:03:ERR:3A\r"

    op, addr_hex, len_hex, payload, crc_hex = parts
    body = f"{op}:{addr_hex}:{len_hex}:{payload}".encode("ascii")
    calc_crc = compute_crc8(body)
    if calc_crc != int(crc_hex, 16):
        print(f"[SLAVE] Format 1 CRC Mismatch: Expected {calc_crc:02X}, Got {crc_hex}")
        return "!:FFFF:03:CRC:70\r"

    param_addr = int(addr_hex, 16)
    if op == "!":
        SLAVE_REGISTERS[param_addr] = payload
        print(f"[SLAVE] Format 1 WRITE Param 0x{param_addr:04X} = {payload}")
    else:
        print(f"[SLAVE] Format 1 READ  Param 0x{param_addr:04X}")

    resp_data = SLAVE_REGISTERS.get(param_addr, "0000")
    resp_body = f"!:{param_addr:04X}:{len(resp_data):02X}:{resp_data}"
    resp_crc  = compute_crc8(resp_body.encode("ascii"))
    return f"{resp_body}:{resp_crc:02X}\r"

def process_format2_slcan(raw_frame: str) -> str:
    clean = raw_frame.strip("\r\n")
    if not clean.startswith("T") or len(clean) < 10:
        return ""

    can_id   = int(clean[1:9], 16)
    dlc      = int(clean[9], 16)
    data_hex = clean[10:10 + dlc * 2]

    prio = (can_id >> 26) & 0x07
    op   = (can_id >> 23) & 0x07
    obj  = (can_id >> 12) & 0x7FF
    src  = (can_id >> 6)  & 0x3F
    dst  = can_id & 0x3F

    print(f"[SLAVE] Format 2 CAN RX: Prio={prio} Op={op} Obj=0x{obj:03X} Src={src} Dst={dst} Data={data_hex}")
    if op == 1 and dlc > 0:
        SLAVE_REGISTERS[obj] = data_hex.upper()

    val_hex = SLAVE_REGISTERS.get(obj, "000000FA").rjust(8, "0")[:8]
    resp_op = 2  # TFCAN_OP_RESPONSE
    resp_id = (prio << 26) | (resp_op << 23) | (obj << 12) | (dst << 6) | src
    return f"T{resp_id:08X}4{val_hex}\r"

class SlaveRestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/api/v1/packet":
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8")
        payload = json.loads(body)
        pkt_format = payload.get("format", 0)
        raw_packet = payload.get("packet", "")

        if pkt_format == 0:
            reply = process_format1_frame(raw_packet)
        else:
            reply = process_format2_slcan(raw_packet)

        reply_bytes = reply.encode("ascii")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(reply_bytes)))
        self.end_headers()
        self.wfile.write(reply_bytes)

if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", 8080), SlaveRestHandler)
    print("Slave Controller REST Simulator listening on http://127.0.0.1:8080/api/v1/packet ...")
    print("Press Ctrl+C to stop.")
    server.serve_forever()