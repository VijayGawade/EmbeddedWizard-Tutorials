/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file is part of the interface (glue layer) between an Embedded Wizard
*   generated UI application and the board support package (BSP) of a dedicated
*   target. It is intended to be used as a template. Feel free to adapt this
*   implementation according your particular hardware.
*
*   This file is responsible to initialize the display hardware and to provide
*   the necessary access to update the display content. The color format of the
*   framebuffer has to correspond to the color format of the Graphics Engine.
*
*******************************************************************************/

#ifndef EW_BSP_DISPLAY_H
#define EW_BSP_DISPLAY_H


#ifdef __cplusplus
  extern "C"
  {
#endif


/******************************************************************************
* TYPE:
*   XDisplayInfo
*
* DESCRIPTION:
*   The structure XDisplayInfo describes the attributes and current configuration
*   of the display. The interpretation and usage of the members may depend on the
*   underlying system and the selected framebuffer integration scenario.
*
* ELEMENTS:
*   FrameBuffer    - Pointer to the framebuffer memory. In case of double-buffering
*     it refers to the first framebuffer (not the currently active front-buffer).
*   DoubleBuffer   - Pointer to the second framebuffer in case of double-buffering.
*   DisplayWidth,
*   DisplayHeight  - Size of the display in pixel.
*   ViewportX,
*   ViewportY      - Origin of the viewport / start position of the GUI.
*   ViewportWidth,
*   ViewportHeight - Size of the viewport / area where the GUI will be drawn.
*   Context        - Optional pointer to a target specific struct.
*
******************************************************************************/
typedef struct
{
  void*             FrameBuffer;
  void*             DoubleBuffer;
  int               DisplayWidth;
  int               DisplayHeight;
  int               ViewportX;
  int               ViewportY;
  int               ViewportWidth;
  int               ViewportHeight;
  void*             Context;
} XDisplayInfo;


/*******************************************************************************
* FUNCTION:
*   EwBspDisplayInit
*
* DESCRIPTION:
*   The function EwBspDisplayInit initializes the display hardware and returns
*   the display parameter.
*
* ARGUMENTS:
*   aGuiWidth,
*   aGuiHeight   - Size of the GUI in pixel.
*   aDisplayInfo - Display info data structure.
*
* RETURN VALUE:
*   Returns 1 if successful, 0 otherwise.
*
*******************************************************************************/
int EwBspDisplayInit
(
  int               aGuiWidth,
  int               aGuiHeight,
  XDisplayInfo*     aDisplayInfo
);


/*******************************************************************************
* FUNCTION:
*   EwBspDisplayDone
*
* DESCRIPTION:
*   The function EwBspDisplayDone deinitializes the display hardware.
*
* ARGUMENTS:
*   aDisplayInfo - Display info data structure.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspDisplayDone
(
  XDisplayInfo*     aDisplayInfo
);


/*******************************************************************************
* FUNCTION:
*   EwBspDisplayUpdate
*
* DESCRIPTION:
*   The function EwBspDisplayUpdate updates the screen content.
*
* ARGUMENTS:
*   aContext - Display context.
*   aArea    - The update area.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspDisplayUpdate
(
  void* aContext,
  XRect aArea
);


#ifdef __cplusplus
  }
#endif

#endif /* EW_BSP_DISPLAY_H */


/* mli, msy */
