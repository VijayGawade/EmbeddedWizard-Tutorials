/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file is part of the interface (glue layer) between an Embedded Wizard
*   generated UI application and the board support package (BSP) of a dedicated
*   target. It is intended to be used as a template. Feel free to adapt this
*   implementation according your particular hardware.
*
*   This file is responsible to initialize the display hardware and to provide
*   the necessary access to update the display content. The color format of the
*   framebuffer has to correspond to the color format of the Graphics Engine.
*
*******************************************************************************/

#include <string.h>
#include <windows.h>

#include "ewrte.h"
#include "ewgfx.h"

#include "ew_bsp_display.h"
#include "gfx_system.h"


/*******************************************************************************
* FUNCTION:
*   EwBspDisplayInit
*
* DESCRIPTION:
*   The function EwBspDisplayInit initializes the display hardware and returns
*   the display parameter.
*
* ARGUMENTS:
*   aGuiWidth,
*   aGuiHeight   - Size of the GUI in pixel.
*   aDisplayInfo - Display info data structure.
*
* RETURN VALUE:
*   Returns 1 if successful, 0 otherwise.
*
*******************************************************************************/
int EwBspDisplayInit( int aGuiWidth, int aGuiHeight, XDisplayInfo* aDisplayInfo )
{
  int            guiWidth;
  int            guiHeight;
  XGfxSystemInfo gfxSystemInfo;

  /* check and clean display info structure */
  if ( !aDisplayInfo )
    return 0;

  memset( aDisplayInfo, 0, sizeof( XDisplayInfo ));

  /* adjust size of gui if viewport is rotated */
  #if (( EW_SURFACE_ROTATION == 90 ) || ( EW_SURFACE_ROTATION == 270 ))
    guiWidth  = aGuiHeight;
    guiHeight = aGuiWidth;
  #else
    guiWidth  = aGuiWidth;
    guiHeight = aGuiHeight;
  #endif

  /* create a surface */
  if ( ! GfxSystemCreateSurface( guiWidth, guiHeight ))
  {
    EwPrint( "Cannot create surface\n" );
    return 0;
  }


  /* get gfx system info structure */
  GfxSystemGetInfo( &gfxSystemInfo );

  if ( gfxSystemInfo.Type != GFX_SYSTEM_WINDOWS )
  {
    EwPrint( "Invalid GFX system\n" );
    return 0;
  }

  /* return the current display configuration */
  aDisplayInfo->FrameBuffer    = gfxSystemInfo.FrameBuffer;
  aDisplayInfo->DisplayWidth   = guiWidth;
  aDisplayInfo->DisplayHeight  = guiHeight;
  aDisplayInfo->ViewportX      = 0;
  aDisplayInfo->ViewportY      = 0;
  aDisplayInfo->ViewportWidth  = guiWidth;
  aDisplayInfo->ViewportHeight = guiHeight;
  aDisplayInfo->Context        = 0;

  return 1;
}


/*******************************************************************************
* FUNCTION:
*   EwBspDisplayDone
*
* DESCRIPTION:
*   The function EwBspDisplayDone deinitializes the display hardware.
*
* ARGUMENTS:
*   aDisplayInfo - Display info data structure.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspDisplayDone( XDisplayInfo* aDisplayInfo )
{
  EW_UNUSED_ARG( aDisplayInfo );
}


/*******************************************************************************
* FUNCTION:
*   EwBspDisplayUpdate
*
* DESCRIPTION:
*   The function EwBspDisplayUpdate updates the screen content.
*
* ARGUMENTS:
*   aContext - Display context.
*   aArea    - The update area.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspDisplayUpdate( void* aContext, XRect aArea )
{
  /* start an update if there is anything to draw */
  if ( !EwIsRectEmpty( aArea ))
    GfxSystemUpdateSurface(
      aArea.Point1.X, aArea.Point1.Y, aArea.Point2.X, aArea.Point2.Y );
}


/* mli, msy */
