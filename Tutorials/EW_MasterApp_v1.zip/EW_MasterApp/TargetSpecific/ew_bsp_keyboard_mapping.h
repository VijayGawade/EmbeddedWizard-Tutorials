/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file is part of the interface (glue layer) between an Embedded Wizard
*   generated UI application and the board support package (BSP) of a dedicated
*   target. It is intended to be used as a template. Feel free to adapt this
*   implementation according your particular hardware.

*   This file maps the key codes provided by the Windows system to EW_BSP key
*   codes.
*
*******************************************************************************/

#ifndef EW_BSP_KEYBOARD_MAPPING_H
#define EW_BSP_KEYBOARD_MAPPING_H

#include <windows.h>

#define EW_BSP_KEY_CODE_BACK      VK_BACK
#define EW_BSP_KEY_CODE_DELETE    VK_DELETE
#define EW_BSP_KEY_CODE_DOWN      VK_DOWN
#define EW_BSP_KEY_CODE_END       VK_END
#define EW_BSP_KEY_CODE_ESCAPE    VK_ESCAPE
#define EW_BSP_KEY_CODE_F1        VK_F1
#define EW_BSP_KEY_CODE_F10       VK_F10
#define EW_BSP_KEY_CODE_F2        VK_F2
#define EW_BSP_KEY_CODE_F3        VK_F3
#define EW_BSP_KEY_CODE_F4        VK_F4
#define EW_BSP_KEY_CODE_F5        VK_F5
#define EW_BSP_KEY_CODE_F6        VK_F6
#define EW_BSP_KEY_CODE_F7        VK_F7
#define EW_BSP_KEY_CODE_F8        VK_F8
#define EW_BSP_KEY_CODE_F9        VK_F9
#define EW_BSP_KEY_CODE_HOME      VK_HOME
#define EW_BSP_KEY_CODE_INSERT    VK_INSERT
#define EW_BSP_KEY_CODE_LEFT      VK_LEFT
#define EW_BSP_KEY_CODE_NEXT      VK_NEXT
#define EW_BSP_KEY_CODE_NUMPAD0   VK_NUMPAD0
#define EW_BSP_KEY_CODE_NUMPAD1   VK_NUMPAD1
#define EW_BSP_KEY_CODE_NUMPAD2   VK_NUMPAD2
#define EW_BSP_KEY_CODE_NUMPAD3   VK_NUMPAD3
#define EW_BSP_KEY_CODE_NUMPAD4   VK_NUMPAD4
#define EW_BSP_KEY_CODE_NUMPAD5   VK_NUMPAD5
#define EW_BSP_KEY_CODE_NUMPAD6   VK_NUMPAD6
#define EW_BSP_KEY_CODE_NUMPAD7   VK_NUMPAD7
#define EW_BSP_KEY_CODE_NUMPAD8   VK_NUMPAD8
#define EW_BSP_KEY_CODE_NUMPAD9   VK_NUMPAD9
#define EW_BSP_KEY_CODE_PRIOR     VK_PRIOR
#define EW_BSP_KEY_CODE_RETURN    VK_RETURN
#define EW_BSP_KEY_CODE_RIGHT     VK_RIGHT
#define EW_BSP_KEY_CODE_TAB       VK_TAB
#define EW_BSP_KEY_CODE_UP        VK_UP

#endif /* EW_BSP_KEYBOARD_MAPPING_H */


/* msy */
