/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file is part of the interface (glue layer) between an Embedded Wizard
*   generated UI application and the board support package (BSP) of a dedicated
*   target. It is intended to be used as a template. Feel free to adapt this
*   implementation according your particular hardware.
* 
*   This file is responsible to initialize the key board driver of the display
*   hardware and to receive the key board events for the GUI application.
*
*******************************************************************************/

#include "ewrte.h"
#include "ew_bsp_keyboard.h"
#include "gfx_system.h"


/*******************************************************************************
* FUNCTION:
*   EwBspKeyboardInit
*
* DESCRIPTION:
*   Initalizes the key board interface.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   Returns 1 if successful, 0 otherwise.
*
*******************************************************************************/
int EwBspKeyboardInit( void )
{
  return 1;
}


/*******************************************************************************
* FUNCTION:
*   EwBspKeyboardDone
*
* DESCRIPTION:
*   Terminates key board driver.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspKeyboardDone( void )
{
}


/*******************************************************************************
* FUNCTION:
*   EwBspKeyboardGetEvent
*
* DESCRIPTION:
*   The function EwBspKeyboardGetEvent gets the next available key board event 
*   from the key board driver
*
* ARGUMENTS:
*   aKeyboardEvent - Pointer to an object of type XKeyboardEvent.
*
* RETURN VALUE:
*   1 in case of a valid key board event, otherwise 0.
*
*******************************************************************************/
int EwBspKeyboardGetEvent( XKeyboardEvent* aKeyboardEvent )
{
  return GfxSystemGetKeyboardEvent( aKeyboardEvent );
}


/* msy */
