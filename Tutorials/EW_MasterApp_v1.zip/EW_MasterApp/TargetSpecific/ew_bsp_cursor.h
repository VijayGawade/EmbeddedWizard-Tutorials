/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file is part of the interface (glue layer) between an Embedded Wizard
*   generated UI application and the board support package (BSP) of a dedicated
*   target. It is intended to be used as a template. Feel free to adapt this
*   implementation according your particular hardware.
* 
*   This file is responsible to initialize the cursor driver of the display
*   hardware and to receive the cursor events for the GUI application.
*
*******************************************************************************/

#ifndef EW_BSP_CURSOR_H
#define EW_BSP_CURSOR_H


#ifdef __cplusplus
  extern "C"
  {
#endif


#define  EW_BSP_CURSOR_EVENT_IDLE             0
#define  EW_BSP_CURSOR_EVENT_MOVE             1
#define  EW_BSP_CURSOR_EVENT_BUTTON_PRESSED   2
#define  EW_BSP_CURSOR_EVENT_BUTTON_RELEASED  3


/******************************************************************************
* TYPE:
*   XCursorEvent
*
* DESCRIPTION:
*   The structure XCursorEvent contains the event type, the button state 
*   and the psotion of the cursor.
*
* ELEMENTS:
*   Type        - Event type.
*   X           - X position.
*   Y           - Y position.
*   Button      - The button number (-1, if no button is pressed).
*
******************************************************************************/
typedef struct
{
  int   Type;
  int   X;
  int   Y;
  int   Button;
} XCursorEvent;


/*******************************************************************************
* FUNCTION:
*   EwBspCursorInit
*
* DESCRIPTION:
*   Initalizes the cursor driver interface. The provided display information is
*   used to configure the cursor driver interface so that a proper mapping of
*   cursor coordinates to GUI coordinates can be done.
*
* ARGUMENTS:
*   aGuiWidth,
*   aGuiHeight   - Size of the GUI in pixel.
*   aDisplayInfo - Display info data structure.
*
* RETURN VALUE:
*   Returns 1 if successful, 0 otherwise.
*
*******************************************************************************/
int EwBspCursorInit
(
  int               aGuiWidth,
  int               aGuiHeight,
  XDisplayInfo*     aDisplayInfo
);


/*******************************************************************************
* FUNCTION:
*   EwBspCursorDone
*
* DESCRIPTION:
*   Terminates the cursor driver.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwBspCursorDone
(
  void
);


/*******************************************************************************
* FUNCTION:
*   EwBspCursorGetEvent
*
* DESCRIPTION:
*   The function EwBspCursorGetEvent gets the next available cursor event 
*   from the cursor driver.
*
* ARGUMENTS:
*   aCursorEvent - Pointer to return a cursor event.
*
* RETURN VALUE:
*   1 in case of a valid cursor event, otherwise 0.
*
*******************************************************************************/
int EwBspCursorGetEvent
(
  XCursorEvent*               aCursorEvent
);


#ifdef __cplusplus
  }
#endif

#endif /* EW_BSP_CURSOR_H */


/* msy */
