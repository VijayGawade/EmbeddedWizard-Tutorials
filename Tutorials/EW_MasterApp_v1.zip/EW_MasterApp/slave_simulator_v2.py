#!/usr/bin/env python3
"""
Multi-Protocol Slave Controller Simulator (HTTP REST API + Serial RS232/RS485/CAN)
Usage:
  1. HTTP REST API only (No extra packages needed):
     python C:\EW_MasterApp\slave_simulator.py
  2. HTTP REST API + Serial COM Port (Requires: pip install pyserial):
     python C:\EW_MasterApp\slave_simulator.py --com COM5 --baud 115200

Testing:
    $ curl.exe -X POST http://127.0.0.1:8080/api/v1/packet -H "Content-Type: application/json" -d "{\"format\":0,\"packet\":\"?:01A4:00::A5\"}"
"""
import argparse
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

SLAVE_REGISTERS = {
    0x01A4: "00FA",
    0x0200: "0064",
    0x0300: "1234",
}

def compute_crc8(data: bytes) -> int:
    crc = 0x00
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if (crc & 0x80) else ((crc << 1) & 0xFF)
    return crc

def process_format1_frame(raw_frame: str) -> str:
    clean = raw_frame.strip("\r\n")
    parts = clean.split(":")
    if len(parts) != 5:
        return "!:FFFF:03:ERR:3A\r"

    op, addr_hex, len_hex, payload, crc_hex = parts
    body = f"{op}:{addr_hex}:{len_hex}:{payload}".encode("ascii")
    calc_crc = compute_crc8(body)
    if calc_crc != int(crc_hex, 16):
        print(f"[SLAVE] Format 1 CRC Mismatch: Expected {calc_crc:02X}, Got {crc_hex}")
        return "!:FFFF:03:CRC:70\r"

    param_addr = int(addr_hex, 16)
    if op == "!":
        SLAVE_REGISTERS[param_addr] = payload
        print(f"[SLAVE] Format 1 WRITE -> Addr=0x{param_addr:04X}, NewVal={payload}")
    else:
        print(f"[SLAVE] Format 1 READ  -> Addr=0x{param_addr:04X}")

    resp_data = SLAVE_REGISTERS.get(param_addr, "0000")
    resp_body = f"!:{param_addr:04X}:{len(resp_data):02X}:{resp_data}"
    resp_crc  = compute_crc8(resp_body.encode("ascii"))
    reply = f"{resp_body}:{resp_crc:02X}\r"
    print(f"[SLAVE] Format 1 TX    -> {reply.strip()}")
    return reply

def process_format2_slcan(raw_frame: str) -> str:
    clean = raw_frame.strip("\r\n")
    if not clean.startswith("T") or len(clean) < 10:
        return ""

    can_id   = int(clean[1:9], 16)
    dlc      = int(clean[9], 16)
    data_hex = clean[10:10 + dlc * 2]

    prio = (can_id >> 26) & 0x07
    op   = (can_id >> 23) & 0x07
    obj  = (can_id >> 12) & 0x7FF
    src  = (can_id >> 6)  & 0x3F
    dst  = can_id & 0x3F

    print(f"[SLAVE] Format 2 CAN RX -> Prio={prio} Op={op} Obj=0x{obj:03X} Src={src} Dst={dst} Data={data_hex}")
    if op == 1 and dlc > 0:
        SLAVE_REGISTERS[obj] = data_hex.upper()

    val_hex = SLAVE_REGISTERS.get(obj, "000000FA").rjust(8, "0")[:8]
    resp_op = 2  # TFCAN_OP_RESPONSE
    resp_id = (prio << 26) | (resp_op << 23) | (obj << 12) | (dst << 6) | src
    reply = f"T{resp_id:08X}4{val_hex}\r"
    print(f"[SLAVE] Format 2 CAN TX -> {reply.strip()}")
    return reply

class SlaveRestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/api/v1/packet":
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8")
        payload = json.loads(body)
        pkt_format = payload.get("format", 0)
        raw_packet = payload.get("packet", "")

        reply = process_format1_frame(raw_packet) if pkt_format == 0 else process_format2_slcan(raw_packet)
        reply_bytes = reply.encode("ascii")

        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(reply_bytes)))
        self.end_headers()
        self.wfile.write(reply_bytes)

def serial_slave_worker(com_port: str, baud_rate: int):
    try:
        import serial
    except ImportError:
        print("[ERROR] pyserial not installed. Run: pip install pyserial")
        return

    print(f"[SLAVE] Opening Serial Port {com_port} at {baud_rate} baud...")
    with serial.Serial(com_port, baud_rate, timeout=0.1) as ser:
        buf = ""
        while True:
            chunk = ser.read(64).decode("ascii", errors="ignore")
            if chunk:
                for ch in chunk:
                    if ch in ("\r", "\n"):
                        if buf:
                            reply = process_format2_slcan(buf) if buf.startswith("T") else process_format1_frame(buf)
                            if reply:
                                ser.write(reply.encode("ascii"))
                            buf = ""
                    else:
                        buf += ch

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Multi-Protocol Slave Simulator")
    parser.add_argument("--com", type=str, default="", help="Optional Slave COM port (e.g., COM5)")
    parser.add_argument("--baud", type=int, default=115200, help="Serial baud rate (default: 115200)")
    parser.add_argument("--port", type=int, default=8080, help="HTTP REST port (default: 8080)")
    args = parser.parse_args()

    if args.com:
        t = threading.Thread(target=serial_slave_worker, args=(args.com, args.baud), daemon=True)
        t.start()

    server = HTTPServer(("127.0.0.1", args.port), SlaveRestHandler)
    print(f"[SLAVE] HTTP REST Simulator listening on http://127.0.0.1:{args.port}/api/v1/packet ...")
    server.serve_forever()