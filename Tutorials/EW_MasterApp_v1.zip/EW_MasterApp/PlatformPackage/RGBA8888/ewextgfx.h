/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software and related documentation (the "Library") are intellectual
* property of TARA Systems GmbH.
*
* Use of this file and the Library is governed as follows:
*
*   (1) To the extent your use is covered by the Embedded Wizard License
*       Agreement (EWLA) and the Embedded Wizard Terms and Conditions (EWTC),
*       or by another written commercial license agreement with TARA Systems
*       GmbH that expressly covers this Library, that agreement governs;
*       otherwise
*
*   (2) Your use is governed by the Embedded Wizard Community License (EWCL).
*
* Absent such a commercial license as in (1), distribution of products including
* this Library may require you to provide the complete corresponding Application
* Source Code, as described in the Embedded Wizard Community License (EWCL).
*
* Any use, modification, copying, reproduction, or redistribution of this file
* not in accordance with the applicable license is expressly prohibited. The
* removal of this preamble is expressly prohibited.
*
* License information:
*   EWTC: https://www.embedded-wizard.de/legal/ewtc
*   EWLA: https://www.embedded-wizard.de/legal/ewla
*   EWCL: https://www.embedded-wizard.de/legal/ewcl
*
********************************************************************************
*
* DESCRIPTION:
*   This header file contains Graphics Engine configuration parameters and the
*   adaptation for the target specific graphics subsystem.
*
*******************************************************************************/

#ifndef EWEXTGFX_H
#define EWEXTGFX_H


#ifdef __cplusplus
  extern "C"
  {
#endif

/*
  EW_USE_OFFSCREEN_BUFFER - Flag to switch on/off the usage of an off-screen
  buffer. This is an internal buffer, allocated by the Graphics Engine and
  used to prepare the graphical content (composition buffer).
  Per default, the usage of the off-screen buffer is disabled. To activate
  the usage of this composition buffer, please set the macro
  EW_USE_OFFSCREEN_BUFFER to 1 within your makefile. This can be achieved by
  using the compiler flag -DEW_USE_OFFSCREEN_BUFFER=1
  If the usage of an off-screen buffer is deactivated, the resulting display
  update depends on the macro EW_USE_DOUBLE_BUFFER:
  In case of a double-buffering configuration, the graphics composition is
  done directly into the back-buffer.
  In case of a single buffered configuration, the graphics composition is done
  directly into the framebuffer. This makes only sence, when you are using
  an LCD with its own pixelbuffer (e.g. some MIPI-DSI displays). Otherwise,
  the complete drawing composition is visible on the screen (flickering).
  The usage of an separate off-screen buffer might be advantagous on systems
  where the read access from the physical framebuffer is very slow. In this
  case, the off-screen buffer is used for composition (read and write acceess)
  and the final graphics is then copied into the framebuffer (write access).
*/
#ifndef EW_USE_OFFSCREEN_BUFFER
  #define EW_USE_OFFSCREEN_BUFFER 0
#endif

#if EW_USE_OFFSCREEN_BUFFER == 0
  #undef EW_USE_OFFSCREEN_BUFFER
#endif


/* The following macros override the default color channel allocation to the
   order (bit31) A..R..G..B (bit0). If your graphics hardware supports other
   color channel order, you can define the following macros in your make file. */
#ifndef EW_COLOR_CHANNEL_BIT_OFFSET_RED
  #define EW_COLOR_CHANNEL_BIT_OFFSET_RED    16
#endif

#ifndef EW_COLOR_CHANNEL_BIT_OFFSET_GREEN
  #define EW_COLOR_CHANNEL_BIT_OFFSET_GREEN   8
#endif

#ifndef EW_COLOR_CHANNEL_BIT_OFFSET_BLUE
  #define EW_COLOR_CHANNEL_BIT_OFFSET_BLUE    0
#endif

#ifndef EW_COLOR_CHANNEL_BIT_OFFSET_ALPHA
  #define EW_COLOR_CHANNEL_BIT_OFFSET_ALPHA  24
#endif


/* The following macros override the default color channel allocation to the
   order (bit15) R..G..B (bit0). If your graphics hardware supports other
   color channel order, you can define the following macros in your make file. */
#ifndef EW_RGB565_COLOR_CHANNEL_BIT_OFFSET_RED
  #define EW_RGB565_COLOR_CHANNEL_BIT_OFFSET_RED    11
#endif

#ifndef EW_RGB565_COLOR_CHANNEL_BIT_OFFSET_GREEN
  #define EW_RGB565_COLOR_CHANNEL_BIT_OFFSET_GREEN   5
#endif

#ifndef EW_RGB565_COLOR_CHANNEL_BIT_OFFSET_BLUE
  #define EW_RGB565_COLOR_CHANNEL_BIT_OFFSET_BLUE    0
#endif


/* Generic operates with premultiplied colors */
#define EW_PREMULTIPLY_COLOR_CHANNELS         1


/* The following XDib structure represents EmWi framebuffer in the MS Windows
   operating system environment. The structure covers the attributes of a usual
   Windows DIB. */
typedef struct
{
  int               Width;   /* Width of the DIB in pixel                     */
  int               Height;  /* Height of the DIB in pixel                    */
  void*             Header;  /* Internal Windows DIB header                   */
  unsigned char*    Pixel;   /* Pointer to 24 bit RGB information             */
  unsigned char*    Alpha;   /* Pointer to 8 bit alpha information (optional) */
} XDib;


/*******************************************************************************
* FUNCTION:
*   GfxInitViewport
*
* DESCRIPTION:
*   The function GfxInitViewport is called from the Graphics Engine,
*   to create a new viewport on the target. The function uses the given
*   buffers passed in the arguments aDisplay1 and aDisplay2.
*
* ARGUMENTS:
*   aWidth,
*   aHeight       - Size of the application in pixel.
*   aExtentX,
*   aExtentY      - not used.
*   aExtentWidth,
*   aExtentHeight - Size of the physical or virtual framebuffer in pixel.
*   aOrient       - not used.
*   aOpacity      - not used.
*   aDisplay1     - Pointer to Windows DIB.
*   aDisplay2     - not used.
*   aDisplay3     - not used.
*
* RETURN VALUE:
*   Handle of the surface descriptor (viewport).
*
*******************************************************************************/
void* GfxInitViewport
(
  int               aWidth,
  int               aHeight,
  int               aExtentX,
  int               aExtentY,
  int               aExtentWidth,
  int               aExtentHeight,
  int               aOrient,
  int               aOpacity,
  void*             aDisplay1,
  void*             aDisplay2,
  void*             aDisplay3
);


/*******************************************************************************
* FUNCTION:
*   GfxDoneViewport
*
* DESCRIPTION:
*   The function GfxDoneViewport is called from the Graphics Engine, to
*   release a previously created viewport on the target.
*
* ARGUMENTS:
*   aHandle - Handle of the surface descriptor (viewport).
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void GfxDoneViewport
(
  void*             aHandle
);


/*******************************************************************************
* FUNCTION:
*   GfxBeginUpdate
*
* DESCRIPTION:
*   The function GfxBeginUpdate is called from the Graphics Engine, to
*   initiate the screen update cycle.
*
* ARGUMENTS:
*   aHandle - Handle of the surface descriptor (viewport).
*
* RETURN VALUE:
*   Handle of the destination surface, used for all drawing operations.
*
*******************************************************************************/
void* GfxBeginUpdate
(
  void*             aHandle
);


/*******************************************************************************
* FUNCTION:
*   GfxEndUpdate
*
* DESCRIPTION:
*   The function GfxEndUpdate is called from the Graphics Engine, to
*   finalize the screen update cycle.
*
* ARGUMENTS:
*   aHandle - Handle of the surface descriptor (viewport).
*   aX,
*   aY,
*   aWidth,
*   aHeight - Position and size of the area affected from the screen update
*     (dirty rectangle).
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void GfxEndUpdate
(
  void*             aHandle,
  int               aX,
  int               aY,
  int               aWidth,
  int               aHeight
);


/* Redirect the following operations to the functions within this module */
#define EwGfxInitViewport    GfxInitViewport
#define EwGfxDoneViewport    GfxDoneViewport
#define EwGfxBeginUpdate     GfxBeginUpdate
#define EwGfxEndUpdate       GfxEndUpdate


#ifdef __cplusplus
  }
#endif

#endif /* EWEXTGFX_H */


/* msy */
