/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard tools based on the
* GUI project configuration and resources provided by you.
*
* Please do not modify this file! Any changes will be lost when it is generated
* again by the Embedded Wizard code generation process.
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy 'head.ewt' into your project directory
* and edit only that copy. Please avoid any modifications of the original
* template file.
*
* License, ownership and responsibility:
*
*   - The generated code is based on your project configuration and forms part
*     of your application. The application-specific content of this file
*     (including project-specific classes, resources and UI logic) is owned by
*     you or your licensors. You remain responsible for the overall design,
*     implementation, testing and validation of your application, including any
*     project-specific code and any changes or additions you make to the
*     generated code. TARA Systems GmbH is not responsible for defects or
*     malfunctions caused by such project-specific content or modifications.
*
*   - The use of Embedded Wizard Studio, the Embedded Wizard command line code
*     generator (ChoraC), the Embedded Wizard technology used to generate this
*     file and any Embedded Wizard Platform Packages and Runtime Components
*     required to build and run the generated code is subject to the Embedded
*     Wizard license terms (as published at https://www.embedded-wizard.de/legal),
*     including in particular:
*
*       - Embedded Wizard Terms and Conditions (EWTC)
*       - Embedded Wizard License Agreement (EWLA)
*       - Embedded Wizard Community License (EWCL)
*
*     The specific agreement(s) applicable to you and the applicable warranties
*     and limitations of liability are exclusively governed by these license
*     terms.
*
* Version  : 15.07
* Profile  : Profile
* Platform : Windows.Software.RGBA8888
*
*******************************************************************************/

#include "ewlocale.h"
#include "_ApplicationApplication.h"
#include "_ApplicationDeviceClass.h"
#include "_CoreSystemEvent.h"
#include "_CoreSystemEventHandler.h"
#include "_CoreView.h"
#include "_ResourcesFont.h"
#include "_ViewsRectangle.h"
#include "_ViewsText.h"
#include "_WidgetSetPushButton.h"
#include "_WidgetSetPushButtonConfig.h"
#include "Application.h"
#include "Resources.h"
#include "Views.h"
#include "WidgetSet.h"

/* Compressed strings for the language 'Default'. */
EW_CONST_STRING_PRAGMA static const unsigned int _StringsDefault0[] =
{
  0x000001A2, /* ratio 65.07 % */
  0xB8001300, 0x000A6452, 0x1CC2003A, 0xC0075004, 0x1510001C, 0x04122C0C, 0x008B1900,
  0xE32800E4, 0x89C463B0, 0xC8021250, 0x800D8003, 0x7E2F2237, 0x24E43824, 0x372F3700,
  0x10B31802, 0x199002E2, 0x4944225D, 0x8849A513, 0x711A0902, 0x488DB1A9, 0x4A273684,
  0x22F0A991, 0x9B2D0008, 0x11022000, 0x57898300, 0xC859A672, 0xA34B69F1, 0xC04C012A,
  0x42A350A9, 0x3C002FA3, 0x80062001, 0x934F001A, 0x03A0054C, 0x0018002E, 0x307D54F0,
  0x8549A0D1, 0xA53E6476, 0xC2A110AA, 0x5E214FBA, 0x80031825, 0x0037000C, 0x992BB8B8,
  0x10C6E4F2, 0xB96C4C0F, 0xAA8DAA56, 0xC5E2099A, 0x4422B43B, 0x62994A04, 0xA2799924,
  0x004CAA5C, 0xD13D0114, 0xB6005A89, 0x30844367, 0x23800B71, 0x9000AA00, 0x5AF634FB,
  0xAEEC5DE0, 0x47A00385, 0x9F1306D5, 0x94BBB1F2, 0x2686C3E3, 0xE8873A11, 0xE9803A20,
  0xDC2A874F, 0x46A1B26A, 0x42ABDB8E, 0x0000080C, 0x00000000
};

/* Constant values used in this 'C' module only. */
static const XRect _Const0000 = {{ 0, 0 }, { 1280, 720 }};
static const XColor _Const0001 = { 0xBF, 0xBF, 0xBF, 0xFF };
static const XRect _Const0002 = {{ 54, 74 }, { 551, 98 }};
static const XStringRes _Const0003 = { _StringsDefault0, 0x0002 };
static const XColor _Const0004 = { 0xFF, 0x4F, 0x7C, 0xFF };
static const XRect _Const0005 = {{ 54, 137 }, { 551, 161 }};
static const XStringRes _Const0006 = { _StringsDefault0, 0x000B };
static const XRect _Const0007 = {{ 54, 196 }, { 551, 220 }};
static const XStringRes _Const0008 = { _StringsDefault0, 0x0015 };
static const XRect _Const0009 = {{ 40, 594 }, { 190, 644 }};
static const XStringRes _Const000A = { _StringsDefault0, 0x001F };
static const XRect _Const000B = {{ 254, 594 }, { 404, 644 }};
static const XStringRes _Const000C = { _StringsDefault0, 0x0029 };
static const XRect _Const000D = {{ 490, 594 }, { 640, 644 }};
static const XStringRes _Const000E = { _StringsDefault0, 0x0034 };
static const XRect _Const000F = {{ 699, 594 }, { 849, 644 }};
static const XStringRes _Const0010 = { _StringsDefault0, 0x003D };
static const XRect _Const0011 = {{ 926, 594 }, { 1076, 644 }};
static const XStringRes _Const0012 = { _StringsDefault0, 0x0048 };
static const XStringRes _Const0013 = { _StringsDefault0, 0x0054 };
static const XStringRes _Const0014 = { _StringsDefault0, 0x0067 };
static const XStringRes _Const0015 = { _StringsDefault0, 0x0076 };
static const XStringRes _Const0016 = { _StringsDefault0, 0x0082 };
static const XStringRes _Const0017 = { _StringsDefault0, 0x0089 };
static const XStringRes _Const0018 = { _StringsDefault0, 0x0090 };
static const XStringRes _Const0019 = { _StringsDefault0, 0x0098 };
static const XStringRes _Const001A = { _StringsDefault0, 0x009F };
static const XStringRes _Const001B = { _StringsDefault0, 0x00A6 };
static const XStringRes _Const001C = { _StringsDefault0, 0x00B6 };
static const XStringRes _Const001D = { _StringsDefault0, 0x00C3 };

/* Initializer for the class 'Application::Application' */
void ApplicationApplication__Init( ApplicationApplication _this, XObject aLink, XHandle aArg )
{
  /* At first initialize the super class ... */
  CoreRoot__Init( &_this->_.Super, aLink, aArg );

  /* Allow the Immediate Garbage Collection to evalute the members of this class. */
  _this->_.XObject._.GCT = EW_CLASS_GCT( ApplicationApplication );

  /* ... then construct all embedded objects */
  ViewsRectangle__Init( &_this->Rectangle, &_this->_.XObject, 0 );
  ViewsText__Init( &_this->StatusText, &_this->_.XObject, 0 );
  ViewsText__Init( &_this->AddressText, &_this->_.XObject, 0 );
  ViewsText__Init( &_this->PayloadText, &_this->_.XObject, 0 );
  WidgetSetPushButton__Init( &_this->BtnConnect, &_this->_.XObject, 0 );
  WidgetSetPushButton__Init( &_this->BtnSwitchProtocol, &_this->_.XObject, 0 );
  WidgetSetPushButton__Init( &_this->BtnSwitchFormat, &_this->_.XObject, 0 );
  WidgetSetPushButton__Init( &_this->BtnSendRead, &_this->_.XObject, 0 );
  WidgetSetPushButton__Init( &_this->BtnSendWrite, &_this->_.XObject, 0 );
  CoreSystemEventHandler__Init( &_this->RxEventHandler, &_this->_.XObject, 0 );

  /* Setup the VMT pointer */
  _this->_.VMT = EW_CLASS( ApplicationApplication );

  /* ... and initialize objects, variables, properties, etc. */
  CoreRectView__OnSetBounds( _this, _Const0000 );
  CoreRectView__OnSetBounds( &_this->Rectangle, _Const0000 );
  ViewsRectangle_OnSetColor( &_this->Rectangle, _Const0001 );
  CoreRectView__OnSetBounds( &_this->StatusText, _Const0002 );
  ViewsText_OnSetOverflowWarning( &_this->StatusText, 1 );
  ViewsText_OnSetAutoSize( &_this->StatusText, 1 );
  ViewsText_OnSetWrapText( &_this->StatusText, 0 );
  ViewsText_OnSetAlignment( &_this->StatusText, ViewsTextAlignmentAlignHorzJustified 
  | ViewsTextAlignmentAlignVertCenter );
  ViewsText_OnSetString( &_this->StatusText, EwLoadString( &_Const0003 ));
  ViewsText_OnSetColor( &_this->StatusText, _Const0004 );
  CoreRectView__OnSetBounds( &_this->AddressText, _Const0005 );
  ViewsText_OnSetOverflowWarning( &_this->AddressText, 1 );
  ViewsText_OnSetAutoSize( &_this->AddressText, 1 );
  ViewsText_OnSetWrapText( &_this->AddressText, 0 );
  ViewsText_OnSetAlignment( &_this->AddressText, ViewsTextAlignmentAlignHorzJustified 
  | ViewsTextAlignmentAlignVertCenter );
  ViewsText_OnSetString( &_this->AddressText, EwLoadString( &_Const0006 ));
  ViewsText_OnSetColor( &_this->AddressText, _Const0004 );
  CoreRectView__OnSetBounds( &_this->PayloadText, _Const0007 );
  ViewsText_OnSetOverflowWarning( &_this->PayloadText, 1 );
  ViewsText_OnSetAutoSize( &_this->PayloadText, 1 );
  ViewsText_OnSetWrapText( &_this->PayloadText, 0 );
  ViewsText_OnSetAlignment( &_this->PayloadText, ViewsTextAlignmentAlignHorzJustified 
  | ViewsTextAlignmentAlignVertCenter );
  ViewsText_OnSetString( &_this->PayloadText, EwLoadString( &_Const0008 ));
  ViewsText_OnSetColor( &_this->PayloadText, _Const0004 );
  CoreRectView__OnSetBounds( &_this->BtnConnect, _Const0009 );
  WidgetSetPushButton_OnSetLabel( &_this->BtnConnect, EwLoadString( &_Const000A ));
  CoreRectView__OnSetBounds( &_this->BtnSwitchProtocol, _Const000B );
  WidgetSetPushButton_OnSetLabel( &_this->BtnSwitchProtocol, EwLoadString( &_Const000C ));
  CoreRectView__OnSetBounds( &_this->BtnSwitchFormat, _Const000D );
  WidgetSetPushButton_OnSetLabel( &_this->BtnSwitchFormat, EwLoadString( &_Const000E ));
  CoreRectView__OnSetBounds( &_this->BtnSendRead, _Const000F );
  WidgetSetPushButton_OnSetLabel( &_this->BtnSendRead, EwLoadString( &_Const0010 ));
  CoreRectView__OnSetBounds( &_this->BtnSendWrite, _Const0011 );
  WidgetSetPushButton_OnSetLabel( &_this->BtnSendWrite, EwLoadString( &_Const0012 ));
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->Rectangle ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->StatusText ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->AddressText ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->PayloadText ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->BtnConnect ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->BtnSwitchProtocol ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->BtnSwitchFormat ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->BtnSendRead ), 0 );
  CoreGroup_Add((CoreGroup)_this, ((CoreView)&_this->BtnSendWrite ), 0 );
  ViewsText_OnSetFont( &_this->StatusText, EwLoadResource( &ResourcesFontMedium, 
  ResourcesFont ));
  ViewsText_OnSetFont( &_this->AddressText, EwLoadResource( &ResourcesFontMedium, 
  ResourcesFont ));
  ViewsText_OnSetFont( &_this->PayloadText, EwLoadResource( &ResourcesFontMedium, 
  ResourcesFont ));
  _this->BtnConnect.OnActivate = EwNewSlot( _this, ApplicationApplication_OnConnectSlot );
  WidgetSetPushButton_OnSetAppearance( &_this->BtnConnect, EwGetAutoObject( &WidgetSetPushButton_Mono_Medium, 
  WidgetSetPushButtonConfig ));
  _this->BtnSwitchProtocol.OnActivate = EwNewSlot( _this, ApplicationApplication_OnToggleProtoSlot );
  WidgetSetPushButton_OnSetAppearance( &_this->BtnSwitchProtocol, EwGetAutoObject( 
  &WidgetSetPushButton_Mono_Medium, WidgetSetPushButtonConfig ));
  _this->BtnSwitchFormat.OnActivate = EwNewSlot( _this, ApplicationApplication_OnToggleFormatSlot );
  WidgetSetPushButton_OnSetAppearance( &_this->BtnSwitchFormat, EwGetAutoObject( 
  &WidgetSetPushButton_Mono_Medium, WidgetSetPushButtonConfig ));
  _this->BtnSendRead.OnActivate = EwNewSlot( _this, ApplicationApplication_OnReadSlot );
  WidgetSetPushButton_OnSetAppearance( &_this->BtnSendRead, EwGetAutoObject( &WidgetSetPushButton_Mono_Medium, 
  WidgetSetPushButtonConfig ));
  _this->BtnSendWrite.OnActivate = EwNewSlot( _this, ApplicationApplication_OnWriteSlot );
  WidgetSetPushButton_OnSetAppearance( &_this->BtnSendWrite, EwGetAutoObject( &WidgetSetPushButton_Mono_Medium, 
  WidgetSetPushButtonConfig ));
  _this->RxEventHandler.OnEvent = EwNewSlot( _this, ApplicationApplication_OnRxEventSlot );
  CoreSystemEventHandler_OnSetEvent( &_this->RxEventHandler, &EwGetAutoObject( &ApplicationDevice, 
  ApplicationDeviceClass )->RxPacketEvent );
}

/* Re-Initializer for the class 'Application::Application' */
void ApplicationApplication__ReInit( ApplicationApplication _this )
{
  /* At first re-initialize the super class ... */
  CoreRoot__ReInit( &_this->_.Super );

  /* ... then re-construct all embedded objects */
  ViewsRectangle__ReInit( &_this->Rectangle );
  ViewsText__ReInit( &_this->StatusText );
  ViewsText__ReInit( &_this->AddressText );
  ViewsText__ReInit( &_this->PayloadText );
  WidgetSetPushButton__ReInit( &_this->BtnConnect );
  WidgetSetPushButton__ReInit( &_this->BtnSwitchProtocol );
  WidgetSetPushButton__ReInit( &_this->BtnSwitchFormat );
  WidgetSetPushButton__ReInit( &_this->BtnSendRead );
  WidgetSetPushButton__ReInit( &_this->BtnSendWrite );
  CoreSystemEventHandler__ReInit( &_this->RxEventHandler );
}

/* Finalizer method for the class 'Application::Application' */
void ApplicationApplication__Done( ApplicationApplication _this )
{
  /* Finalize this class */
  _this->_.Super._.VMT = EW_CLASS( CoreRoot );

  /* Finalize all embedded objects */
  ViewsRectangle__Done( &_this->Rectangle );
  ViewsText__Done( &_this->StatusText );
  ViewsText__Done( &_this->AddressText );
  ViewsText__Done( &_this->PayloadText );
  WidgetSetPushButton__Done( &_this->BtnConnect );
  WidgetSetPushButton__Done( &_this->BtnSwitchProtocol );
  WidgetSetPushButton__Done( &_this->BtnSwitchFormat );
  WidgetSetPushButton__Done( &_this->BtnSendRead );
  WidgetSetPushButton__Done( &_this->BtnSendWrite );
  CoreSystemEventHandler__Done( &_this->RxEventHandler );

  /* Don't forget to deinitialize the super class ... */
  CoreRoot__Done( &_this->_.Super );
}

/* This slot method is executed when the associated system event handler 'SystemEventHandler' 
   receives an event. */
void ApplicationApplication_OnRxEventSlot( ApplicationApplication _this, XObject 
  sender )
{
  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( sender );

  ViewsText_OnSetString( &_this->AddressText, EwConcatString( EwLoadString( &_Const0013 ), 
  EwNewStringInt( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->LastRxAddress, 
  4, 16 )));
  ViewsText_OnSetString( &_this->PayloadText, EwConcatString( EwLoadString( &_Const0014 ), 
  EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->LastRxPayload ));
  ViewsText_OnSetString( &_this->StatusText, EwGetAutoObject( &ApplicationDevice, 
  ApplicationDeviceClass )->StatusLog );
}

/* 'C' function for method : 'Application::Application.OnConnectSlot()' */
void ApplicationApplication_OnConnectSlot( ApplicationApplication _this, XObject 
  sender )
{
  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( _this );
  EW_UNUSED_ARG( sender );

  if ( !EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->IsConnected )
  {
    if ( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->ProtocolType 
        == 3 )
      ApplicationDeviceClass_OpenConnection( EwGetAutoObject( &ApplicationDevice, 
      ApplicationDeviceClass ), EwLoadString( &_Const0015 ), 8080 );
    else
      ApplicationDeviceClass_OpenConnection( EwGetAutoObject( &ApplicationDevice, 
      ApplicationDeviceClass ), EwLoadString( &_Const0016 ), 115200 );
  }
  else
    ApplicationDeviceClass_CloseConnection( EwGetAutoObject( &ApplicationDevice, 
    ApplicationDeviceClass ));
}

/* 'C' function for method : 'Application::Application.OnToggleProtoSlot()' */
void ApplicationApplication_OnToggleProtoSlot( ApplicationApplication _this, XObject 
  sender )
{
  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( _this );
  EW_UNUSED_ARG( sender );

  ApplicationDeviceClass_OnSetProtocolType( EwGetAutoObject( &ApplicationDevice, 
  ApplicationDeviceClass ), ( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->ProtocolType 
  + 1 ) % 4 );
}

/* 'C' function for method : 'Application::Application.OnToggleFormatSlot()' */
void ApplicationApplication_OnToggleFormatSlot( ApplicationApplication _this, XObject 
  sender )
{
  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( _this );
  EW_UNUSED_ARG( sender );

  ApplicationDeviceClass_OnSetPacketFormat( EwGetAutoObject( &ApplicationDevice, 
  ApplicationDeviceClass ), (( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->PacketFormat 
  == 0 )? 1 : 0 ));
}

/* 'C' function for method : 'Application::Application.OnReadSlot()' */
void ApplicationApplication_OnReadSlot( ApplicationApplication _this, XObject sender )
{
  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( _this );
  EW_UNUSED_ARG( sender );

  if ( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->PacketFormat 
      == 0 )
    ApplicationDeviceClass_SendFormat1( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass ), 
    0, 420, 0 );
  else
    ApplicationDeviceClass_SendFormat2CAN( EwGetAutoObject( &ApplicationDevice, 
    ApplicationDeviceClass ), 3, 0, 420, 1, 2, 0 );
}

/* 'C' function for method : 'Application::Application.OnWriteSlot()' */
void ApplicationApplication_OnWriteSlot( ApplicationApplication _this, XObject sender )
{
  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( _this );
  EW_UNUSED_ARG( sender );

  if ( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass )->PacketFormat 
      == 0 )
    ApplicationDeviceClass_SendFormat1( EwGetAutoObject( &ApplicationDevice, ApplicationDeviceClass ), 
    1, 420, EwLoadString( &_Const0017 ));
  else
    ApplicationDeviceClass_SendFormat2CAN( EwGetAutoObject( &ApplicationDevice, 
    ApplicationDeviceClass ), 2, 1, 420, 1, 2, 250 );
}

/* Variants derived from the class : 'Application::Application' */
EW_DEFINE_CLASS_VARIANTS( ApplicationApplication )
EW_END_OF_CLASS_VARIANTS( ApplicationApplication )

/* Virtual Method Table (VMT) for the class : 'Application::Application' */
EW_DEFINE_CLASS( ApplicationApplication, CoreRoot, Rectangle, _.VMT, _.VMT, _.VMT, 
                 _.VMT, _.VMT, "Application::Application" )
  CoreRectView_initLayoutContext,
  CoreRoot_GetRoot,
  CoreRoot_Draw,
  CoreGroup_GetClipping,
  CoreView_HandleEvent,
  CoreGroup_CursorHitTest,
  CoreGroup_AdjustDrawingArea,
  CoreRectView_ArrangeView,
  CoreRectView_MoveView,
  CoreRectView_GetExtent,
  CoreRoot_ChangeViewState,
  CoreGroup_OnSetBounds,
  CoreRoot_OnSetFocus,
  CoreRoot_DispatchEvent,
  CoreRoot_BroadcastEvent,
  CoreGroup_UpdateViewState,
  CoreRoot_InvalidateArea,
EW_END_OF_CLASS( ApplicationApplication )

/* User defined inline code: 'Application::Inline' */
/*

  TO DO:

  Include external header files or add type and function declarations needed
  in the implementation of Application::DeviceClass. For example:

    #include "DeviceDriver.h"

    #include "your_middleware_api.h"

    void Your_Middleware_Some_Function( int aSomeArg );

*/
#include "transport_manager.h"


/* Initializer for the class 'Application::DeviceClass' */
void ApplicationDeviceClass__Init( ApplicationDeviceClass _this, XObject aLink, XHandle aArg )
{
  /* At first initialize the super class ... */
  TemplatesDeviceClass__Init( &_this->_.Super, aLink, aArg );

  /* Allow the Immediate Garbage Collection to evalute the members of this class. */
  _this->_.XObject._.GCT = EW_CLASS_GCT( ApplicationDeviceClass );

  /* ... then construct all embedded objects */
  CoreSystemEvent__Init( &_this->RxPacketEvent, &_this->_.XObject, 0 );

  /* Setup the VMT pointer */
  _this->_.VMT = EW_CLASS( ApplicationDeviceClass );

  /* ... and initialize objects, variables, properties, etc. */
  _this->ProtocolType = 3;
  _this->StatusLog = EwShareString( EwLoadString( &_Const0018 ));
  _this->CurrentOperation = EwShareString( EwLoadString( &_Const0019 ));
  _this->OperationResult = EwShareString( EwLoadString( &_Const001A ));
  _this->FailureReason = EwShareString( EwLoadString( &_Const001A ));

  /* Call the user defined constructor */
  ApplicationDeviceClass_Init( _this, aArg );
}

/* Re-Initializer for the class 'Application::DeviceClass' */
void ApplicationDeviceClass__ReInit( ApplicationDeviceClass _this )
{
  /* At first re-initialize the super class ... */
  TemplatesDeviceClass__ReInit( &_this->_.Super );

  /* ... then re-construct all embedded objects */
  CoreSystemEvent__ReInit( &_this->RxPacketEvent );
}

/* Finalizer method for the class 'Application::DeviceClass' */
void ApplicationDeviceClass__Done( ApplicationDeviceClass _this )
{
  /* Call the user defined destructor of the class */
  ApplicationDeviceClass_Done( _this );

  /* Finalize this class */
  _this->_.Super._.VMT = EW_CLASS( TemplatesDeviceClass );

  /* Finalize all embedded objects */
  CoreSystemEvent__Done( &_this->RxPacketEvent );

  /* Don't forget to deinitialize the super class ... */
  TemplatesDeviceClass__Done( &_this->_.Super );
}

/* 'C' function for method : 'Application::DeviceClass.Done()' */
void ApplicationDeviceClass_Done( ApplicationDeviceClass _this )
{
  XObject thisObject = ((XObject)_this );

  {
    /*
       TO DO:

       Depending on your application case you call functions of the underlying
       middleware (or access the device directly) in order to perform the necessary
       de-initialization steps. For example, you invoke some 'C' function:

         YourDevice_DeInitialize();

       IMPORTANT:
       ----------

       The variable 'thisObject' represents the actually de-initialized instance of the
       Application::DeviceClass. If you have stored this object at the initialization
       time (in the 'Init' method) in some global C variable or registered it by the
       middleware, it is important to perform now the opposite operation. Set the
       global variable to NULL or de-register 'thisObject' object from the middleware.

    */
  }
}

/* 'C' function for method : 'Application::DeviceClass.Init()' */
void ApplicationDeviceClass_Init( ApplicationDeviceClass _this, XHandle aArg )
{
  XObject thisObject;

  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( aArg );

  thisObject = ((XObject)_this );
  {
    /*
       TO DO:

       Depending on your application case you call functions of the underlying
       middleware (or access the device directly) in order to perform the necessary
       initialization steps. For example, you invoke some 'C' function:

         YourDevice_Initialize();

       The variable 'thisObject' represents the actually initialized instance of the
       Application::DeviceClass. You can store this variable e.g. in the middleware
       and use it whenever the middleware needs to notify the GUI application about
       some state alternation or events. In this manner, the middleware will be able
       to invoke methods of the interface device object.

       For example, you can store 'thisObject' in some global C variable:

         // Declaration of the global C variable
         XObject theDeviceObject;

         // Store the instance in the global variable
         theDeviceObject = thisObject;

       Later use the global variable e.g. to provide the GUI application with events:

         ApplicationDeviceClass__TriggerSomeEvent( theDeviceObject );

       IMPORTANT:
       ----------

       If you store 'thisObject' for later use, don't forget to implement the opposite
       operation in the method 'Done'. Concrete, 'Done' should set the global variable
       again to the value NULL.

    */
  }
}

/* This method is intended to be called by the device to notify the GUI application 
   about a particular system event. */
void ApplicationDeviceClass_TriggerEvent( ApplicationDeviceClass _this )
{
  CoreSystemEvent_Trigger( &_this->RxPacketEvent, 0, 0 );
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.TriggerEvent()' */
void ApplicationDeviceClass__TriggerEvent( void* _this )
{
  ApplicationDeviceClass_TriggerEvent((ApplicationDeviceClass)_this );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetProtocolType()' */
XInt32 ApplicationDeviceClass_OnGetProtocolType( ApplicationDeviceClass _this )
{
  return _this->ProtocolType;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetProtocolType()' */
void ApplicationDeviceClass_OnSetProtocolType( ApplicationDeviceClass _this, XInt32 
  value )
{
  if ( _this->ProtocolType == value )
    return;

  _this->ProtocolType = value;
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetProtocolType, 
    ApplicationDeviceClass_OnSetProtocolType ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateProtocolType( ApplicationDeviceClass _this, XInt32 
  aNewValue )
{
  if ( aNewValue != _this->ProtocolType )
  {
    _this->ProtocolType = aNewValue;
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetProtocolType, 
      ApplicationDeviceClass_OnSetProtocolType ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateProtocolType()' */
void ApplicationDeviceClass__UpdateProtocolType( void* _this, XInt32 aNewValue )
{
  ApplicationDeviceClass_UpdateProtocolType((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetPacketFormat()' */
XInt32 ApplicationDeviceClass_OnGetPacketFormat( ApplicationDeviceClass _this )
{
  return _this->PacketFormat;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetPacketFormat()' */
void ApplicationDeviceClass_OnSetPacketFormat( ApplicationDeviceClass _this, XInt32 
  value )
{
  if ( _this->PacketFormat == value )
    return;

  _this->PacketFormat = value;
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetPacketFormat, 
    ApplicationDeviceClass_OnSetPacketFormat ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdatePacketFormat( ApplicationDeviceClass _this, XInt32 
  aNewValue )
{
  if ( aNewValue != _this->PacketFormat )
  {
    _this->PacketFormat = aNewValue;
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetPacketFormat, 
      ApplicationDeviceClass_OnSetPacketFormat ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdatePacketFormat()' */
void ApplicationDeviceClass__UpdatePacketFormat( void* _this, XInt32 aNewValue )
{
  ApplicationDeviceClass_UpdatePacketFormat((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetIsConnected()' */
XBool ApplicationDeviceClass_OnGetIsConnected( ApplicationDeviceClass _this )
{
  return _this->IsConnected;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetIsConnected()' */
void ApplicationDeviceClass_OnSetIsConnected( ApplicationDeviceClass _this, XBool 
  value )
{
  if ( _this->IsConnected == value )
    return;

  _this->IsConnected = value;
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetIsConnected, 
    ApplicationDeviceClass_OnSetIsConnected ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateIsConnected( ApplicationDeviceClass _this, XBool 
  aNewValue )
{
  if ( aNewValue != _this->IsConnected )
  {
    _this->IsConnected = aNewValue;
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetIsConnected, 
      ApplicationDeviceClass_OnSetIsConnected ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateIsConnected()' */
void ApplicationDeviceClass__UpdateIsConnected( void* _this, XBool aNewValue )
{
  ApplicationDeviceClass_UpdateIsConnected((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetLastRxAddress()' */
XInt32 ApplicationDeviceClass_OnGetLastRxAddress( ApplicationDeviceClass _this )
{
  return _this->LastRxAddress;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetLastRxAddress()' */
void ApplicationDeviceClass_OnSetLastRxAddress( ApplicationDeviceClass _this, XInt32 
  value )
{
  if ( _this->LastRxAddress == value )
    return;

  _this->LastRxAddress = value;
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastRxAddress, 
    ApplicationDeviceClass_OnSetLastRxAddress ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateLastRxAddress( ApplicationDeviceClass _this, XInt32 
  aNewValue )
{
  if ( aNewValue != _this->LastRxAddress )
  {
    _this->LastRxAddress = aNewValue;
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastRxAddress, 
      ApplicationDeviceClass_OnSetLastRxAddress ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateLastRxAddress()' */
void ApplicationDeviceClass__UpdateLastRxAddress( void* _this, XInt32 aNewValue )
{
  ApplicationDeviceClass_UpdateLastRxAddress((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetLastRxPayload()' */
XString ApplicationDeviceClass_OnGetLastRxPayload( ApplicationDeviceClass _this )
{
  return _this->LastRxPayload;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetLastRxPayload()' */
void ApplicationDeviceClass_OnSetLastRxPayload( ApplicationDeviceClass _this, XString 
  value )
{
  if ( !EwCompString( _this->LastRxPayload, value ))
    return;

  _this->LastRxPayload = EwShareString( value );
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastRxPayload, 
    ApplicationDeviceClass_OnSetLastRxPayload ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateLastRxPayload( ApplicationDeviceClass _this, XString 
  aNewValue )
{
  if ( EwCompString( aNewValue, _this->LastRxPayload ) != 0 )
  {
    _this->LastRxPayload = EwShareString( aNewValue );
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastRxPayload, 
      ApplicationDeviceClass_OnSetLastRxPayload ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateLastRxPayload()' */
void ApplicationDeviceClass__UpdateLastRxPayload( void* _this, XString aNewValue )
{
  ApplicationDeviceClass_UpdateLastRxPayload((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetStatusLog()' */
XString ApplicationDeviceClass_OnGetStatusLog( ApplicationDeviceClass _this )
{
  return _this->StatusLog;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetStatusLog()' */
void ApplicationDeviceClass_OnSetStatusLog( ApplicationDeviceClass _this, XString 
  value )
{
  if ( !EwCompString( _this->StatusLog, value ))
    return;

  _this->StatusLog = EwShareString( value );
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetStatusLog, 
    ApplicationDeviceClass_OnSetStatusLog ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateStatusLog( ApplicationDeviceClass _this, XString 
  aNewValue )
{
  if ( EwCompString( aNewValue, _this->StatusLog ) != 0 )
  {
    _this->StatusLog = EwShareString( aNewValue );
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetStatusLog, 
      ApplicationDeviceClass_OnSetStatusLog ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateStatusLog()' */
void ApplicationDeviceClass__UpdateStatusLog( void* _this, XString aNewValue )
{
  ApplicationDeviceClass_UpdateStatusLog((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OpenConnection()' */
XBool ApplicationDeviceClass_OpenConnection( ApplicationDeviceClass _this, XString 
  aEndpoint, XInt32 aBaudOrPort )
{
  XInt32 proto = _this->ProtocolType;
  XInt32 format = _this->PacketFormat;
  XBool ok = 0;

  {
    char c_endpoint[128];
    EwStringToAnsi( aEndpoint, c_endpoint, sizeof( c_endpoint ), '?' );
    ok = Transport_Connect(
      (CommProtocol_t)proto,
      (PacketFormat_t)format,
      c_endpoint,
      (uint32_t)aBaudOrPort
    );
  }
  _this->IsConnected = ok;
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetIsConnected, 
    ApplicationDeviceClass_OnSetIsConnected ), 0 );
  return ok;
}

/* 'C' function for method : 'Application::DeviceClass.CloseConnection()' */
void ApplicationDeviceClass_CloseConnection( ApplicationDeviceClass _this )
{
  Transport_Disconnect();
  _this->IsConnected = 0;
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetIsConnected, 
    ApplicationDeviceClass_OnSetIsConnected ), 0 );
}

/* 'C' function for method : 'Application::DeviceClass.SendFormat1()' */
XBool ApplicationDeviceClass_SendFormat1( ApplicationDeviceClass _this, XBool aIsWrite, 
  XInt32 aAddr, XString aData )
{
  XBool sent;

  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( _this );

  sent = 0;
  {
    char c_data[129];
    EwStringToAnsi( aData, c_data, sizeof( c_data ), '?' );
    char op = aIsWrite ? '!' : '?';
    sent = Transport_SendFormat1Request( op, (uint16_t)(aAddr & 0xFFFF), c_data );
  }
  return sent;
}

/* 'C' function for method : 'Application::DeviceClass.SendFormat2CAN()' */
XBool ApplicationDeviceClass_SendFormat2CAN( ApplicationDeviceClass _this, XInt32 
  aPrio, XInt32 aOp, XInt32 aObjId, XInt32 aSrc, XInt32 aDst, XInt32 aValue32 )
{
  XBool sent;

  /* Dummy expressions to avoid the 'C' warning 'unused argument'. */
  EW_UNUSED_ARG( _this );

  sent = 0;
  {
    uint8_t payload[4];
    payload[0] = (uint8_t)((aValue32 >> 24) & 0xFF);
    payload[1] = (uint8_t)((aValue32 >> 16) & 0xFF);
    payload[2] = (uint8_t)((aValue32 >> 8)  & 0xFF);
    payload[3] = (uint8_t)(aValue32 & 0xFF);

    sent = Transport_SendFormat2CanFrame(
      (uint8_t)(aPrio & 0x07),
      (uint8_t)(aOp & 0x07),
      (uint16_t)(aObjId & 0x7FF),
      (uint8_t)(aSrc & 0x3F),
      (uint8_t)(aDst & 0x3F),
      payload,
      4U
    );
  }
  return sent;
}

/* 'C' function for method : 'Application::DeviceClass.UpdateTelemetryFromDriver()' */
void ApplicationDeviceClass_UpdateTelemetryFromDriver( ApplicationDeviceClass _this, 
  XInt32 aParamOrObjId, XBool aIsError, XString aOperation, XString aResult, XString 
  aFailure, XString aPayload, XString aRawLog )
{
  _this->LastRxAddress = aParamOrObjId;
  _this->LastIsError = aIsError;
  _this->CurrentOperation = EwShareString( aOperation );
  _this->OperationResult = EwShareString( aResult );
  _this->FailureReason = EwShareString( aFailure );
  _this->LastRxPayload = EwShareString( aPayload );
  _this->StatusLog = EwShareString( aRawLog );
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastRxAddress, 
    ApplicationDeviceClass_OnSetLastRxAddress ), 0 );
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastIsError, 
    ApplicationDeviceClass_OnSetLastIsError ), 0 );
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetCurrentOperation, 
    ApplicationDeviceClass_OnSetCurrentOperation ), 0 );
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetOperationResult, 
    ApplicationDeviceClass_OnSetOperationResult ), 0 );
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetFailureReason, 
    ApplicationDeviceClass_OnSetFailureReason ), 0 );
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastRxPayload, 
    ApplicationDeviceClass_OnSetLastRxPayload ), 0 );
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetStatusLog, 
    ApplicationDeviceClass_OnSetStatusLog ), 0 );
  EwTrace( "%s%s%s%s%s%s", EwLoadString( &_Const001B ), aOperation, EwLoadString( 
    &_Const001C ), aResult, EwLoadString( &_Const001D ), aFailure );
  CoreSystemEvent_Trigger( &_this->RxPacketEvent, 0, 0 );
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateTelemetryFromDriver()' */
void ApplicationDeviceClass__UpdateTelemetryFromDriver( void* _this, XInt32 aParamOrObjId, 
  XBool aIsError, XString aOperation, XString aResult, XString aFailure, XString 
  aPayload, XString aRawLog )
{
  ApplicationDeviceClass_UpdateTelemetryFromDriver((ApplicationDeviceClass)_this
  , aParamOrObjId, aIsError, aOperation, aResult, aFailure, aPayload, aRawLog );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetLastIsError()' */
XBool ApplicationDeviceClass_OnGetLastIsError( ApplicationDeviceClass _this )
{
  return _this->LastIsError;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetLastIsError()' */
void ApplicationDeviceClass_OnSetLastIsError( ApplicationDeviceClass _this, XBool 
  value )
{
  if ( _this->LastIsError == value )
    return;

  _this->LastIsError = value;
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastIsError, 
    ApplicationDeviceClass_OnSetLastIsError ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateLastIsError( ApplicationDeviceClass _this, XBool 
  aNewValue )
{
  if ( aNewValue != _this->LastIsError )
  {
    _this->LastIsError = aNewValue;
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetLastIsError, 
      ApplicationDeviceClass_OnSetLastIsError ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateLastIsError()' */
void ApplicationDeviceClass__UpdateLastIsError( void* _this, XBool aNewValue )
{
  ApplicationDeviceClass_UpdateLastIsError((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetCurrentOperation()' */
XString ApplicationDeviceClass_OnGetCurrentOperation( ApplicationDeviceClass _this )
{
  return _this->CurrentOperation;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetCurrentOperation()' */
void ApplicationDeviceClass_OnSetCurrentOperation( ApplicationDeviceClass _this, 
  XString value )
{
  if ( !EwCompString( _this->CurrentOperation, value ))
    return;

  _this->CurrentOperation = EwShareString( value );
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetCurrentOperation, 
    ApplicationDeviceClass_OnSetCurrentOperation ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateCurrentOperation( ApplicationDeviceClass _this, 
  XString aNewValue )
{
  if ( EwCompString( aNewValue, _this->CurrentOperation ) != 0 )
  {
    _this->CurrentOperation = EwShareString( aNewValue );
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetCurrentOperation, 
      ApplicationDeviceClass_OnSetCurrentOperation ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateCurrentOperation()' */
void ApplicationDeviceClass__UpdateCurrentOperation( void* _this, XString aNewValue )
{
  ApplicationDeviceClass_UpdateCurrentOperation((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetOperationResult()' */
XString ApplicationDeviceClass_OnGetOperationResult( ApplicationDeviceClass _this )
{
  return _this->OperationResult;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetOperationResult()' */
void ApplicationDeviceClass_OnSetOperationResult( ApplicationDeviceClass _this, 
  XString value )
{
  if ( !EwCompString( _this->OperationResult, value ))
    return;

  _this->OperationResult = EwShareString( value );
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetOperationResult, 
    ApplicationDeviceClass_OnSetOperationResult ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateOperationResult( ApplicationDeviceClass _this, 
  XString aNewValue )
{
  if ( EwCompString( aNewValue, _this->OperationResult ) != 0 )
  {
    _this->OperationResult = EwShareString( aNewValue );
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetOperationResult, 
      ApplicationDeviceClass_OnSetOperationResult ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateOperationResult()' */
void ApplicationDeviceClass__UpdateOperationResult( void* _this, XString aNewValue )
{
  ApplicationDeviceClass_UpdateOperationResult((ApplicationDeviceClass)_this, aNewValue );
}

/* 'C' function for method : 'Application::DeviceClass.OnGetFailureReason()' */
XString ApplicationDeviceClass_OnGetFailureReason( ApplicationDeviceClass _this )
{
  return _this->FailureReason;
}

/* 'C' function for method : 'Application::DeviceClass.OnSetFailureReason()' */
void ApplicationDeviceClass_OnSetFailureReason( ApplicationDeviceClass _this, XString 
  value )
{
  if ( !EwCompString( _this->FailureReason, value ))
    return;

  _this->FailureReason = EwShareString( value );
  {
    /*
       TO DO:

       You can call a function of your own device API or you simply
       modify a variable existing in your middleware to reflect the
       new value:

       YourDevice_SetSomeValue( value );

       or

       YourDevice_SomeVariable = value;
    */
  }
  EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetFailureReason, 
    ApplicationDeviceClass_OnSetFailureReason ), 0 );
}

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateFailureReason( ApplicationDeviceClass _this, XString 
  aNewValue )
{
  if ( EwCompString( aNewValue, _this->FailureReason ) != 0 )
  {
    _this->FailureReason = EwShareString( aNewValue );
    EwNotifyRefObservers( EwNewRef( _this, ApplicationDeviceClass_OnGetFailureReason, 
      ApplicationDeviceClass_OnSetFailureReason ), 0 );
  }
}

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateFailureReason()' */
void ApplicationDeviceClass__UpdateFailureReason( void* _this, XString aNewValue )
{
  ApplicationDeviceClass_UpdateFailureReason((ApplicationDeviceClass)_this, aNewValue );
}

/* Variants derived from the class : 'Application::DeviceClass' */
EW_DEFINE_CLASS_VARIANTS( ApplicationDeviceClass )
EW_END_OF_CLASS_VARIANTS( ApplicationDeviceClass )

/* Virtual Method Table (VMT) for the class : 'Application::DeviceClass' */
EW_DEFINE_CLASS( ApplicationDeviceClass, TemplatesDeviceClass, RxPacketEvent, LastRxPayload, 
                 LastRxPayload, LastRxPayload, LastRxPayload, ProtocolType, "Application::DeviceClass" )
EW_END_OF_CLASS( ApplicationDeviceClass )

/* User defined auto object: 'Application::Device' */
EW_DEFINE_AUTOOBJECT( ApplicationDevice, ApplicationDeviceClass )

/* Initializer for the auto object 'Application::Device' */
void ApplicationDevice__Init( ApplicationDeviceClass _this )
{
  EW_UNUSED_ARG( _this );
}

/* Re-Initializer for the auto object 'Application::Device' */
void ApplicationDevice__ReInit( ApplicationDeviceClass _this )
{
  EW_UNUSED_ARG( _this );
}

/* Table with links to derived variants of the auto object : 'Application::Device' */
EW_DEFINE_AUTOOBJECT_VARIANTS( ApplicationDevice )
EW_END_OF_AUTOOBJECT_VARIANTS( ApplicationDevice )

/* Embedded Wizard */
