/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard tools based on the
* GUI project configuration and resources provided by you.
*
* Please do not modify this file! Any changes will be lost when it is generated
* again by the Embedded Wizard code generation process.
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy 'head.ewt' into your project directory
* and edit only that copy. Please avoid any modifications of the original
* template file.
*
* License, ownership and responsibility:
*
*   - The generated code is based on your project configuration and forms part
*     of your application. The application-specific content of this file
*     (including project-specific classes, resources and UI logic) is owned by
*     you or your licensors. You remain responsible for the overall design,
*     implementation, testing and validation of your application, including any
*     project-specific code and any changes or additions you make to the
*     generated code. TARA Systems GmbH is not responsible for defects or
*     malfunctions caused by such project-specific content or modifications.
*
*   - The use of Embedded Wizard Studio, the Embedded Wizard command line code
*     generator (ChoraC), the Embedded Wizard technology used to generate this
*     file and any Embedded Wizard Platform Packages and Runtime Components
*     required to build and run the generated code is subject to the Embedded
*     Wizard license terms (as published at https://www.embedded-wizard.de/legal),
*     including in particular:
*
*       - Embedded Wizard Terms and Conditions (EWTC)
*       - Embedded Wizard License Agreement (EWLA)
*       - Embedded Wizard Community License (EWCL)
*
*     The specific agreement(s) applicable to you and the applicable warranties
*     and limitations of liability are exclusively governed by these license
*     terms.
*
* Version  : 15.07
* Profile  : Profile
* Platform : Windows.Software.RGBA8888
*
*******************************************************************************/

#ifndef _ApplicationDeviceClass_H
#define _ApplicationDeviceClass_H

#ifdef __cplusplus
  extern "C"
  {
#endif

#include "ewrte.h"
#if ( EW_RTE_VERSION >> 16 ) != 15
  #error Wrong version of Embedded Wizard Runtime Environment.
#endif

#include "ewgfx.h"
#if ( EW_GFX_VERSION >> 16 ) != 15
  #error Wrong version of Embedded Wizard Graphics Engine.
#endif

#include "_CoreSystemEvent.h"
#include "_TemplatesDeviceClass.h"

/* Forward declaration of the class Application::DeviceClass */
#ifndef _ApplicationDeviceClass_
  EW_DECLARE_CLASS( ApplicationDeviceClass )
#define _ApplicationDeviceClass_
#endif


/* Deklaration of class : 'Application::DeviceClass' */
EW_DEFINE_FIELDS( ApplicationDeviceClass, TemplatesDeviceClass )
  EW_OBJECT  ( RxPacketEvent,   CoreSystemEvent )
  EW_PROPERTY( LastRxPayload,   XString )
  EW_PROPERTY( StatusLog,       XString )
  EW_PROPERTY( CurrentOperation, XString )
  EW_PROPERTY( OperationResult, XString )
  EW_PROPERTY( FailureReason,   XString )
  EW_PROPERTY( ProtocolType,    XInt32 )
  EW_PROPERTY( PacketFormat,    XInt32 )
  EW_PROPERTY( LastRxAddress,   XInt32 )
  EW_PROPERTY( IsConnected,     XBool )
  EW_PROPERTY( LastIsError,     XBool )
EW_END_OF_FIELDS( ApplicationDeviceClass )

/* Virtual Method Table (VMT) for the class : 'Application::DeviceClass' */
EW_DEFINE_METHODS( ApplicationDeviceClass, TemplatesDeviceClass )
EW_END_OF_METHODS( ApplicationDeviceClass )

/* 'C' function for method : 'Application::DeviceClass.Done()' */
void ApplicationDeviceClass_Done( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.Init()' */
void ApplicationDeviceClass_Init( ApplicationDeviceClass _this, XHandle aArg );

/* This method is intended to be called by the device to notify the GUI application 
   about a particular system event. */
void ApplicationDeviceClass_TriggerEvent( ApplicationDeviceClass _this );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.TriggerEvent()' */
void ApplicationDeviceClass__TriggerEvent( void* _this );

/* The following define announces the presence of the method Application::DeviceClass.TriggerEvent(). */
#define _ApplicationDeviceClass__TriggerEvent_

/* 'C' function for method : 'Application::DeviceClass.OnGetProtocolType()' */
XInt32 ApplicationDeviceClass_OnGetProtocolType( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetProtocolType()' */
void ApplicationDeviceClass_OnSetProtocolType( ApplicationDeviceClass _this, XInt32 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateProtocolType( ApplicationDeviceClass _this, XInt32 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateProtocolType()' */
void ApplicationDeviceClass__UpdateProtocolType( void* _this, XInt32 aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateProtocolType(). */
#define _ApplicationDeviceClass__UpdateProtocolType_

/* 'C' function for method : 'Application::DeviceClass.OnGetPacketFormat()' */
XInt32 ApplicationDeviceClass_OnGetPacketFormat( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetPacketFormat()' */
void ApplicationDeviceClass_OnSetPacketFormat( ApplicationDeviceClass _this, XInt32 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdatePacketFormat( ApplicationDeviceClass _this, XInt32 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdatePacketFormat()' */
void ApplicationDeviceClass__UpdatePacketFormat( void* _this, XInt32 aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdatePacketFormat(). */
#define _ApplicationDeviceClass__UpdatePacketFormat_

/* 'C' function for method : 'Application::DeviceClass.OnGetIsConnected()' */
XBool ApplicationDeviceClass_OnGetIsConnected( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetIsConnected()' */
void ApplicationDeviceClass_OnSetIsConnected( ApplicationDeviceClass _this, XBool 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateIsConnected( ApplicationDeviceClass _this, XBool 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateIsConnected()' */
void ApplicationDeviceClass__UpdateIsConnected( void* _this, XBool aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateIsConnected(). */
#define _ApplicationDeviceClass__UpdateIsConnected_

/* 'C' function for method : 'Application::DeviceClass.OnGetLastRxAddress()' */
XInt32 ApplicationDeviceClass_OnGetLastRxAddress( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetLastRxAddress()' */
void ApplicationDeviceClass_OnSetLastRxAddress( ApplicationDeviceClass _this, XInt32 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateLastRxAddress( ApplicationDeviceClass _this, XInt32 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateLastRxAddress()' */
void ApplicationDeviceClass__UpdateLastRxAddress( void* _this, XInt32 aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateLastRxAddress(). */
#define _ApplicationDeviceClass__UpdateLastRxAddress_

/* 'C' function for method : 'Application::DeviceClass.OnGetLastRxPayload()' */
XString ApplicationDeviceClass_OnGetLastRxPayload( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetLastRxPayload()' */
void ApplicationDeviceClass_OnSetLastRxPayload( ApplicationDeviceClass _this, XString 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateLastRxPayload( ApplicationDeviceClass _this, XString 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateLastRxPayload()' */
void ApplicationDeviceClass__UpdateLastRxPayload( void* _this, XString aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateLastRxPayload(). */
#define _ApplicationDeviceClass__UpdateLastRxPayload_

/* 'C' function for method : 'Application::DeviceClass.OnGetStatusLog()' */
XString ApplicationDeviceClass_OnGetStatusLog( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetStatusLog()' */
void ApplicationDeviceClass_OnSetStatusLog( ApplicationDeviceClass _this, XString 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateStatusLog( ApplicationDeviceClass _this, XString 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateStatusLog()' */
void ApplicationDeviceClass__UpdateStatusLog( void* _this, XString aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateStatusLog(). */
#define _ApplicationDeviceClass__UpdateStatusLog_

/* 'C' function for method : 'Application::DeviceClass.OpenConnection()' */
XBool ApplicationDeviceClass_OpenConnection( ApplicationDeviceClass _this, XString 
  aEndpoint, XInt32 aBaudOrPort );

/* 'C' function for method : 'Application::DeviceClass.CloseConnection()' */
void ApplicationDeviceClass_CloseConnection( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.SendFormat1()' */
XBool ApplicationDeviceClass_SendFormat1( ApplicationDeviceClass _this, XBool aIsWrite, 
  XInt32 aAddr, XString aData );

/* 'C' function for method : 'Application::DeviceClass.SendFormat2CAN()' */
XBool ApplicationDeviceClass_SendFormat2CAN( ApplicationDeviceClass _this, XInt32 
  aPrio, XInt32 aOp, XInt32 aObjId, XInt32 aSrc, XInt32 aDst, XInt32 aValue32 );

/* 'C' function for method : 'Application::DeviceClass.UpdateTelemetryFromDriver()' */
void ApplicationDeviceClass_UpdateTelemetryFromDriver( ApplicationDeviceClass _this, 
  XInt32 aParamOrObjId, XBool aIsError, XString aOperation, XString aResult, XString 
  aFailure, XString aPayload, XString aRawLog );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateTelemetryFromDriver()' */
void ApplicationDeviceClass__UpdateTelemetryFromDriver( void* _this, XInt32 aParamOrObjId, 
  XBool aIsError, XString aOperation, XString aResult, XString aFailure, XString 
  aPayload, XString aRawLog );

/* The following define announces the presence of the method Application::DeviceClass.UpdateTelemetryFromDriver(). */
#define _ApplicationDeviceClass__UpdateTelemetryFromDriver_

/* 'C' function for method : 'Application::DeviceClass.OnGetLastIsError()' */
XBool ApplicationDeviceClass_OnGetLastIsError( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetLastIsError()' */
void ApplicationDeviceClass_OnSetLastIsError( ApplicationDeviceClass _this, XBool 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateLastIsError( ApplicationDeviceClass _this, XBool 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateLastIsError()' */
void ApplicationDeviceClass__UpdateLastIsError( void* _this, XBool aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateLastIsError(). */
#define _ApplicationDeviceClass__UpdateLastIsError_

/* 'C' function for method : 'Application::DeviceClass.OnGetCurrentOperation()' */
XString ApplicationDeviceClass_OnGetCurrentOperation( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetCurrentOperation()' */
void ApplicationDeviceClass_OnSetCurrentOperation( ApplicationDeviceClass _this, 
  XString value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateCurrentOperation( ApplicationDeviceClass _this, 
  XString aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateCurrentOperation()' */
void ApplicationDeviceClass__UpdateCurrentOperation( void* _this, XString aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateCurrentOperation(). */
#define _ApplicationDeviceClass__UpdateCurrentOperation_

/* 'C' function for method : 'Application::DeviceClass.OnGetOperationResult()' */
XString ApplicationDeviceClass_OnGetOperationResult( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetOperationResult()' */
void ApplicationDeviceClass_OnSetOperationResult( ApplicationDeviceClass _this, 
  XString value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateOperationResult( ApplicationDeviceClass _this, 
  XString aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateOperationResult()' */
void ApplicationDeviceClass__UpdateOperationResult( void* _this, XString aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateOperationResult(). */
#define _ApplicationDeviceClass__UpdateOperationResult_

/* 'C' function for method : 'Application::DeviceClass.OnGetFailureReason()' */
XString ApplicationDeviceClass_OnGetFailureReason( ApplicationDeviceClass _this );

/* 'C' function for method : 'Application::DeviceClass.OnSetFailureReason()' */
void ApplicationDeviceClass_OnSetFailureReason( ApplicationDeviceClass _this, XString 
  value );

/* This method is intended to be called by the device to notify the GUI application 
   about an alternation of its setting or state value. */
void ApplicationDeviceClass_UpdateFailureReason( ApplicationDeviceClass _this, XString 
  aNewValue );

/* Wrapper function for the non virtual method : 'Application::DeviceClass.UpdateFailureReason()' */
void ApplicationDeviceClass__UpdateFailureReason( void* _this, XString aNewValue );

/* The following define announces the presence of the method Application::DeviceClass.UpdateFailureReason(). */
#define _ApplicationDeviceClass__UpdateFailureReason_

#ifdef __cplusplus
  }
#endif

#endif /* _ApplicationDeviceClass_H */

/* Embedded Wizard */
