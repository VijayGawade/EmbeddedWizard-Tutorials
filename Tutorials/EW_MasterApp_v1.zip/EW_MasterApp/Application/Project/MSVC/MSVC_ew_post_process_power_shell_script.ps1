﻿#*******************************************************************************
#
# E M B E D D E D   W I Z A R D   P R O J E C T
#
#                                                Copyright (c) TARA Systems GmbH
#                                    written by Paul Banach and Manfred Schweyer
#
#
# PowerShell script for modification of the MSVCX project configuration file
# according to Embedded Wizard project settings (color format, screen
# orientation, generated source files)
#
#*******************************************************************************

# Folder in MSVC project for the Runtime Environment
$PrjFolderRte  = "RuntimeEnvironment"
# Folder in MSVC project for the Graphics Engine
$PrjFolderGfx  = "GraphicsEngine"
# Folder in MSVC project for the Generated Code
$PrjFolderEmWi = "GeneratedCode"


function addElement($e1, $name2, $value2, $attr2)
{
   #Write-Host "addElement" $name2 $value2  $attr2

  if ($e1.gettype().name -eq "XmlDocument") {
    $e2 = $e1.CreateElement($name2, $namespace)
  }else {
    $e2 = $e1.ownerDocument.CreateElement($name2, $namespace)
  }

  if ($attr2) {
    $e2.setAttribute($value2,$attr2)
  } elseif ($value2) {
    $e2.InnerText = "$value2"
  }

#  write-host "add" $e2.InnerText.ToString()
  return $e1.AppendChild($e2)
}

function formatXML([xml]$xml)
{
    $sb = New-Object System.Text.StringBuilder
    $sw = New-Object System.IO.StringWriter($sb)
    $wr = New-Object System.Xml.XmlTextWriter($sw)
    $wr.Formatting = [System.Xml.Formatting]::Indented
    $xml.Save($wr)
    return $sb.ToString()
}





# the window title
$host.ui.RawUI.WindowTitle = "Embedded Wizard Post Process - updating MSVC project configuration"
$executingScriptDirectory  = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# check for PowerShell version
$invalidPsVersion = 0
$psVersion        = $PSVersionTable.PSVersion
if ( $psVersion )
{
  Write-Host "PowerShell version: " $psVersion
  If($psVersion -lt '4.0') {
    $invalidPsVersion = 1;
  }
}
Else {
  Write-Host "No PowerShell Version found"
  $invalidPsVersion = 1;
}

if ( $invalidPsVersion ) {
  Write-Host This Embedded Wizard Post Process needs at least V4.0 of Windows Powershell
  Write-Host Powershell update can be found at:
  Write-Host https://docs.microsoft.com/de-de/powershell/scripting/setup/installing-windows-powershell
  [Environment]::Exit(10)
}

# get color format
$NewColorFormat = $env:EmWi_ColorFormat

# check, if requested color format is supported
$ppDir = Join-Path $executingScriptDirectory "../../../PlatformPackage/$NewColorFormat"
if ( -Not ( Test-Path -Path $ppDir ))
{
  Write-Host "Selected color format" $NewColorFormat "not supported!"
  [Environment]::Exit(8)
}


# get screen orientation
$ScreenOrientation     = $env:EmWi_SurfaceRotation
if ( $ScreenOrientation -eq 90 ) {
  $ScreenOrientation_ext = "-r90"
} elseif ( $ScreenOrientation -eq 180 ) {
  $ScreenOrientation_ext = "-r180"
} elseif ( $ScreenOrientation -eq 270 ) {
  $ScreenOrientation_ext = "-r270"
} else {
  $ScreenOrientation_ext = ""
}

# check for profesional version of Embedded Wizard Platform Package
$Path = Join-Path $executingScriptDirectory "../../../PlatformPackage/$NewColorFormat/ewgfx.c"
$UseLibaries = 1
if (Test-Path $path)
{
  $UseLibaries = 0
}


# modify MSVC project file
Write-Host "modifying MSVC project file ..."

$Path = Join-Path $executingScriptDirectory "./EmbeddedWizard-Windows.vcxproj"

if ( -Not ( Test-Path -Path $Path ))
{
  Write-Host MSVC project file not found at path:
  Write-Host $Path
  [Environment]::Exit(6)
}

# update color format
(Get-Content $Path).replace('RGBA8888', $NewColorFormat ) | Set-Content $Path
(Get-Content $Path).replace('RGBA4444', $NewColorFormat ) | Set-Content $Path
(Get-Content $Path).replace('RGB888', $NewColorFormat ) | Set-Content $Path
(Get-Content $Path).replace('RGB565', $NewColorFormat ) | Set-Content $Path
(Get-Content $Path).replace('LumA44', $NewColorFormat ) | Set-Content $Path
(Get-Content $Path).replace('Index8', $NewColorFormat ) | Set-Content $Path

# update screen orientation
(Get-Content $Path).replace('EW_SURFACE_ROTATION=0', 'EW_SURFACE_ROTATION=' + $ScreenOrientation ) | Set-Content $Path
(Get-Content $Path).replace('EW_SURFACE_ROTATION=90', 'EW_SURFACE_ROTATION=' + $ScreenOrientation ) | Set-Content $Path
(Get-Content $Path).replace('EW_SURFACE_ROTATION=180', 'EW_SURFACE_ROTATION=' + $ScreenOrientation ) | Set-Content $Path
(Get-Content $Path).replace('EW_SURFACE_ROTATION=270', 'EW_SURFACE_ROTATION=' + $ScreenOrientation ) | Set-Content $Path


$xml = [xml](get-content $Path)
if ( -Not $xml ) {
  Write-Host MSVC project file not found at path:
  Write-Host $Path
  [Environment]::Exit(6)
}

$namespace = $xml.DocumentElement.NamespaceURI


#create Namespace Manager
$ns = new-object Xml.XmlNamespaceManager $xml.NameTable
$ns.AddNamespace("ns", $namespace)

# remove all nodes with pattern
foreach($node in $xml.SelectNodes('//ns:ClCompile', $ns)) {
    Write-Output $password.OuterXml
  if ( $($node.OuterXml -match 'PlatformPackage') -or
       $($node.OuterXml -match $PrjFolderEmWi)) {
#    Write-Output $password.OuterXml
    $node.ParentNode.RemoveChild($node) | Out-Null
  }

  if ( $($node.OuterXml -match 'main')) {
    $srcNode = $node.ParentNode
  }
}


# remove all emwi libs
foreach($node in $xml.SelectNodes('//ns:Library', $ns)) {
    Write-Output $password.OuterXml
  if ( $($node.OuterXml -match 'PlatformPackage')) {
#    Write-Output $password.OuterXml
    $node.ParentNode.RemoveChild($node) | Out-Null
  }

  $libNode = $node.ParentNode
}



#select ClCompile node
#$node = $xml.SelectSingleNode("//msb:ItemGroup", $ns)
#write-host "---" $node.InnerXml



if ( -Not $srcNode ) {
  Write-Host source node not found in MSVC project file
  [Environment]::Exit(5)
}


if ( $UseLibaries ) {

  if ( -Not $libNode ) {
    $libNode = $srcNode
  }

  # add rte lib
  addElement $libNode "Library"   "Include" "..\..\..\PlatformPackage\RTE\libewrte-msvc.lib"
  addElement $libNode "Library"   "Include" "..\..\..\PlatformPackage\RTE\libewrte-msvc-x64.lib"
  addElement $srcNode "ClCompile"   "Include" "..\..\..\PlatformPackage\RTE\ewextrte.c"

  # add gfx lib
  addElement $libNode "Library" "Include" "..\..\..\PlatformPackage\$NewColorFormat\libewgfx$ScreenOrientation_ext-msvc.lib"
  addElement $libNode "Library" "Include" "..\..\..\PlatformPackage\$NewColorFormat\libewgfx$ScreenOrientation_ext-msvc-x64.lib"

} else
{
  # add platform package sources
  # add rte sources
  $RTESrcFiles = @("ewcolor.c", "ewdebug.c", "ewextrte.c", "ewobject.c", "ewpoint.c", "ewrect.c", "ewref.c", "ewresource.c", "ewscalars.c", "ewslot.c", "ewstring.c", "ewtimer.c", "ewheap.c", "ewinvocations.c" )
  foreach ($element in $RTESrcFiles) {
    addElement $srcNode "ClCompile" "Include" "..\..\..\PlatformPackage\RTE\$element"
  }

  # add gfx sources
  $GFX_SrcFiles = @("ewextbmp_$NewColorFormat.c", "ewextfnt.c", "ewextgfx.c", "ewextpxl_$NewColorFormat.c", "ewgfx.c", "ewgfxattrtext.c", "ewgfxcore.c", "ewgfxdriver.c", "ewgfxtasks.c", "ewgfxbidi.c", "ewextsvg.c", "ewgfxsvg.c" )
  foreach ($element in $GFX_SrcFiles) {
    addElement $srcNode "ClCompile" "Include" "..\..\..\PlatformPackage\$NewColorFormat\$element"
  }
}

# add generated source files
foreach ($element in ($env:EmWi_OutputSrcFiles -split '\s+')) {
  #Write-Host element $element
  if ($($element -like "*.c"  )) {
    addElement $srcNode "ClCompile" "Include" "..\..\$PrjFolderEmWi\$element"
  }
}


# Save and close MSVC configuration file
$xml.Save($Path)





# modify MSVC project filter file
Write-Host "modifying MSVC project filter file ..."

$Path = Join-Path $executingScriptDirectory "./EmbeddedWizard-Windows.vcxproj.filters"

if ( -Not ( Test-Path -Path $Path ))
{
  Write-Host MSVC project filter file not found at path:
  Write-Host $Path
  [Environment]::Exit(4)
}


$xml = [xml](get-content $Path)
if ( -Not $xml ) {
  Write-Host Cannot opten MSVC project filter file:
  Write-Host $Path
  [Environment]::Exit(4)
}

$namespace = $xml.DocumentElement.NamespaceURI

#create Namespace Manager
$ns = new-object Xml.XmlNamespaceManager $xml.NameTable
$ns.AddNamespace("ns", $namespace)


# remove all nodes with pattern
foreach($node in $xml.SelectNodes('//ns:ClCompile', $ns)) {
    Write-Output $password.OuterXml
  if ( $($node.OuterXml -match 'PlatformPackage') -or
       $($node.OuterXml -match $PrjFolderEmWi)) {
#    Write-Output $password.OuterXml
    $node.ParentNode.RemoveChild($node) | Out-Null
  }

  if ( $($node.OuterXml -match 'main')) {
    $srcNode = $node.ParentNode
  }
}


# remove all emwi libs
foreach($node in $xml.SelectNodes('//ns:Library', $ns)) {
    Write-Output $password.OuterXml
  if ( $($node.OuterXml -match 'PlatformPackage')) {
#    Write-Output $password.OuterXml
    $node.ParentNode.RemoveChild($node) | Out-Null
  }

  $libNode = $node.ParentNode
}


if ( -Not $srcNode ) {
  Write-Host "source node not found in MSVC project filter file"
  [Environment]::Exit(5)
}


if ( $UseLibaries ) {

  if ( -Not $libNode ) {
    $libNode = $srcNode
  }

  # add rte lib
  $element = addElement $libNode "Library"   "Include" "..\..\..\PlatformPackage\RTE\libewrte-msvc.lib"
  $element = addElement $element "Filter" $PrjFolderRte
  $element = addElement $srcNode "ClCompile"   "Include" "..\..\..\PlatformPackage\RTE\ewextrte.c"
  $element = addElement $element "Filter" $PrjFolderRte

  # add gfx lib
  $element = addElement $libNode "Library" "Include" "..\..\..\PlatformPackage\$NewColorFormat\libewgfx$ScreenOrientation_ext-msvc.lib"
  $element = addElement $element "Filter" $PrjFolderGfx

} else
{
  # add platform package sources
  # add rte sources
  $RTESrcFiles = @("ewcolor.c", "ewdebug.c", "ewextrte.c", "ewobject.c", "ewpoint.c", "ewrect.c", "ewref.c", "ewresource.c", "ewscalars.c", "ewslot.c", "ewstring.c", "ewtimer.c", "ewheap.c", "ewinvocations.c" )
  foreach ($element in $RTESrcFiles) {
    $element = addElement $srcNode "ClCompile" "Include" "..\..\..\PlatformPackage\RTE\$element"
    $element = addElement $element "Filter" $PrjFolderRte
  }

  # add gfx sources
  $GFX_SrcFiles = @("ewextbmp_$NewColorFormat.c", "ewextfnt.c", "ewextgfx.c", "ewextpxl_$NewColorFormat.c", "ewgfx.c", "ewgfxattrtext.c", "ewgfxcore.c", "ewgfxdriver.c", "ewgfxtasks.c", "ewgfxbidi.c", "ewextsvg.c", "ewgfxsvg.c"  )
  foreach ($element in $GFX_SrcFiles) {
    $element = addElement $srcNode "ClCompile" "Include" "..\..\..\PlatformPackage\$NewColorFormat\$element"
    $element = addElement $element "Filter" $PrjFolderGfx
  }
}

# add generated source files
foreach ($element in ($env:EmWi_OutputSrcFiles -split '\s+')) {
  #Write-Host element $element
  if ($($element -like "*.c"  )) {
    $element = addElement $srcNode "ClCompile" "Include" "..\..\$PrjFolderEmWi\$element"
    $element = addElement $element "Filter" $PrjFolderEmWi
  }
}

# Save and close MSVC configuration file
$xml.Save($Path)

Write-Host "Post process powershell script finished."


