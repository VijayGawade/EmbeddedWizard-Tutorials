::*******************************************************************************
::
:: E M B E D D E D   W I Z A R D   P R O J E C T
::
::                                                Copyright (c) TARA Systems GmbH
::                                    written by Paul Banach and Manfred Schweyer
::
::
:: Embedded Wizard Post Process script for automatic updating of the MSVC
:: project (color format, screen orientation, generated source files,
:: Embedded Wizard runtime environment libraries and source files.
:: Call this script from Embedded Wizard Studio. A Post Process can be set as
:: Profil parameter.
::
::*******************************************************************************

@echo off


::set EmWi_ColorFormat=RGBA8888
::set EmWi_SurfaceRotation=0
::set EmWi_OutputSrcFiles=Application.c Core.c DefaultClut.c Effects.c Graphics.c Resources.c Views.c

echo Embedded Wizard post processing (Embedded Wizard version: %EmWi_Version%)
::echo project:            %EmWi_ProjectFile%
::echo profile:            %EmWi_Profile%
::echo platform:           %EmWi_Platform%
::echo screen orientation: %EmWi_SurfaceRotation%
::echo screen size:        %EmWi_ScreenSize%
::echo.
::echo EmWi_ColorFormat = %EmWi_ColorFormat%
::echo EmWi_SurfaceRotation = %EmWi_SurfaceRotation%
::echo EmWi_OutputSrcFiles = %EmWi_OutputSrcFiles%

SET mypath=%~dp0
SET realativepath=%mypath:~0,-1%

:: Call a PowerShell script to modify the MPLABX project configuration file
PowerShell.exe -ExecutionPolicy Bypass -Command "& '%realativepath%\MSVC_ew_post_process_power_shell_script.ps1'"



if ERRORLEVEL == 10 (
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 echo This Embedded Wizard Post Process needs at least V4.0 of Windows Powershell
 echo Powershell update can be found at:
 echo https://docs.microsoft.com/de-de/powershell/scripting/setup/installing-windows-powershell
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 exit /B 1
)

if ERRORLEVEL == 8 (
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 echo The selected color format '%EmWi_ColorFormat%' is not supported!
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 exit /B 1
)

if ERRORLEVEL == 6 (
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 echo The MSVC project was not found!
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 exit /B 1
)

if ERRORLEVEL == 5 (
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 echo Error occured during modifcation of the MSVC project
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 exit /B 1
)

if ERRORLEVEL == 1 (
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 echo Unknown error occured during Embedded Wizard Post Process!
 echo !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 exit /B 1
)


exit /B 0
