#ifndef TRANSPORT_MANAGER_H
#define TRANSPORT_MANAGER_H

#include "protocol_codec.h"

#ifdef __cplusplus
extern "C" {
#endif

	typedef struct {
		CommProtocol_t protocol;
		PacketFormat_t format;
		bool           is_error;
		uint16_t       param_or_object_id;
		uint8_t        operation;
		uint8_t        source_node;
		char           current_op[64];
		char           result_msg[96];
		char           failure_msg[96];
		char           payload_str[FORMAT1_MAX_DATA_LEN + 1];
		char           raw_frame_log[256];
	} MasterRxEvent_t;

	bool Transport_Initialize(void);
	void Transport_Shutdown(void);

	bool Transport_Connect(
		CommProtocol_t protocol,
		PacketFormat_t format,
		const char* endpoint,
		uint32_t       baud_or_port
	);
	void Transport_Disconnect(void);
	bool Transport_IsConnected(void);

	bool Transport_SendFormat1Request(char op_char, uint16_t param_addr, const char* data_str);
	bool Transport_SendFormat2CanFrame(
		uint8_t        priority,
		uint8_t        operation,
		uint16_t       object_id,
		uint8_t        source_node,
		uint8_t        dest_node,
		const uint8_t* payload,
		uint8_t        dlc
	);

	bool Transport_PopRxEvent(MasterRxEvent_t* out_event);

#ifdef __cplusplus
}
#endif

#endif /* TRANSPORT_MANAGER_H */