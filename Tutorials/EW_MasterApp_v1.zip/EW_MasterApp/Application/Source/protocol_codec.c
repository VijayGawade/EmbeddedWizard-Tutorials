#include "protocol_codec.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* CRC-8-CCITT (Polynomial = 0x07, Initial Value = 0x00) */
uint8_t Codec_ComputeCRC8(const uint8_t* data, size_t length) {
    uint8_t crc = 0x00U;
    for (size_t i = 0; i < length; ++i) {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8U; ++bit) {
            if ((crc & 0x80U) != 0U) {
                crc = (uint8_t)((crc << 1U) ^ 0x07U);
            } else {
                crc <<= 1U;
            }
        }
    }
    return crc;
}

/* Builds Format 1 Frame: [?/!]:[aaaa]:[bb]:[ccc...ccc]:[dd]\r */
int Codec_Format1_Encode(const PacketFormat1_t* pkt, char* out_buf, size_t out_size) {
    if (!pkt || !out_buf || out_size < FORMAT1_MAX_FRAME_LEN) {
        return -1;
    }
    if (pkt->operation != '?' && pkt->operation != '!') {
        return -2;
    }

    size_t actual_data_len = strlen(pkt->data);
    if (actual_data_len > FORMAT1_MAX_DATA_LEN) {
        return -3;
    }

    char body[FORMAT1_MAX_FRAME_LEN];
    int body_len = snprintf(
        body,
        sizeof(body),
        "%c:%04X:%02X:%s",
        pkt->operation,
        (unsigned int)(pkt->param_address & 0xFFFFU),
        (unsigned int)(actual_data_len & 0xFFU),
        pkt->data
    );
    if (body_len < 0 || (size_t)body_len >= sizeof(body)) {
        return -4;
    }

    uint8_t crc = Codec_ComputeCRC8((const uint8_t*)body, (size_t)body_len);
    return snprintf(out_buf, out_size, "%s:%02X\r", body, (unsigned int)crc);
}

/* Parses and validates Format 1 Frame: !:[aaaa]:[bb]:[ccc...ccc]:[dd]\r */
bool Codec_Format1_Decode(const char* raw_frame, size_t raw_len, PacketFormat1_t* out_pkt) {
    if (!raw_frame || !out_pkt || raw_len < 13U) {
        return false;
    }

    char clean[FORMAT1_MAX_FRAME_LEN];
    if (raw_len >= sizeof(clean)) {
        return false;
    }
    memcpy(clean, raw_frame, raw_len);
    clean[raw_len] = '\0';

    while (raw_len > 0U && (clean[raw_len - 1U] == '\r' || clean[raw_len - 1U] == '\n')) {
        clean[--raw_len] = '\0';
    }

    /* Minimum valid frame without data is 13 chars: !:0000:00::00 */
    if (raw_len < 13U || clean[1] != ':' || clean[6] != ':' || clean[9] != ':') {
        return false;
    }

    char* last_colon = strrchr(clean, ':');
    if (!last_colon || last_colon < (clean + 9) || strlen(last_colon + 1) != 2U) {
        return false;
    }

    unsigned int rx_crc = 0U;
    if (sscanf(last_colon + 1, "%02X", &rx_crc) != 1) {
        return false;
    }

    size_t body_len = (size_t)(last_colon - clean);
    uint8_t calc_crc = Codec_ComputeCRC8((const uint8_t*)clean, body_len);
    if (calc_crc != (uint8_t)rx_crc) {
        return false;
    }

    char addr_str[5] = { clean[2], clean[3], clean[4], clean[5], '\0' };
    char len_str[3]  = { clean[7], clean[8], '\0' };
    unsigned int addr_val = 0U;
    unsigned int len_val  = 0U;

    if (sscanf(addr_str, "%04X", &addr_val) != 1 || sscanf(len_str, "%02X", &len_val) != 1) {
        return false;
    }

    size_t data_chars = (size_t)(last_colon - (clean + 10));
    if (data_chars != (size_t)len_val || data_chars > FORMAT1_MAX_DATA_LEN) {
        return false;
    }

    out_pkt->operation     = clean[0];
    out_pkt->param_address = (uint16_t)addr_val;
    out_pkt->data_length   = (uint8_t)len_val;
    memcpy(out_pkt->data, clean + 10, data_chars);
    out_pkt->data[data_chars] = '\0';
    out_pkt->crc8          = (uint8_t)rx_crc;
    return true;
}

/* Packs 29-Bit TF CAN Extended Identifier (Bits 28..0) */
uint32_t Codec_Format2_PackCanId(
    uint8_t  priority,
    uint8_t  operation,
    uint16_t object_id,
    uint8_t  source,
    uint8_t  destination
) {
    return ((uint32_t)(priority    & 0x07U)  << 26U) |
           ((uint32_t)(operation   & 0x07U)  << 23U) |
           ((uint32_t)(object_id   & 0x7FFU) << 12U) |
           ((uint32_t)(source      & 0x3FU)  << 6U)  |
           ((uint32_t)(destination & 0x3FU)  << 0U);
}

/* Unpacks 29-Bit TF CAN Extended Identifier (Bits 28..0) */
void Codec_Format2_UnpackCanId(uint32_t can_id_29bit, PacketFormat2_CAN_t* out_pkt) {
    if (!out_pkt) {
        return;
    }
    out_pkt->priority    = (uint8_t)((can_id_29bit >> 26U) & 0x07U);
    out_pkt->operation   = (uint8_t)((can_id_29bit >> 23U) & 0x07U);
    out_pkt->object_id   = (uint16_t)((can_id_29bit >> 12U) & 0x7FFU);
    out_pkt->source      = (uint8_t)((can_id_29bit >> 6U)  & 0x3FU);
    out_pkt->destination = (uint8_t)(can_id_29bit & 0x3FU);
}

/* Converts 29-Bit TF CAN Frame into SLCAN ASCII Frame: T<8-Hex-ID><1-Hex-DLC><Data>\r */
int Codec_Format2_ToAsciiHex(const PacketFormat2_CAN_t* pkt, char* out_buf, size_t out_size) {
    if (!pkt || !out_buf || out_size < 32U || pkt->dlc > 8U) {
        return -1;
    }
    uint32_t can_id = Codec_Format2_PackCanId(
        pkt->priority, pkt->operation, pkt->object_id, pkt->source, pkt->destination
    );
    int offset = snprintf(out_buf, out_size, "T%08X%1X", (unsigned int)can_id, (unsigned int)pkt->dlc);
    for (uint8_t i = 0; i < pkt->dlc; ++i) {
        offset += snprintf(out_buf + offset, out_size - (size_t)offset, "%02X", pkt->payload[i]);
    }
    offset += snprintf(out_buf + offset, out_size - (size_t)offset, "\r");
    return offset;
}

/* Parses SLCAN ASCII Frame T<8-Hex-ID><1-Hex-DLC><Data>\r into PacketFormat2_CAN_t */
bool Codec_Format2_FromAsciiHex(const char* ascii_line, PacketFormat2_CAN_t* out_pkt) {
    if (!ascii_line || !out_pkt || ascii_line[0] != 'T' || strlen(ascii_line) < 10U) {
        return false;
    }
    char id_str[9];
    memcpy(id_str, ascii_line + 1, 8);
    id_str[8] = '\0';

    uint32_t can_id = (uint32_t)strtoul(id_str, NULL, 16);
    uint8_t dlc = (uint8_t)(ascii_line[9] - '0');
    if (dlc > 8U || strlen(ascii_line + 10) < (size_t)(dlc * 2U)) {
        return false;
    }

    Codec_Format2_UnpackCanId(can_id, out_pkt);
    out_pkt->dlc = dlc;
    for (uint8_t i = 0; i < dlc; ++i) {
        unsigned int byte_val = 0U;
        if (sscanf(ascii_line + 10 + (i * 2), "%02X", &byte_val) != 1) {
            return false;
        }
        out_pkt->payload[i] = (uint8_t)byte_val;
    }
    return true;
}