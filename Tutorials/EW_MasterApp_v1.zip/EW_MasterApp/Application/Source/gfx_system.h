/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file is part of the interface (glue layer) between an Embedded Wizard
*   generated UI application and the graphics subsystem.
*
*   This template is responsible to access the grafics subsystem within an
*   embedded Linux environment. The display is accessed by using EGL via the
*   graphics subsystem (e.g. Wayland, DRM, X11 or fbdev).
*
*   Important: This file is intended to be used as a template. Please adapt the
*   implementation and declarations according your particular hardware.
*
*******************************************************************************/

#ifndef GFX_SYSTEM_H
#define GFX_SYSTEM_H

#define GFX_SYSTEM_UNKNOWN                       0
#define GFX_SYSTEM_WINDOWS                       1
#define GFX_SYSTEM_FBDEV                         2
#define GFX_SYSTEM_WAYLAND                       3
#define GFX_SYSTEM_DRM                           4


/******************************************************************************
* TYPE:
*   XGfxSystemInfo
*
* DESCRIPTION:
*   The structure XGfxSystemInfo contains information regarding the graphics 
*   system.
*
* ELEMENTS:
*   Type        - Type of Grahics System.
*   FrameBuffer - The Framebuffer.
*   Display     - The Display.
*   Surface     - The Surface.
*   Context     - The Context.
*
******************************************************************************/
typedef struct
{
  int     Type;
  void *  FrameBuffer;
  void *  Display;
  void *  Surface;
  void *  Context;
} XGfxSystemInfo;


#ifdef __cplusplus
  extern "C"
  {
#endif


/*******************************************************************************
* FUNCTION:
*   GfxSystemInit
*
* DESCRIPTION:
*   The function GfxSystemInit is responsible to get an access to the
*   graphics subsystem. In case that the underlying graphics subsystem contains
*   a window manager, the given size is used to create a suitable window.
*   Otherwise, the given size is ignored, because the size of the framebuffer
*   cannot be changed.
*
* ARGUMENTS:
*   NONE.
*
* RETURN VALUE:
*   Returns 1 if successful, 0 otherwise.
*
*******************************************************************************/
int GfxSystemInit
(
  void
);


/*******************************************************************************
* FUNCTION:
*   GfxSystemDone
*
* DESCRIPTION:
*   The function GfxSystemDone is responsible to close the access to the
*   graphics subsystem.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void GfxSystemDone( void );


/*******************************************************************************
* FUNCTION:
*   GfxSystemProcess
*
* DESCRIPTION:
*   The function GfxSystemProcess drives the graphics subsystem or window
*   manager in order to process all pending events.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   1, if further processing is needed, 0 otherwise.
*
*******************************************************************************/
int GfxSystemProcess( void );


/*******************************************************************************
* FUNCTION:
*   GfxSystemCreateSurface
*
* DESCRIPTION:
*   The function GfxSystemCreateSurface creates a graphic surface with the 
*   given dimensions.
*
* ARGUMENTS:
*   aWidth  - Required surface width.
*   aHeight - Required surface height.
*
* RETURN VALUE:
*   Returns 1, if native window could be created, otherwise 0.
*
*******************************************************************************/
int GfxSystemCreateSurface
(
  int aWidth,
  int aHeight
);


/*******************************************************************************
* FUNCTION:
*   GfxSystemUpdateSurface
*
* DESCRIPTION:
*   The function GfxSystemUpdateSurface updates the graphic surface.
*
* ARGUMENTS:
*   aX1  - Surface update area left.
*   aY1  - Surface update area topt.
*   aX2  - Surface update area right.
*   aY2  - Surface update area bottom.
*
* RETURN VALUE:
*   None.
*
*******************************************************************************/
void GfxSystemUpdateSurface
( 
  int aX1, 
  int aY1, 
  int aX2, 
  int aY2 
);


/*******************************************************************************
* FUNCTION:
*   GfxSystemGetInfo
*
* DESCRIPTION:
*   The function GfxSystemGetInfo returns the graphic system info struct.
*
* ARGUMENTS:
*   aGfxSystemInfo  - Pointer to return the graphic system info struct.
*
* RETURN VALUE:
*   None.
*
*******************************************************************************/
void GfxSystemGetInfo
( 
  XGfxSystemInfo* aGfxSystemInfo
);

#ifdef EW_BSP_TOUCH_H
/*******************************************************************************
* FUNCTION:
*   GfxSystemGetTouchEvents
*
* DESCRIPTION:
*   The function GfxSystemGetTouchEvents returns the current touch position and 
*   touch status of the different fingers. The returned number of touch events 
*   indicates the number of XTouchEvent that contain position and status 
*   information.
*   The orientation of the touch positions is adjusted to match GUI coordinates.
*   If the hardware supports only single touch, the finger number is always 0.
*
* ARGUMENTS:
*   aToucEvents  - Pointer to return array of XTouchEvent.
*
* RETURN VALUE:
*   Returns the number of available touch events.
*
*******************************************************************************/
int GfxSystemGetTouchEvents
( 
  XTouchEvent ** aToucEvents
);
#endif


#ifdef EW_BSP_CURSOR_H
/*******************************************************************************
* FUNCTION:
*   GfxSystemGetCursorEvent
*
* DESCRIPTION:
*   The function GfxSystemGetTouchState returns the current touch state and the
*   touch position.
*
* ARGUMENTS:
*   aCursorEvent  - Pointer to return the cursor event.
*
* RETURN VALUE:
*   Returns 1 in case of a valid cursor event, 0 otherwise.
*
*******************************************************************************/
int GfxSystemGetCursorEvent
( 
  XCursorEvent* aCursorEvent
);
#endif


#ifdef EW_BSP_KEYBOARD_H
/*******************************************************************************
* FUNCTION:
*   GfxSystemGetKeyboardEvent
*
* DESCRIPTION:
*   The function GfxSystemGetKeyboardEvent returns the latest keyboard event.
*
* ARGUMENTS:
*   aKeyboardEvent  - Pointer to return the keyboard event.
*
* RETURN VALUE:
*   Returns 1 in case of a valid keyboard event, 0 otherwise.
*
*******************************************************************************/
int GfxSystemGetKeyboardEvent
(
  XKeyboardEvent * aEvent
);
#endif


#ifdef __cplusplus
  }
#endif

#endif /* GFX_SYSTEM_H */


/* msy */
