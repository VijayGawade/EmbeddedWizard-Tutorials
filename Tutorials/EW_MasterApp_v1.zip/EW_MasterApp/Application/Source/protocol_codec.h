#ifndef PROTOCOL_CODEC_H
#define PROTOCOL_CODEC_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FORMAT1_MAX_DATA_LEN   128
#define FORMAT1_MAX_FRAME_LEN  160
#define TFCAN_MAX_PAYLOAD_LEN  8

/* Active Physical Communication Protocol */
typedef enum {
    PROTO_RS232             = 0,
    PROTO_RS485_FULL_DUPLEX = 1,
    PROTO_CAN               = 2,
    PROTO_REST_API          = 3
} CommProtocol_t;

/* Active Data Packet Framing Format */
typedef enum {
    PKT_FORMAT_1_ASCII      = 0,
    PKT_FORMAT_2_TFCAN      = 1
} PacketFormat_t;

/* Data Packet Format 1: [?/!]:[aaaa]:[bb]:[ccc...ccc]:[dd]\r */
typedef struct {
    char     operation;                        /* '?' = Read Request, '!' = Write Request / Slave Response */
    uint16_t param_address;                    /* 4-char hex parameter address [aaaa] (0x0000..0xFFFF) */
    uint8_t  data_length;                      /* 2-char hex payload length [bb] (0x00..0x80) */
    char     data[FORMAT1_MAX_DATA_LEN + 1];   /* Null-terminated ASCII payload [ccc...ccc] */
    uint8_t  crc8;                             /* 2-char hex CRC-8 checksum [dd] */
} PacketFormat1_t;

/* Data Packet Format 2: TF CAN 29-Bit Operation Codes (Bits 25..23) */
typedef enum {
    TFCAN_OP_READ     = 0,
    TFCAN_OP_WRITE    = 1,
    TFCAN_OP_RESPONSE = 2,
    TFCAN_OP_EVENT    = 3
} TfCanOperation_t;

/* Data Packet Format 2: Classic CAN 29-Bit Extended Frame */
typedef struct {
    uint8_t  priority;                         /* Bits 28..26 (3 bits: 0..7) */
    uint8_t  operation;                        /* Bits 25..23 (3 bits: 0..7) */
    uint16_t object_id;                        /* Bits 22..12 (11 bits: 0..2047) */
    uint8_t  source;                           /* Bits 11..6  (6 bits: 0..63) */
    uint8_t  destination;                      /* Bits 5..0   (6 bits: 0..63) */
    uint8_t  dlc;                              /* CAN payload length (0..8 bytes) */
    uint8_t  payload[TFCAN_MAX_PAYLOAD_LEN];   /* CAN data bytes */
} PacketFormat2_CAN_t;

/* CRC-8 Calculation (Polynomial 0x07, Initial 0x00) */
uint8_t  Codec_ComputeCRC8(const uint8_t* data, size_t length);

/* Packet Format 1 Encode & Decode */
int      Codec_Format1_Encode(const PacketFormat1_t* pkt, char* out_buf, size_t out_size);
bool     Codec_Format1_Decode(const char* raw_frame, size_t raw_len, PacketFormat1_t* out_pkt);

/* Packet Format 2 (29-Bit TF CAN) Pack, Unpack & ASCII SLCAN Helpers */
uint32_t Codec_Format2_PackCanId(uint8_t priority, uint8_t operation, uint16_t object_id, uint8_t source, uint8_t destination);
void     Codec_Format2_UnpackCanId(uint32_t can_id_29bit, PacketFormat2_CAN_t* out_pkt);
int      Codec_Format2_ToAsciiHex(const PacketFormat2_CAN_t* pkt, char* out_buf, size_t out_size);
bool     Codec_Format2_FromAsciiHex(const char* ascii_line, PacketFormat2_CAN_t* out_pkt);

#ifdef __cplusplus
}
#endif

#endif /* PROTOCOL_CODEC_H */