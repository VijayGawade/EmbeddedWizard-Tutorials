#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winhttp.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "transport_manager.h"

#pragma comment(lib, "winhttp.lib")

#define RX_QUEUE_CAPACITY 64

static CRITICAL_SECTION g_QueueLock;
static MasterRxEvent_t  g_RxQueue[RX_QUEUE_CAPACITY];
static size_t           g_QueueHead = 0;
static size_t           g_QueueTail = 0;
static size_t           g_QueueCount = 0;

static HANDLE           g_SerialHandle = INVALID_HANDLE_VALUE;
static HANDLE           g_WorkerThread = NULL;
static volatile LONG    g_Running = 0;
static bool             g_Connected = false;

static CommProtocol_t   g_ActiveProto = PROTO_RS232;
static PacketFormat_t   g_ActiveFormat = PKT_FORMAT_1_ASCII;
static char             g_Endpoint[128] = "127.0.0.1";
static uint32_t         g_BaudOrPort = 8080;
static char             g_LastOpDesc[64] = "IDLE";

static const char* GetProtoName(CommProtocol_t p) {
    switch (p) {
    case PROTO_RS232:             return "RS232";
    case PROTO_RS485_FULL_DUPLEX: return "RS485_FD";
    case PROTO_CAN:               return "CAN";
    case PROTO_REST_API:          return "RestAPI";
    default:                      return "UNKNOWN";
    }
}

static const char* GetFormatName(PacketFormat_t f) {
    return (f == PKT_FORMAT_1_ASCII) ? "Fmt1" : "Fmt2_CAN";
}

/* Writes timestamped log line to Windows Console and C:\EW_MasterApp\master_comm.log */
static void WriteLogToFileAndConsole(const MasterRxEvent_t* ev) {
    SYSTEMTIME st;
    GetLocalTime(&st);

    char log_line[512];
    snprintf(
        log_line,
        sizeof(log_line),
        "[%04d-%02d-%02d %02d:%02d:%02d.%03d] [%s/%s] OP=\"%s\" | RESULT=\"%s\" | FAILURE=\"%s\" | RAW=\"%s\"\n",
        st.wYear, st.wMonth, st.wDay,
        st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
        GetProtoName(ev->protocol),
        GetFormatName(ev->format),
        ev->current_op,
        ev->result_msg,
        ev->failure_msg,
        ev->raw_frame_log
    );

    /* Print to Embedded Wizard Windows Console */
    printf("%s", log_line);

    /* Append to persistent log file */
    FILE* fp = fopen("C:\\EW_MasterApp\\master_comm.log", "a");
    if (fp != NULL) {
        fputs(log_line, fp);
        fclose(fp);
    }
}

static void PushRxEvent(const MasterRxEvent_t* ev) {
    EnterCriticalSection(&g_QueueLock);
    WriteLogToFileAndConsole(ev);
    if (g_QueueCount < RX_QUEUE_CAPACITY) {
        g_RxQueue[g_QueueTail] = *ev;
        g_QueueTail = (g_QueueTail + 1U) % RX_QUEUE_CAPACITY;
        g_QueueCount++;
    }
    LeaveCriticalSection(&g_QueueLock);
}

static void PushStatusOrError(
    bool        is_error,
    uint16_t    addr_or_obj,
    const char* op_desc,
    const char* result_text,
    const char* failure_text,
    const char* payload_text,
    const char* raw_log
) {
    MasterRxEvent_t ev;
    memset(&ev, 0, sizeof(ev));
    ev.protocol = g_ActiveProto;
    ev.format = g_ActiveFormat;
    ev.is_error = is_error;
    ev.param_or_object_id = addr_or_obj;
    snprintf(ev.current_op, sizeof(ev.current_op), "%s", op_desc ? op_desc : g_LastOpDesc);
    snprintf(ev.result_msg, sizeof(ev.result_msg), "%s", result_text ? result_text : (is_error ? "FAILED" : "OK"));
    snprintf(ev.failure_msg, sizeof(ev.failure_msg), "%s", failure_text ? failure_text : (is_error ? "Unknown Error" : "NONE"));
    snprintf(ev.payload_str, sizeof(ev.payload_str), "%s", payload_text ? payload_text : "");
    snprintf(ev.raw_frame_log, sizeof(ev.raw_frame_log), "%s", raw_log ? raw_log : "");
    PushRxEvent(&ev);
}

static bool OpenWin32SerialPort(const char* port_name, uint32_t baud_rate, bool is_rs485_full_duplex) {
    char full_port_path[64];
    if (strncmp(port_name, "\\\\.\\", 4) == 0) {
        snprintf(full_port_path, sizeof(full_port_path), "%s", port_name);
    }
    else {
        snprintf(full_port_path, sizeof(full_port_path), "\\\\.\\%s", port_name);
    }

    g_SerialHandle = CreateFileA(
        full_port_path,
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        0,
        NULL
    );

    if (g_SerialHandle == INVALID_HANDLE_VALUE) {
        return false;
    }

    DCB dcb;
    SecureZeroMemory(&dcb, sizeof(DCB));
    dcb.DCBlength = sizeof(DCB);

    if (!GetCommState(g_SerialHandle, &dcb)) {
        CloseHandle(g_SerialHandle);
        g_SerialHandle = INVALID_HANDLE_VALUE;
        return false;
    }

    dcb.BaudRate = baud_rate;
    dcb.ByteSize = 8;
    dcb.Parity = NOPARITY;
    dcb.StopBits = ONESTOPBIT;
    dcb.fBinary = TRUE;
    dcb.fParity = FALSE;
    dcb.fOutxCtsFlow = FALSE;
    dcb.fOutxDsrFlow = FALSE;
    dcb.fOutX = FALSE;
    dcb.fInX = FALSE;
    dcb.fRtsControl = is_rs485_full_duplex ? RTS_CONTROL_DISABLE : RTS_CONTROL_ENABLE;
    dcb.fDtrControl = DTR_CONTROL_ENABLE;

    if (!SetCommState(g_SerialHandle, &dcb)) {
        CloseHandle(g_SerialHandle);
        g_SerialHandle = INVALID_HANDLE_VALUE;
        return false;
    }

    COMMTIMEOUTS timeouts = { 10, 1, 25, 1, 50 };
    SetCommTimeouts(g_SerialHandle, &timeouts);
    PurgeComm(g_SerialHandle, PURGE_RXCLEAR | PURGE_TXCLEAR);
    return true;
}

static void ProcessReceivedAsciiLine(const char* line_buf, size_t line_len) {
    char raw_log[256];
    snprintf(raw_log, sizeof(raw_log), "RX: %.*s", (int)line_len, line_buf);

    if (g_ActiveFormat == PKT_FORMAT_1_ASCII) {
        PacketFormat1_t pkt1;
        if (Codec_Format1_Decode(line_buf, line_len, &pkt1)) {
            char res_msg[96];
            snprintf(res_msg, sizeof(res_msg), "SUCCESS: Addr=0x%04X Data=%s (CRC=%02X OK)",
                pkt1.param_address, pkt1.data, pkt1.crc8);
            PushStatusOrError(false, pkt1.param_address, g_LastOpDesc, res_msg, "NONE", pkt1.data, raw_log);
        }
        else {
            PushStatusOrError(true, 0, g_LastOpDesc, "FAILED", "Format 1 CRC-8 or Frame Syntax Error", "ERR", raw_log);
        }
    }
    else {
        PacketFormat2_CAN_t pkt2;
        if (Codec_Format2_FromAsciiHex(line_buf, &pkt2)) {
            char payload_hex[64] = { 0 };
            int offset = 0;
            for (uint8_t i = 0; i < pkt2.dlc; ++i) {
                offset += snprintf(payload_hex + offset, sizeof(payload_hex) - (size_t)offset, "%02X ", pkt2.payload[i]);
            }
            char res_msg[96];
            snprintf(res_msg, sizeof(res_msg), "SUCCESS: CAN Obj=0x%03X Src=%u DLC=%u",
                pkt2.object_id, pkt2.source, pkt2.dlc);
            PushStatusOrError(false, pkt2.object_id, g_LastOpDesc, res_msg, "NONE", payload_hex, raw_log);
        }
        else {
            PushStatusOrError(true, 0, g_LastOpDesc, "FAILED", "Format 2 CAN Frame Decode Error", "ERR", raw_log);
        }
    }
}

static DWORD WINAPI TransportRxWorkerThread(LPVOID lpParam) {
    (void)lpParam;
    char rx_accum[FORMAT1_MAX_FRAME_LEN];
    size_t rx_pos = 0;

    while (InterlockedCompareExchange(&g_Running, 0, 0) != 0) {
        if (g_SerialHandle != INVALID_HANDLE_VALUE) {
            char byte_buf[32];
            DWORD bytes_read = 0;
            if (ReadFile(g_SerialHandle, byte_buf, sizeof(byte_buf), &bytes_read, NULL) && bytes_read > 0) {
                for (DWORD i = 0; i < bytes_read; ++i) {
                    char c = byte_buf[i];
                    if (c == '\r' || c == '\n') {
                        if (rx_pos > 0) {
                            rx_accum[rx_pos] = '\0';
                            ProcessReceivedAsciiLine(rx_accum, rx_pos);
                            rx_pos = 0;
                        }
                    }
                    else if (rx_pos < (sizeof(rx_accum) - 1U)) {
                        rx_accum[rx_pos++] = c;
                    }
                    else {
                        rx_pos = 0;
                    }
                }
            }
        }
        else {
            Sleep(20);
        }
    }
    return 0;
}

static bool SendViaWinHttpRestApi(const char* raw_packet_str) {
    wchar_t w_host[128];
    MultiByteToWideChar(CP_UTF8, 0, g_Endpoint, -1, w_host, 128);

    HINTERNET hSession = WinHttpOpen(
        L"EmbeddedWizard-MasterController/1.0",
        WINHTTP_ACCESS_TYPE_NO_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0
    );
    if (!hSession) {
        PushStatusOrError(true, 0, g_LastOpDesc, "FAILED", "WinHttpOpen Initialization Failed", "ERR", "WinHttpOpen=NULL");
        return false;
    }

    HINTERNET hConnect = WinHttpConnect(hSession, w_host, (INTERNET_PORT)g_BaudOrPort, 0);
    if (!hConnect) {
        WinHttpCloseHandle(hSession);
        PushStatusOrError(true, 0, g_LastOpDesc, "FAILED", "WinHttpConnect Failed (Invalid Host/Port)", "ERR", g_Endpoint);
        return false;
    }

    HINTERNET hRequest = WinHttpOpenRequest(
        hConnect, L"POST", L"/api/v1/packet", NULL,
        WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0
    );
    if (!hRequest) {
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        PushStatusOrError(true, 0, g_LastOpDesc, "FAILED", "WinHttpOpenRequest Failed", "ERR", "/api/v1/packet");
        return false;
    }

    char clean_pkt[FORMAT1_MAX_FRAME_LEN];
    snprintf(clean_pkt, sizeof(clean_pkt), "%s", raw_packet_str);
    size_t len = strlen(clean_pkt);
    if (len > 0 && clean_pkt[len - 1] == '\r') {
        clean_pkt[len - 1] = '\0';
    }

    char json_body[256];
    int json_len = snprintf(json_body, sizeof(json_body), "{\"format\":%d,\"packet\":\"%s\"}", (int)g_ActiveFormat, clean_pkt);

    LPCWSTR headers = L"Content-Type: application/json\r\n";
    BOOL bResults = WinHttpSendRequest(
        hRequest, headers, (DWORD)-1L, (LPVOID)json_body, (DWORD)json_len, (DWORD)json_len, 0
    );

    if (bResults) {
        bResults = WinHttpReceiveResponse(hRequest, NULL);
    }

    if (bResults) {
        char resp_buf[256] = { 0 };
        DWORD bytes_read = 0;
        if (WinHttpReadData(hRequest, resp_buf, sizeof(resp_buf) - 1, &bytes_read) && bytes_read > 0) {
            resp_buf[bytes_read] = '\0';
            ProcessReceivedAsciiLine(resp_buf, bytes_read);
        }
    }
    else {
        DWORD err_code = GetLastError();
        char fail_reason[96];
        snprintf(fail_reason, sizeof(fail_reason), "HTTP Request Failed (WinHTTP Error=%lu)", (unsigned long)err_code);
        PushStatusOrError(true, 0, g_LastOpDesc, "FAILED", fail_reason, "ERR", json_body);
    }

    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return bResults == TRUE;
}

bool Transport_Initialize(void) {
    InitializeCriticalSection(&g_QueueLock);
    g_QueueHead = 0;
    g_QueueTail = 0;
    g_QueueCount = 0;
    return true;
}

void Transport_Shutdown(void) {
    Transport_Disconnect();
    DeleteCriticalSection(&g_QueueLock);
}

bool Transport_Connect(CommProtocol_t protocol, PacketFormat_t format, const char* endpoint, uint32_t baud_or_port) {
    Transport_Disconnect();

    g_ActiveProto = protocol;
    g_ActiveFormat = format;
    snprintf(g_Endpoint, sizeof(g_Endpoint), "%s", endpoint ? endpoint : "127.0.0.1");
    g_BaudOrPort = baud_or_port;

    snprintf(g_LastOpDesc, sizeof(g_LastOpDesc), "CONNECT [%s/%s] %s:%u",
        GetProtoName(protocol), GetFormatName(format), g_Endpoint, (unsigned)baud_or_port);

    if (protocol != PROTO_REST_API) {
        bool is_rs485 = (protocol == PROTO_RS485_FULL_DUPLEX);
        if (!OpenWin32SerialPort(g_Endpoint, baud_or_port, is_rs485)) {
            DWORD err = GetLastError();
            char fail_msg[96];
            snprintf(fail_msg, sizeof(fail_msg), "CreateFileA Failed on %s (Win32 Error=%lu)", g_Endpoint, (unsigned long)err);
            PushStatusOrError(true, 0, g_LastOpDesc, "CONNECTION FAILED", fail_msg, "DISCONNECTED", g_Endpoint);
            return false;
        }
    }

    g_Connected = true;
    InterlockedExchange(&g_Running, 1);
    g_WorkerThread = CreateThread(NULL, 0, TransportRxWorkerThread, NULL, 0, NULL);

    PushStatusOrError(false, 0, g_LastOpDesc, "CONNECTED", "NONE", "ONLINE", g_Endpoint);
    return true;
}

void Transport_Disconnect(void) {
    InterlockedExchange(&g_Running, 0);
    if (g_WorkerThread != NULL) {
        WaitForSingleObject(g_WorkerThread, 500);
        CloseHandle(g_WorkerThread);
        g_WorkerThread = NULL;
    }
    if (g_SerialHandle != INVALID_HANDLE_VALUE) {
        CloseHandle(g_SerialHandle);
        g_SerialHandle = INVALID_HANDLE_VALUE;
    }
    if (g_Connected) {
        g_Connected = false;
        PushStatusOrError(false, 0, "DISCONNECT", "DISCONNECTED", "NONE", "OFFLINE", "Port Closed");
    }
}

bool Transport_IsConnected(void) {
    return g_Connected;
}

bool Transport_SendFormat1Request(char op_char, uint16_t param_addr, const char* data_str) {
    snprintf(g_LastOpDesc, sizeof(g_LastOpDesc), "%s [%s/Fmt1] Addr=0x%04X",
        (op_char == '!') ? "WRITE" : "READ", GetProtoName(g_ActiveProto), param_addr);

    if (!g_Connected) {
        PushStatusOrError(true, param_addr, g_LastOpDesc, "FAILED", "Transport Not Connected", "ERR", "TX Aborted");
        return false;
    }

    PacketFormat1_t pkt;
    memset(&pkt, 0, sizeof(pkt));
    pkt.operation = op_char;
    pkt.param_address = param_addr;
    snprintf(pkt.data, sizeof(pkt.data), "%s", data_str ? data_str : "");
    pkt.data_length = (uint8_t)strlen(pkt.data);

    char encoded[FORMAT1_MAX_FRAME_LEN];
    int len = Codec_Format1_Encode(&pkt, encoded, sizeof(encoded));
    if (len <= 0) {
        PushStatusOrError(true, param_addr, g_LastOpDesc, "FAILED", "Format 1 Frame Encode Error", "ERR", "Invalid Payload");
        return false;
    }

    if (g_ActiveProto == PROTO_REST_API) {
        return SendViaWinHttpRestApi(encoded);
    }

    if (g_SerialHandle != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        if (WriteFile(g_SerialHandle, encoded, (DWORD)len, &written, NULL) && (written == (DWORD)len)) {
            return true;
        }
        PushStatusOrError(true, param_addr, g_LastOpDesc, "FAILED", "Serial WriteFile Timeout/Error", "ERR", encoded);
    }
    return false;
}

bool Transport_SendFormat2CanFrame(
    uint8_t priority, uint8_t operation, uint16_t object_id,
    uint8_t source_node, uint8_t dest_node, const uint8_t* payload, uint8_t dlc
) {
    snprintf(g_LastOpDesc, sizeof(g_LastOpDesc), "CAN_%s [%s/Fmt2] Obj=0x%03X Dst=%u",
        (operation == 1) ? "WRITE" : "READ", GetProtoName(g_ActiveProto), object_id, dest_node);

    if (!g_Connected || dlc > 8U) {
        PushStatusOrError(true, object_id, g_LastOpDesc, "FAILED", "Transport Disconnected or Invalid DLC", "ERR", "TX Aborted");
        return false;
    }

    PacketFormat2_CAN_t pkt2;
    memset(&pkt2, 0, sizeof(pkt2));
    pkt2.priority = priority;
    pkt2.operation = operation;
    pkt2.object_id = object_id;
    pkt2.source = source_node;
    pkt2.destination = dest_node;
    pkt2.dlc = dlc;
    if (payload && dlc > 0U) {
        memcpy(pkt2.payload, payload, dlc);
    }

    char slcan_frame[64];
    int len = Codec_Format2_ToAsciiHex(&pkt2, slcan_frame, sizeof(slcan_frame));
    if (len <= 0) {
        PushStatusOrError(true, object_id, g_LastOpDesc, "FAILED", "Format 2 CAN Encode Error", "ERR", "Encode Error");
        return false;
    }

    if (g_ActiveProto == PROTO_REST_API) {
        return SendViaWinHttpRestApi(slcan_frame);
    }

    if (g_SerialHandle != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        if (WriteFile(g_SerialHandle, slcan_frame, (DWORD)len, &written, NULL) && (written == (DWORD)len)) {
            return true;
        }
        PushStatusOrError(true, object_id, g_LastOpDesc, "FAILED", "Serial WriteFile Timeout/Error", "ERR", slcan_frame);
    }
    return false;
}

bool Transport_PopRxEvent(MasterRxEvent_t* out_event) {
    bool has_item = false;
    EnterCriticalSection(&g_QueueLock);
    if (g_QueueCount > 0U && out_event != NULL) {
        *out_event = g_RxQueue[g_QueueHead];
        g_QueueHead = (g_QueueHead + 1U) % RX_QUEUE_CAPACITY;
        g_QueueCount--;
        has_item = true;
    }
    LeaveCriticalSection(&g_QueueLock);
    return has_item;
}