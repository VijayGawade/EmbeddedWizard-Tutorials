/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file implements a generic main() function for running Embedded Wizard
*   generated applications in the MS Windows environment. The main() function
*   initializes the Runtime Environment, creates an instance of the application
*   class and drives the message translation and screen updates.
*
*   In order to keep the main() function independent from the particular GUI
*   application, the application class and the screen size are taken from the
*   generated code. In this manner, it is not necessary to modify this file
*   when creating new GUI applications. Just set the attributes 'ScreenSize'
*   and 'ApplicationClass' of the profile in the Embedded Wizard Studio.
*
*   This program demonstrates how to integrate an application developed using
*   Chora and Mosaic class library with the MS Windows operating system.
*
*******************************************************************************/

#include "gfx_system.h"
#include "ewmain.h"
#include "ewrte.h"
#include "ew_bsp_console.h"

/* Exclude rarely-used stuff from Windows headers */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>


/* Under Win32 we need a separate console window for print outputs */
#if ( defined EW_PRINT_MEMORY_USAGE  || defined EW_PRINT_GFX_TASKS    ||         \
      defined EW_RUN_BENCHMARK_SHORT || defined EW_RUN_BENCHMARK_FULL ||         \
      defined EW_RUN_VERIFICATION ) && !defined EW_OPEN_CONSOLE
  #define EW_OPEN_CONSOLE
#endif


/* This is the main function of the MS Windows application */
int APIENTRY WinMain( HINSTANCE aInstance, HINSTANCE aPrevInstance,
  LPSTR aCmdLine, int aCmdShow )
{
  unsigned int stack;

  (void)( aInstance );
  (void)( aPrevInstance );
  (void)( aCmdLine );
  (void)( aCmdShow );

  /* determine the stack area and provide it to the Runtime Environmnet */
  EwSetStackAddressArea( &stack, (void*)((uintptr_t)&stack - EW_GUI_THREAD_STACK_SIZE ));

  #ifdef EW_OPEN_CONSOLE
    /* initialize console interface for debug messages */
    EwBspConsoleInit();
  #endif

  /* initialize the graphics subsystem */
  GfxSystemInit();

  /* initialize Embedded Wizard application */
  if (EwInit() != 0)
  {
    EwPrintSystemInfo();

    /* process the graphics subsystem and the Embedded Wizard main loop */
    while (GfxSystemProcess() && EwProcess())
      ;

    /* de-initialize Embedded Wizard application */
    EwDone();
  }

  /* de-initialize graphics subsystem */
  GfxSystemDone();

  /* restore console */
  EwBspConsoleDone();

  /* return the exit-code of the viewer */
  return 0; // msg.wParam;
}

/* pba, mli */
