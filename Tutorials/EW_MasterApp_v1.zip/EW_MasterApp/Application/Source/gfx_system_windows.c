/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file implements a generic 'glue' interface to integrate Embedded Wizard
*   generated GUI applications with the MS Windows environment by using the
*   Windows DIB as framebuffer.
*
*   This interface simplifies the creation of and working with the console and
*   the viewer windows. It translates MS Windows messages and drives the screen
*   update. This interface is called directly from WinMain().
*
*   These functions are implemented for the convenience only - they hide the
*   complexity of the underlying Win32 environment only.
*
*******************************************************************************/

#include "ewrte.h"
#include "ewgfx.h"
#include "ew_bsp_display.h"
#include "ew_bsp_keyboard.h"
#include "ew_bsp_cursor.h"
#include "ew_bsp_touch.h"
#include "gfx_system.h"
#include "Core.h"

/* Exclude rarely-used stuff from Windows headers */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

/* Undo the macro overloading of following functions */
#undef EwOpenViewer

/* Error messages */
static const char* Err02 = "Viewer window creation failed";
static const char* Err03 = "Out of memory to create framebuffer";

/* Viewer */
static HWND        Viewer              = 0;
static XPoint      ViewerSize          = { 0, 0 };
static XDib*       FrameBuffer         = 0;

/* Keyboard */
static WPARAM      GfxKeyCode          = 0;
static int         GfxKeyEvent         = EW_BSP_KEY_EVENT_IDLE;
static int         GfxKeyState         = 0;

/* Cursor (Mouse) */
/* Saves the cursor position when the WM_LBUTTONUP message is arrived. The
   CursorButton variable stores the number of the currently pressed mouse
   button (0-left, 1-right, 2-middle) */
static XPoint      LastCursorPos;
static int         CursorButton        = -1;
static int         GfxCursorEvent      = EW_BSP_CURSOR_EVENT_IDLE;

/* Touch Screen */
#define GFX_SYSTEM_MAX_NB_OF_TOUCH_EVENTS 20
#define GFX_SYSTEM_MAX_NB_OF_FINGERS      10
#define GFX_SYSTEM_MAX_TICKS_MULTI_TAP    500
#define GFX_SYSTEM_MAX_TICKS_TERM_TOUCH   500

/* Status variables used by track touch events and associated them to
   finger numbers 0 .. 9 */
static int         TouchCount          = 0;
static DWORD       LastTouchTime       = 0;
static int         NbOfTouchEvents     = 0;
static XTouchEvent TouchEvents[ GFX_SYSTEM_MAX_NB_OF_TOUCH_EVENTS ];

#if WINVER >= 0x0601
static int         TouchDown [ GFX_SYSTEM_MAX_NB_OF_FINGERS] = { 0 };
static DWORD       TouchIDs  [ GFX_SYSTEM_MAX_NB_OF_FINGERS];
static XPoint      TouchPos  [ GFX_SYSTEM_MAX_NB_OF_FINGERS];
static DWORD       TouchTicks[ GFX_SYSTEM_MAX_NB_OF_FINGERS] = { 0 };
#endif

/* The following mode determines how images are stored within the surface pixel
   memory. This setting should always reflect the orientation of the display in
   your device in relation to the orientation of the framebuffer itself. If not
   explicitly specified, assume that all surfaces store the images in their
   natural, not rotated orientation. The mode is expressed in degree. */
#ifndef EW_SURFACE_ROTATION
  #define EW_SURFACE_ROTATION  0
#endif


/* The following helper function reserves memory for a new Windows DIB and
   returns it covered in a XDib structure. The returned Dib is used then as
   a framebuffer */
static XDib* CreateDib( int aW, int aH )
{
  XDib*             dib   = malloc( sizeof( XDib ));
  DWORD             size  = (((( aW * 24 ) + 31 ) & ~31 ) >> 3 ) * aH;
  BITMAPINFOHEADER* header;
  BYTE*             pixel;

  /* check given parameter */
  if (( aW <= 0 ) || ( aH <= 0 ))
    return 0;

  /* create bitmapinfo without a color table and reserve memory for the
     pixel data */
  header = GlobalAlloc( GMEM_FIXED, sizeof( *header ));
  pixel  = GlobalAlloc( GMEM_FIXED, size );

  /* No memory to create the dib */
  if ( !dib || !header || !pixel )
  {
    if ( dib    ) free( dib );
    if ( header ) GlobalFree( header );
    if ( pixel  ) GlobalFree( pixel  );

    return 0;
  }

  /* set parameter in bitmapinfoheader */
  header->biSize        = sizeof( BITMAPINFOHEADER );
  header->biWidth       = aW;
  header->biHeight      = aH;
  header->biPlanes      = 1;
  header->biBitCount    = 24;
  header->biClrUsed     = 0;
  header->biCompression = BI_RGB;
  header->biSizeImage   = size;

  /* clear created pixel area */
  EwZero( pixel, size );

  dib->Width  = aW;
  dib->Height = aH;
  dib->Header = header;
  dib->Pixel  = pixel;
  dib->Alpha  = 0;

  return dib;
}


/* The following helper function frees the given Windows DIB, releases the
   used pixel memory, etc. */
static void DestroyDib( XDib* aDib )
{
  if ( !aDib )
    return;

  if ( aDib->Header ) GlobalFree( aDib->Header );
  if ( aDib->Pixel  ) GlobalFree( aDib->Pixel  );

  aDib->Header = 0;
  aDib->Pixel  = 0;
  aDib->Alpha  = 0;

  free( aDib );
}


#if WINVER >= 0x0602
/* Helper function to prepare the touch event list */
static void GfxSystemAddTouchEvent( int aEvent, int aFinger, int aX, int aY )
{
  XTouchEvent* tochEvent;

  if ( NbOfTouchEvents >= GFX_SYSTEM_MAX_NB_OF_TOUCH_EVENTS )
    return;

  #ifdef EW_PRINT_TOUCH_DATA
  EwPrint( "AddTouchEvent: finger %d, x %d, y %d, event %d\n", aFinger, aX, aY, aEvent );
  #endif

  tochEvent = &TouchEvents[ NbOfTouchEvents++ ];
  tochEvent->Finger = aFinger;
  tochEvent->XPos   = aX;
  tochEvent->YPos   = aY;
  tochEvent->State  = aEvent;

  #ifdef EW_PRINT_TOUCH_EVENTS
  EwPrint( "Touch event for finger %d with state %d ( %4d, %4d )\n",
    tochEvent->Finger, tochEvent->State, tochEvent->XPos, tochEvent->YPos );
  #endif

}
#endif


/* Message handler for the viewer window. */
static LRESULT CALLBACK WindowProc( HWND aWindow, UINT aMsg, WPARAM aWParam,
  LPARAM aLParam )
{
  //EwPrint("Msg: %d\n", aMsg);

  /* What is happend? */
  switch ( aMsg )
  {
    case WM_QUIT :
    EwPrint("WM_QUIT\n");
    break;
    /* The F10 key needs a special handling - in this case the following case
       WM_KEYDOWN is executed */
    case WM_SYSKEYDOWN :
    {
      /* React to Alt+F4 --> terminates the application */
      if (( aWParam == VK_F4 ) && ( GetKeyState( VK_CONTROL ) >= 0 ) &&
          ( GetKeyState( VK_SHIFT ) >= 0 ) && ( GetKeyState( VK_MENU ) < 0 ))
        PostQuitMessage( 0 );

      if ( aWParam != VK_F10 )
        break;
    }

    /* In response to the WM_KEYDOWN message create a key down event. */
    case WM_KEYDOWN :
    {
      GfxKeyCode  = aWParam;
      GfxKeyEvent = EW_BSP_KEY_EVENT_DOWN;
      GfxKeyState = 0;
      if ( GetKeyState( VK_CONTROL ) < 0 )
        GfxKeyState |= EW_BSP_KEY_STATE_CTRL;
      if ( GetKeyState( VK_SHIFT ) < 0 )
        GfxKeyState |= EW_BSP_KEY_STATE_SHIFT;
      if ( GetKeyState( VK_MENU ) < 0 )
        GfxKeyState |= EW_BSP_KEY_STATE_ALT;
    }
    break;

    /* If the application window loses the input focus,
       create a key up event, if a key is still pressed. */
    case WM_KILLFOCUS :
    {
      if ( GfxKeyCode != 0 )
        GfxKeyEvent = EW_BSP_KEY_EVENT_UP;
    }
    break;

    /* In response to the WM_KEYUP message create a key up event. */
    case WM_SYSKEYUP :
    case WM_KEYUP :
    {
      GfxKeyCode  = aWParam;
      GfxKeyEvent = EW_BSP_KEY_EVENT_UP;
    }
    break;

    /* In response to the WM_CHAR message pass the code of the pressed
       character to the application */
    case WM_CHAR :
    {
      /* Cover the character code within an event object and pass it to the
         application */
      if ( aWParam >= 0x20 )
      {
        GfxKeyCode  = aWParam;
        GfxKeyEvent = EW_BSP_KEY_EVENT_CHAR;
      }
    }
    break;

    /* In response to the mouse-button down message a cursor-down event
       should be processed by the application */
    case WM_LBUTTONDOWN :
    case WM_MBUTTONDOWN :
    case WM_RBUTTONDOWN :
    {
      int cbn = ( aMsg - WM_LBUTTONDOWN ) / 3;

      /* As long as the mouse button is not pressed and the application is
         actually not controlled by touch screen. Note, Windows seems to report
         mouse messages shortly after a touch event is finished. Therefore we
         suppress the processing of those messages if generated shortly (less
         than 500 ms) after the touch event. */
      if ( !TouchCount && /*( CursorButton == -1 ) &&*/
         (( GetTickCount() - LastTouchTime ) > GFX_SYSTEM_MAX_TICKS_TERM_TOUCH ))
      {
        SetCapture( aWindow );
        GfxCursorEvent = EW_BSP_CURSOR_EVENT_BUTTON_PRESSED;

        /* Remember, the number of the pressed mouse button */
        CursorButton = cbn;
      }
    }
    break;

    /* In response to the mouse-button up message the mouse capture is
       released */
    case WM_LBUTTONUP :
    case WM_RBUTTONUP :
    case WM_MBUTTONUP :
    {
      int x = (short)LOWORD( aLParam ) + GetScrollPos( Viewer, SB_HORZ );
      int y = (short)HIWORD( aLParam ) + GetScrollPos( Viewer, SB_VERT );

      #if EW_SURFACE_ROTATION == 90
        int xx = x;
        x = y;
        y = ViewerSize.X - xx - 1;
      #endif

      #if EW_SURFACE_ROTATION == 180
        x = ViewerSize.X - x - 1;
        y = ViewerSize.Y - y - 1;
      #endif

      #if EW_SURFACE_ROTATION == 270
        int xx = x;
        x = ViewerSize.Y - y - 1;
        y = xx;
      #endif

      /* As long as the user releases the previously pressed mouse button and the
         application is actually not controlled by touch screen. */
      if ( !TouchCount /*&& ( CursorButton == (int)(( aMsg - WM_LBUTTONUP ) / 3 ))*/)
      {
        LastCursorPos.X = x;
        LastCursorPos.Y = y;
        ReleaseCapture();
        CursorButton = ( aMsg - WM_LBUTTONUP ) / 3;
        GfxCursorEvent = EW_BSP_CURSOR_EVENT_BUTTON_RELEASED;
      }
    }
    break;

    /* In response to the capture-loose message a cursor-up event
       should be processed by the application */
    case WM_CAPTURECHANGED :
    {
#if 0
      /* Only if the application is actually not controlled by touch screen. */
      if ( !TouchCount )
        GfxCursorEvent = EW_BSP_CURSOR_EVENT_BUTTON_RELEASED;
#endif
    }
    break;

    /* In response to the move-mouse message a drag event should be
       processed by the application */
    case WM_MOUSEMOVE :
    {
      int x = (short)LOWORD( aLParam ) + GetScrollPos( Viewer, SB_HORZ );
      int y = (short)HIWORD( aLParam ) + GetScrollPos( Viewer, SB_VERT );

      #if EW_SURFACE_ROTATION == 90
        int xx = x;
        x = y;
        y = ViewerSize.X - xx - 1;
      #endif

      #if EW_SURFACE_ROTATION == 180
        x = ViewerSize.X - x - 1;
        y = ViewerSize.Y - y - 1;
      #endif

      #if EW_SURFACE_ROTATION == 270
        int xx = x;
        x = ViewerSize.Y - y - 1;
        y = xx;
      #endif

      /* As long as the application is actually not controlled by touch
         screen. */
      if ( !TouchCount )
      {
        LastCursorPos.X = x;
        LastCursorPos.Y = y;
        GfxCursorEvent = EW_BSP_CURSOR_EVENT_MOVE;
      }
    }
    break;


    /* Handle dedicated touch events if the device provides them */
  #if WINVER >= 0x0602
    case WM_TOUCH :
    {
      int         count   = LOWORD( aWParam );
      DWORD       time    = GetTickCount();
      TOUCHINPUT* inputs  = 0;
      int         i, j;

      /* Touch and mouse interactions are handled exclusively. Thus, only
         if no mouse button pressed. */
      if ( CursorButton < 0 )
        inputs = malloc( sizeof( TOUCHINPUT ) * count );

      /* Try to obtain the collected touch events. */
      if ( inputs && !GetTouchInputInfo((HTOUCHINPUT)aLParam, count,
                       inputs, sizeof( TOUCHINPUT )))
      {
        free( inputs );
        inputs = 0;
      }

      /* Track the timestamp of the latest processed touch event. It is used
         to temporarily supress mouse events */
      if ( inputs )
        LastTouchTime = time;

      /* Process the collected touch events */
      if ( inputs )
        for ( i = 0; i < count; i++ )
        {
          TOUCHINPUT ti     = inputs[i];
          int        finger = -1;
          POINT      pos;
          XRect      area;

          #ifdef EW_PRINT_TOUCH_DATA
          EwPrint( "Raw touch data: id %d, x %d, y %d, flags 0x04X\n", ti.dwID, ti.x, ti.y, ti.dwFlags);
          #endif

          /* Get the coordinates of the corresponding event */
          pos.x = TOUCH_COORD_TO_PIXEL( ti.x );
          pos.y = TOUCH_COORD_TO_PIXEL( ti.y );
          ScreenToClient( aWindow, &pos );
          pos.x += GetScrollPos( Viewer, SB_HORZ );
          pos.y += GetScrollPos( Viewer, SB_VERT );

          #if EW_SURFACE_ROTATION == 90
          {
            int xx = pos.x;
            pos.x  = pos.y;
            pos.y  = ViewerSize.X - xx - 1;
          }
          #endif

          #if EW_SURFACE_ROTATION == 180
            pos.x = ViewerSize.X - pos.x - 1;
            pos.y = ViewerSize.Y - pos.y - 1;
          #endif

          #if EW_SURFACE_ROTATION == 270
          {
            int xx = pos.x;
            pos.x  = ViewerSize.Y - pos.y - 1;
            pos.y  = xx;
          }
          #endif

          #ifdef EW_PRINT_TOUCH_DATA
          EwPrint( "GUI coordinates: x %d, y %d\n", pos.x, pos.y );
          #endif

          /* An area around the finger position */
          area = EwNewRect( pos.x - 16, pos.y - 16, pos.x + 32, pos.y + 32 );

          /* Track the id numbers provided with the events and map them to
             finger numbers in range 0 .. 9. Doing this try to assign the same
             numbers to fingers recognized recently. This is essential to track
             double/tripple-taps. */
          for ( j = 0; j < GFX_SYSTEM_MAX_NB_OF_FINGERS; j++ )
          {
            if ( TouchDown[j] )
            {
              /* The touch event is actually active */
              if ( TouchIDs[j] == ti.dwID )
              {
                finger = j;
                break;
              }
            }
            else /* TouchDown[ j ] == 0 */
            {
              /* The touch event corresponds to a recently released finger. */
              if ( EwIsPointInRect( area, TouchPos[ j ] ) &&
                (( time - TouchTicks[ j ] ) < GFX_SYSTEM_MAX_TICKS_TERM_TOUCH ))
                finger = j;

              if ( finger < 0 )
                finger = j;
            }
          }

          if ( finger != -1 )
          {
            TouchTicks[ finger ]  = time;
            TouchPos[ finger ].X  = pos.x;
            TouchPos[ finger ].Y  = pos.y;

            if ( !TouchDown[ finger ] )
            {
              /* The user is performing a DOWN event? */
              if ( ti.dwFlags & TOUCHEVENTF_DOWN )
              {
                TouchDown[ finger ] = 1;
                TouchIDs [ finger ] = ti.dwID;
                TouchCount++;
                GfxSystemAddTouchEvent( EW_BSP_TOUCH_DOWN, finger, pos.x, pos.y );
              }
            }
            else /* TouchDown[ finger ] == 1 */
            {
              /* The user is performing a MOVE operation? */
              if ( ti.dwFlags & TOUCHEVENTF_MOVE )
              {
                GfxSystemAddTouchEvent( EW_BSP_TOUCH_MOVE, finger, pos.x, pos.y );
              }

              /* The user has finalized the interaction? */
              if ( ti.dwFlags & TOUCHEVENTF_UP )
              {
                TouchDown[ finger ]    = 0;
                TouchCount--;
                GfxSystemAddTouchEvent( EW_BSP_TOUCH_UP, finger, pos.x, pos.y );
              }
            }
          }
        }

      /* We were able to process touch events. Release the used resources */
      if ( inputs )
      {
        free( inputs );
        CloseTouchInputHandle((HTOUCHINPUT)aLParam );
      }

      /* ... otherwise give the default implementation a chance to do this. */
      else
        return DefWindowProcA( aWindow, aMsg, aWParam, aLParam );
    }
    break;
  #endif

    /* In response to the WM_PAINT event we redraw the invalid part of the screen */
    case WM_PAINT :
    {
      PAINTSTRUCT paintStruct;
      HDC         dc = BeginPaint( aWindow, &paintStruct );
      POINT       pos;

      /* Get the current scroll position and adjust the drawing context */
      pos.x = GetScrollPos( Viewer, SB_HORZ );
      pos.y = GetScrollPos( Viewer, SB_VERT );
      OffsetWindowOrgEx( dc, pos.x, pos.y, 0 );

      /* Map the framebuffer pixel from the DIB into the window context */
      if ( FrameBuffer )
        SetDIBitsToDevice( dc, 0, 0, FrameBuffer->Width, FrameBuffer->Height,
          0, 0, 0, FrameBuffer->Height, FrameBuffer->Pixel,
          (BITMAPINFO*)FrameBuffer->Header, DIB_RGB_COLORS );

      EndPaint( aWindow, &paintStruct );
    }
    break;

    /* Let the viewer erase the background - otherwise we get a lot of flickers */
    case WM_ERASEBKGND :
    {
      return TRUE;
    }
    break;

    /* Ensure, the size of the viewer window doesn't exceed the given framebuffer
       size */
    case WM_GETMINMAXINFO :
    {
      DWORD       style   = WS_OVERLAPPEDWINDOW;
      DWORD       exStyle = WS_EX_CLIENTEDGE;
      MINMAXINFO* mmi     = (MINMAXINFO*)aLParam;
      RECT        rect;
      SIZE        size;

      /* Which is the desired size of the window in order to show the entire
         framebuffer? */
      rect.left   = 0;
      rect.top    = 0;
      rect.right  = ViewerSize.X;
      rect.bottom = ViewerSize.Y;
      AdjustWindowRectEx( &rect, style, 0, exStyle );
      size.cx     = rect.right  - rect.left;
      size.cy     = rect.bottom - rect.top;

      /* Limit the window size to the calculated max. size ... */
      if ( mmi->ptMaxSize.x > size.cx )      mmi->ptMaxSize.x = size.cx + 16;
      if ( mmi->ptMaxSize.y > size.cy )      mmi->ptMaxSize.y = size.cy + 16;
      if ( mmi->ptMaxTrackSize.x > size.cx ) mmi->ptMaxTrackSize.x = size.cx;
      if ( mmi->ptMaxTrackSize.y > size.cy ) mmi->ptMaxTrackSize.y = size.cy;
    }
    break;

    /* In response to WM_SIZE adjust the scrollbars */
    case WM_SIZE :
    {
      SIZE       client;
      SCROLLINFO si;
      static int lock = 0;

      /* Avoid recursive execution of WM_SIZE message when scrollbars are
         shown/hidden */
      if ( lock )
        break;

      lock++;

      /* What size has the current client area of the window and the size of
         framebuffer? */
      client.cx = LOWORD( aLParam );
      client.cy = HIWORD( aLParam );

      /* In the following steps ignore the evtl. visible scrollbars */
      if ( GetWindowLong( aWindow, GWL_STYLE ) & WS_HSCROLL )
        client.cx += GetSystemMetrics( SM_CXVSCROLL );

      if ( GetWindowLong( aWindow, GWL_STYLE ) & WS_VSCROLL )
        client.cy += GetSystemMetrics( SM_CYHSCROLL );

      /* Test, whether it is possible to show the entire freamebuffer within
         the client area without the visible scrollbars. If not, reduce the
         client area by the space needed for the both scrollbars */
      if (( client.cx < ViewerSize.X ) || ( client.cy < ViewerSize.Y ))
      {
        client.cx -= GetSystemMetrics( SM_CXVSCROLL );
        client.cy -= GetSystemMetrics( SM_CYHSCROLL );
      }

      /* Prepare the initialization of the H-Scrollbar */
      memset( &si, 0, sizeof( si ));
      si.cbSize = sizeof( si );
      si.fMask  = SIF_PAGE | SIF_RANGE;
      si.nMin   = 0;
      si.nMax   = ViewerSize.X - 1;
      si.nPage  = client.cx;
      SetScrollInfo( aWindow, SB_HORZ, &si, TRUE );

      /* Prepare the initialization of the H-Scrollbar */
      memset( &si, 0, sizeof( si ));
      si.cbSize = sizeof( si );
      si.fMask  = SIF_PAGE | SIF_RANGE;
      si.nMin   = 0;
      si.nMax   = ViewerSize.Y - 1;
      si.nPage  = client.cy;
      SetScrollInfo( aWindow, SB_VERT, &si, TRUE );

      lock--;
    }
    break;

    /* React to horizontal scrollbar interactions */
    case WM_HSCROLL :
    {
      RECT  client;
      int   size;
      int   pos;
      int   offset;

      /* Get the current client area and the scroll position */
      GetClientRect( aWindow, &client );
      pos  = GetScrollPos( aWindow, SB_HORZ );
      size = ViewerSize.X;

      /* What is the user doing with the scrollbar? */
      switch ( LOWORD( aWParam ))
      {
        case SB_TOP        : pos  = 0;  break;
        case SB_LINEUP     : pos -= 32; break;
        case SB_LINEDOWN   : pos += 32; break;
        case SB_BOTTOM     : pos  = size; break;
        case SB_THUMBTRACK : pos  = HIWORD( aWParam ); break;
        case SB_PAGEUP     : pos -= client.right - client.left; break;
        case SB_PAGEDOWN   : pos += client.right - client.left; break;
      }

      /* The max. scroll range */
      size -= client.right - client.left;

      /* Limit to the size of the framebuffer */
      if ( pos < 0    ) pos = 0;
      if ( pos > size ) pos = size;

      /* Calculate the scroll distance */
      offset = GetScrollPos( aWindow, SB_HORZ ) - pos;

      /* Adjust the client content of the window */
      if ( offset )
        ScrollWindow( aWindow, offset, 0, 0, 0 );

      /* At fin adapt the scrollbar to reflect the new position */
      SetScrollPos( aWindow, SB_HORZ, pos, TRUE );
    }
    break;

    /* React to vertical scrollbar interactions */
    case WM_VSCROLL :
    {
      RECT  client;
      int   size;
      int   pos;
      int   offset;

      /* Get the current client area and the scroll position */
      GetClientRect( aWindow, &client );
      pos  = GetScrollPos( aWindow, SB_VERT );
      size = ViewerSize.Y;

      /* What is the user doing with the scrollbar? */
      switch ( LOWORD( aWParam ))
      {
        case SB_TOP        : pos  = 0;  break;
        case SB_LINEUP     : pos -= 32; break;
        case SB_LINEDOWN   : pos += 32; break;
        case SB_BOTTOM     : pos  = size; break;
        case SB_THUMBTRACK : pos  = HIWORD( aWParam ); break;
        case SB_PAGEUP     : pos -= client.bottom - client.top; break;
        case SB_PAGEDOWN   : pos += client.bottom - client.top; break;
      }

      /* The max. scroll range */
      size -= client.bottom - client.top;

      /* Limit to the size of the framebuffer */
      if ( pos < 0    ) pos = 0;
      if ( pos > size ) pos = size;

      /* Calculate the scroll distance */
      offset = GetScrollPos( aWindow, SB_VERT ) - pos;

      /* Adjust the client content of the window */
      if ( offset )
        ScrollWindow( aWindow, 0, offset, 0, 0 );

      /* At fin adapt the scrollbar to reflect the new position */
      SetScrollPos( aWindow, SB_VERT, pos, TRUE );
    }
    break;

    /* The WM_TIMER message should wake up the current task only. The timer
       processing is performed in the message loop. */
    case WM_TIMER :
    break;

    /* Create the framebuffer when opening the viewer window */
    case WM_CREATE :
    {
      if (( FrameBuffer = CreateDib( ViewerSize.X, ViewerSize.Y )) == 0 )
        EW_PANIC( Err03 );
    }
    break;

    /* In response to WM_DESTROY we close the simulation */
    case WM_DESTROY :
    {
      DestroyDib( FrameBuffer );
      FrameBuffer = 0;
      PostQuitMessage(0);
    }
    break;

    /* In all other cases we let the Windows to handle the message */
    default:
      return DefWindowProcA( aWindow, aMsg, aWParam, aLParam );
  }

  /* The message has been handled */
  return 0;
}


/*******************************************************************************
* FUNCTION:
*   EwOpenViewer
*
* DESCRIPTION:
*   The function EwOpenViewer() creates a new Win32 viewer window. This window
*   is used to display the running GUI application on the MS Windows desktop.
*   The size of the created window is adapted to the size of the application's
*   frame buffer - so the entire frame buffer content can be displayed on the
*   desktop.
*
*   The created viewer window is responsible for the screen update and the key
*   event translation. The MS Windows messages are translated in corresponding
*   key codes in the same manner as the Embedded Wizard Prototyper does.
*
*   Usually this function is called in the body of the MS Windows WinMain()
*   function.
*
* ARGUMENTS:
*   aWidth - The required width of the viewer.
*   aWidth - The required height of the viewer.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
static void EwOpenViewer( int aWidth, int aHeight )
{
  DWORD     style   = WS_OVERLAPPEDWINDOW;
  DWORD     exStyle = WS_EX_CLIENTEDGE;
  WNDCLASSA wc;
  RECT      rect;
  RECT      screen;

  ViewerSize.X = aWidth;
  ViewerSize.Y = aHeight;

  rect.left   = 0;
  rect.top    = 0;
  rect.right  = ViewerSize.X;
  rect.bottom = ViewerSize.Y;

  /* Get the size of the screen without the TaskBar, etc. */
  SystemParametersInfoA( SPI_GETWORKAREA, 0, &screen, 0 );

  /* Calculate the necessary size of the window frame */
  AdjustWindowRectEx( &rect, style, 0, exStyle );

  /* The window may not exceed the screen area */
  OffsetRect( &rect, screen.left - rect.left, screen.top - rect.top );
  IntersectRect( &rect, &rect, &screen );

  /* Prepare a new MS-Windows class ... */
  wc.style         = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc   = WindowProc;
  wc.cbClsExtra    = 0;
  wc.cbWndExtra    = sizeof(DWORD);
  wc.hInstance     = GetModuleHandle(0);
  wc.hIcon         = NULL;
  wc.hCursor       = LoadCursor( NULL, IDC_ARROW );
  wc.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
  wc.lpszMenuName  = NULL;
  wc.lpszClassName = "Embedded Wizard Viewer";

  /* ... and register it. */
  if ( !RegisterClassA( &wc ))
    EW_PANIC( Err02 );

  /* Create the 'Viewer' window */
  Viewer = CreateWindowExA( exStyle, "Embedded Wizard Viewer",
    *EwApplicationTitle ? EwApplicationTitle : "Embedded Wizard Viewer",
    style, rect.left, rect.top, rect.right - rect.left,
    rect.bottom - rect.top, NULL, NULL, GetModuleHandle(0),  NULL );

  if ( !Viewer )
    EW_PANIC( Err02 );

  /* Register the viewer to handle touch events if these are available */
  #if WINVER >= 0x601
    RegisterTouchWindow( Viewer, TWF_WANTPALM );
  #endif

  /* Expose the window on the screen */
  ShowWindow( Viewer, SW_SHOWNORMAL );
  UpdateWindow( Viewer );

  /* Start an update timer which is responsible for processing of pendings timer
     expirations */
  SetTimer( Viewer, 1, 1, 0 );

  /* Should we run the Graphics Engine benchmark? This options expects the module
     ewbenchmark.c to be compiled and linked with the application */
  #if defined EW_RUN_BENCHMARK_SHORT || defined EW_RUN_BENCHMARK_FULL
  {
    extern void EwBenchmark( XViewport* aViewport, int aFullBenchmark );

    #if defined EW_RUN_BENCHMARK_FULL
      EwBenchmark( Viewport, 1 );
    #else
      EwBenchmark( Viewport, 0 );
    #endif
  }
  #endif

  /* Should we run the Graphics Engine verification test? This options expects
     the module ewverification.c to be compiled and linked with the application */
  #if defined EW_RUN_VERIFICATION
  {
    /* Declaration of a callback function used to wait between successive test
       pages */
    typedef void (*XWaitForInputFunc)( void );

    extern void EwVerification( XViewport* aViewport, XWaitForInputFunc aFunc );
    EwVerification( Viewport, WaitForInputFunc );
  }
  #endif
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemInit
*
* DESCRIPTION:
*   The function GfxSystemInit is responsible to get an access to the
*   graphics subsystem. In case that the underlying graphics subsystem contains
*   a window manager, the given size is used to create a suitable window.
*   Otherwise, the given size is ignored, because the size of the framebuffer
*   cannot be changed.
*
* ARGUMENTS:
*   NONE.
*
* RETURN VALUE:
*   Returns 1 if successful, 0 otherwise.
*
*******************************************************************************/
int GfxSystemInit(void)
{
  return 1;
}

/*******************************************************************************
* FUNCTION:
*   GfxSystemDone
*
* DESCRIPTION:
*   The function GfxSystemDone is responsible to close the access to the
*   graphics subsystem.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void GfxSystemDone(void)
{
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemProcess
*
* DESCRIPTION:
*   The function GfxSystemProcess drives the graphics subsystem or window
*   manager in order to process all pending events.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   1, if further processing is needed, 0 otherwise.
*
*******************************************************************************/
int GfxSystemProcess(void)
{
  #if WINVER >= 0x0602
    #define QUERY_STATUS_SET (QS_KEY | QS_MOUSE | QS_TIMER | QS_TOUCH)
  #else
    #define QUERY_STATUS_SET (QS_KEY | QS_MOUSE | QS_TIMER)
  #endif

  MSG  msg;

  if ( !GetQueueStatus( QUERY_STATUS_SET ))
    return 1;

  if ( ! GetMessage( &msg, NULL, 0, 0 ))
    return 0;

  TranslateMessage(&msg);
  DispatchMessage(&msg);

  return (FrameBuffer != 0);
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemCreateSurface
*
* DESCRIPTION:
*   The function GfxSystemCreateSurface creates a graphic surface with the
*   given dimensions.
*
* ARGUMENTS:
*   aWidth  - Required surface width.
*   aHeight - Required surface height.
*
* RETURN VALUE:
*   Returns 1, if native window could be created, otherwise 0.
*
*******************************************************************************/
int GfxSystemCreateSurface( int aWidth, int aHeight )
{
   EwOpenViewer( aWidth, aHeight );
   return 1;
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemGetInfo
*
* DESCRIPTION:
*   The function GfxSystemGetInfo returns the graphic system info struct.
*
* ARGUMENTS:
*   aGfxSystemInfo  - Pointer to return the graphic system info struct.
*
* RETURN VALUE:
*   None.
*
*******************************************************************************/
void GfxSystemGetInfo( XGfxSystemInfo* aGfxSystemInfo )
{
  if ( ! aGfxSystemInfo )
    return;

  memset( aGfxSystemInfo, 0, sizeof( *aGfxSystemInfo ));
  aGfxSystemInfo->Type        = GFX_SYSTEM_WINDOWS;
  aGfxSystemInfo->FrameBuffer = FrameBuffer;
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemGetTouchEvents
*
* DESCRIPTION:
*   The function GfxSystemGetTouchEvents returns the current touch position and
*   touch status of the different fingers. The returned number of touch events
*   indicates the number of XTouchEvent that contain position and status
*   information.
*   The orientation of the touch positions is adjusted to match GUI coordinates.
*   If the hardware supports only single touch, the finger number is always 0.
*
* ARGUMENTS:
*   aTouchEvents  - Pointer to return array of XTouchEvent.
*
* RETURN VALUE:
*   Returns the number of available touch events.
*
*******************************************************************************/
int GfxSystemGetTouchEvents( XTouchEvent ** aTouchEvents )
{
  int   noOfTocuEvents;
  int   finger;
  DWORD ticks;

  if ( ! *aTouchEvents )
    return 0;

  /* check, if there are unfinished touch cycles */
  ticks = GetTickCount();
  for ( finger = 0; finger < GFX_SYSTEM_MAX_NB_OF_FINGERS; finger++ )
  {
    if ( TouchDown[ finger ] &&
      ( ticks - TouchTicks[ finger ] ) > GFX_SYSTEM_MAX_TICKS_TERM_TOUCH )
    {
      #ifdef EW_PRINT_TOUCH_DATA
      EwPrint( "Unfinished touch cycle detected and termimated (finger=%d)!\n", finger );
      #endif

      GfxSystemAddTouchEvent( EW_BSP_TOUCH_UP, finger,
        TouchPos[ finger ].X, TouchPos[ finger ].Y );
      TouchDown[ finger ]    = 0;
      TouchCount--;
    }
  }

  noOfTocuEvents = NbOfTouchEvents;
  *aTouchEvents = TouchEvents;
  NbOfTouchEvents = 0;

  return noOfTocuEvents;
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemGetCursorEvent
*
* DESCRIPTION:
*   The function GfxSystemGetTouchState returns the current touch state and the
*   touch position.
*
* ARGUMENTS:
*   aCursorEvent  - Pointer to return the cursor event.
*
* RETURN VALUE:
*   Returns 1 in case of a valid cursor event, 0 otherwise.
*
*******************************************************************************/
int GfxSystemGetCursorEvent( XCursorEvent * aCursorEvent )
{
  int retValue = 0;

  aCursorEvent->X        = LastCursorPos.X;
  aCursorEvent->Y        = LastCursorPos.Y;
  aCursorEvent->Button   = CursorButton;
  aCursorEvent->Type     = GfxCursorEvent;

  if ( GfxCursorEvent != EW_BSP_CURSOR_EVENT_IDLE )
    retValue = 1;

  if ( GfxCursorEvent == EW_BSP_CURSOR_EVENT_BUTTON_RELEASED )
    CursorButton = -1;

  GfxCursorEvent = EW_BSP_CURSOR_EVENT_IDLE;
  return retValue;
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemGetKeyboardEvent
*
* DESCRIPTION:
*   The function GfxSystemGetKeyboardEvent returns the latest keyboard event.
*
* ARGUMENTS:
*   aKeyboardEvent  - Pointer to return the keyboard event.
*
* RETURN VALUE:
*   Returns 1 in case of a valid keyboard event, 0 otherwise.
*
*******************************************************************************/
int GfxSystemGetKeyboardEvent( XKeyboardEvent * aKeyboardEvent )
{
  if ( ! aKeyboardEvent )
    return 0;

  aKeyboardEvent->State= GfxKeyState;

  switch ( GfxKeyEvent )
  {
    case EW_BSP_KEY_EVENT_DOWN:
      aKeyboardEvent->Type = EW_BSP_KEY_EVENT_DOWN;
      aKeyboardEvent->Data = ( int ) GfxKeyCode;
      break;

    case EW_BSP_KEY_EVENT_CHAR:
      aKeyboardEvent->Type = EW_BSP_KEY_EVENT_CHAR;
      aKeyboardEvent->Data = ( int ) GfxKeyCode;
      break;

    case EW_BSP_KEY_EVENT_UP:
      aKeyboardEvent->Type = EW_BSP_KEY_EVENT_UP;
      aKeyboardEvent->Data = ( int ) GfxKeyCode;
      GfxKeyCode = 0;
      break;

    default:
      return 0;
  }

  GfxKeyEvent = EW_BSP_KEY_EVENT_IDLE;
  return 1;
}


/*******************************************************************************
* FUNCTION:
*   GfxSystemUpdateSurface
*
* DESCRIPTION:
*   The function GfxSystemUpdateUpdateSurface updates the graphic surface.
*
* ARGUMENTS:
*   aX1  - Surface update area left.
*   aY1  - Surface update area topt.
*   aX2  - Surface update area right.
*   aY2  - Surface update area bottom.
*
* RETURN VALUE:
*   None.
*
*******************************************************************************/
void GfxSystemUpdateSurface( int aX1, int aY1, int aX2, int aY2 )
{
  RECT  clip;
  POINT pos;

  /* The area to update within the MS-Windows window */
  #if EW_SURFACE_ROTATION == 0
    clip.left   = aX1;
    clip.right  = aX2;
    clip.top    = aY1;
    clip.bottom = aY2;
  #endif

  #if EW_SURFACE_ROTATION == 90
    clip.left   = ViewerSize.X - aY2;
    clip.right  = ViewerSize.X - aY1;
    clip.top    = aX1;
    clip.bottom = aX2;
  #endif

  #if EW_SURFACE_ROTATION == 180
    clip.left   = ViewerSize.X - aX2;
    clip.right  = ViewerSize.X - aX1;
    clip.top    = ViewerSize.Y - aY2;
    clip.bottom = ViewerSize.Y - aY1;
  #endif

  #if EW_SURFACE_ROTATION == 270
    clip.left   = aY1;
    clip.right  = aY2;
    clip.top    = ViewerSize.Y - aX2;
    clip.bottom = ViewerSize.Y - aX1;
  #endif

  /* Get the current scroll position and correct the position of the affected
      area */
  pos.x = GetScrollPos( Viewer, SB_HORZ );
  pos.y = GetScrollPos( Viewer, SB_VERT );
  OffsetRect( &clip, -pos.x, -pos.y );

  /* Force an update of the MS-Windows window */
  InvalidateRect( Viewer, &clip, FALSE );
  UpdateWindow( Viewer );
}

/* mli */

