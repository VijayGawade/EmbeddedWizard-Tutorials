/*******************************************************************************
*
* Embedded Wizard - GUI Solutions by TARA Systems
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This software is provided as example code to demonstrate the use of Embedded
* Wizard and related software components. It may be used in production systems
* after you have reviewed, tested and adapted it to your specific requirements.
*
* Use of this example code is subject to the Embedded Wizard license terms
* (as published at https://www.embedded-wizard.de/legal), including in
* particular:
*
*   - Embedded Wizard Terms and Conditions (EWTC)
*   - Embedded Wizard License Agreement (EWLA)
*   - Embedded Wizard Community License (EWCL)
*
* The specific agreement(s) applicable to you depend on your contractual
* relationship with TARA Systems GmbH and/or your use of the Community License.
*
* Subject to your compliance with the applicable Embedded Wizard license terms
* and/or any separate written agreement with TARA Systems, you are granted a
* non-exclusive, worldwide, royalty-free license to use, copy, modify and
* integrate this example code into your own software products and projects.
* You may redistribute this code only as part of your products and not as a
* standalone library, framework or development tool.
*
* THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY
* KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.
* TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TARA
* SYSTEMS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
********************************************************************************
*
* DESCRIPTION:
*   This file implements a generic framework for running Embedded Wizard
*   generated GUI applications on a dedicated target with or without the usage
*   of an operating system.
*   The module ewmain contains three major functions that are used within
*   every Embedded Wizard GUI application: EwInit() - EwProcess() - EwDone().
*   These functions represent the lifecycle of the entire GUI application.
*
*   EwInit() is responsible to initialize the system, to configure the display,
*   to get access to the desired input devices (like keyboard or touch),
*   to initialize the Embedded Wizard Runtime Environment / Graphics Engine,
*   to create an instance of the application class and to initialize all
*   needed peripheral components.
*
*   EwProcess() implements one cycle of the main loop. This function has to be
*   called in an (endless) loop and contains typically the following steps:
*   1. Process data from your device driver(s)
*   2. Process recorded function invocations stored in the invocation queue
*   3. Process key events
*   4. Process cursor or touch screen events
*   5. Process timers
*   6. Process signals
*   7. Update the screen
*   8. Start the garbage collection
*
*   EwDone() is responsible to shutdown the application and to release all
*   used resources.
*
*   Important: Please be aware that every Embedded Wizard GUI application
*   requires the execution in a single GUI task!
*   If you are working with an operating system and your software is using
*   several threads/tasks, please take care to access your GUI application
*   only within the context of your GUI thread/task. Use the functions
*   EwInvoke() or EwInvokeCopy() to provide events and data from any other
*   worker thread/task or interrupt service routine to the GUI application.
*
*   In order to keep this framework independent from the particular GUI
*   application, the application class and the screen size are taken from the
*   generated code. In this manner, it is not necessary to modify this file
*   when creating new GUI applications. Just set the attributes 'ScreenSize'
*   and 'ApplicationClass' of the profile in the Embedded Wizard IDE.
*
*   For more information concerning the integration of an Embedded Wizard
*   generated GUI application into your main application, please see
*   https://doc.embedded-wizard.de/main-loop
*
*******************************************************************************/

#include <time.h>

#include "ewconfig.h"
#include "ewmain.h"
#include "Core.h"
#include "Graphics.h"

#include "ew_bsp_display.h"
#include "ew_bsp_touch.h"
#include "ew_bsp_console.h"
#include "ew_bsp_keyboard.h"
#include "ew_bsp_cursor.h"
#include "ew_bsp_os.h"
#include "DeviceDriver.h"


/* memory pool */
#ifdef EW_MEMORY_POOL_SECTION
  EW_MEMORY_POOL_SECTION static unsigned long
    EwMemory[ EW_MEMORY_POOL_SIZE / sizeof( unsigned long )];
  #define EW_MEMORY_POOL_ADDR EwMemory
#endif

/* optional second memory pool */
#ifdef EW_EXTRA_POOL_SECTION
  EW_EXTRA_POOL_SECTION static unsigned long
    EwExtraMemory[ EW_EXTRA_POOL_SIZE / sizeof( unsigned long )];
  #define EW_EXTRA_POOL_ADDR EwExtraMemory
#endif

#define PRINT_ENABLED( arg ) ( arg ) ? "enabled" : "disabled"

#define PRINT_RESULT( result ) \
  if ( !result )               \
    EwPrint( "[failed]\n" );   \
  else                         \
    EwPrint( "[OK]\n" );

#define CHECK_RESULT( result ) \
  if ( !result )               \
  {                            \
    EwPrint( "[failed]\n" );   \
    return 0;                  \
  }                            \
  else                         \
    EwPrint( "[OK]\n" );

#ifndef EW_VIEWPORT_ROTATION
  #define EW_VIEWPORT_ROTATION 0
#endif

/* helper functions used within this module */
static void EwUpdate( XViewport* aViewport, CoreRoot aApplication );
static void EwViewportProc( XViewport* aViewport, void* aHandle,
  void* aDisplay1, void* aDisplay2, void* aDisplay3, XRect aArea );
static XEnum EwGetKeyCodeConsole( void );
static int EwHandleKeyboardEvent( XKeyboardEvent aKeyboardEvent );

static CoreRoot     RootObject;
static XViewport*   Viewport;
static XDisplayInfo DisplayInfo;


/*******************************************************************************
* FUNCTION:
*   EwInit
*
* DESCRIPTION:
*   EwInit() is responsible to initialize the system, to configure the display,
*   to get access to the desired input devices (like keyboard or touch),
*   to initialize the Embedded Wizard Runtime Environment / Graphics Engine,
*   to create an instance of the application class and to initialize all
*   needed peripheral components.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   1 if successful, 0 otherwise.
*
*******************************************************************************/
int EwInit( void )
{
  XRect viewportArea;

  /* initialize display */
  EwPrint( "Initialize Display...                        " );
  CHECK_RESULT( EwBspDisplayInit( EwScreenSize.X, EwScreenSize.Y, &DisplayInfo ));

  /* initialize keyboard */
  EwPrint( "Initialize Keyboard Driver...                " );
  PRINT_RESULT( EwBspKeyboardInit());

  /* initialize touchscreen */
  EwPrint( "Initialize Touch Driver...                   " );
  PRINT_RESULT( EwBspTouchInit( EwScreenSize.X, EwScreenSize.Y, &DisplayInfo ));

  /* initialize mouse */
  EwPrint( "Initialize Mouse Driver...                   " );
  PRINT_RESULT( EwBspCursorInit( EwScreenSize.X, EwScreenSize.Y, &DisplayInfo ));

  #if EW_MEMORY_POOL_SIZE > 0
    /* initialize heap manager */
    EwPrint( "Initialize Memory Manager...                 " );
    CHECK_RESULT( EwInitHeap( 0 ));
    EwAddHeapMemoryPool( (void*)EW_MEMORY_POOL_ADDR, EW_MEMORY_POOL_SIZE );

    #if EW_EXTRA_POOL_SIZE > 0
      EwAddHeapMemoryPool( (void*)EW_EXTRA_POOL_ADDR, EW_EXTRA_POOL_SIZE );
    #endif
  #endif

  /* configure caches, queues and memory allocation strategy of Graphics Engine
     and Runtime Environment according to settings from ewconfig.h */
  EwConfigRuntimeEnvironment();
  EwConfigGraphicsEngine();

  /* initialize Runtime Environment and Graphics Engine */
  EwPrint( "Initialize Platform Package...               " );
  EwInitRuntimeEnvironment( 0 );
  CHECK_RESULT( EwInitGraphicsEngine( 0 ));

  /* initialize the invocation queue to process callbacks in context of GUI thread/task */
  EwPrint( "Initialize Invocation Queue...               " );
  CHECK_RESULT( EwInitInvocations( EW_INVOCATION_QUEUE_SIZE ));

  /* optional: initialize your device driver(s) that provide data for your GUI */
  DeviceDriver_Initialize();

  #ifdef EW_USE_IMMEDIATE_GARBAGE_COLLECTION
    /* test the immediate garbage collection if enabled */
    EwPrint( "Check Immediate Garbage Collection...        " );
    CHECK_RESULT( EwTestImmediateReclaimMemory());
  #endif

  /* create the applications root object ... */
  EwPrint( "Create Embedded Wizard Root Object...        " );
  RootObject = (CoreRoot)EwNewObjectIndirect( EwApplicationClass, 0 );
  CHECK_RESULT( RootObject );

  EwLockObject( RootObject );
  CoreRoot__Initialize( RootObject, EwScreenSize );

  /* create Embedded Wizard viewport object to provide uniform access to the framebuffer */
  viewportArea.Point1.X = DisplayInfo.ViewportX;
  viewportArea.Point1.Y = DisplayInfo.ViewportY;
  viewportArea.Point2.X = DisplayInfo.ViewportX + DisplayInfo.ViewportWidth;
  viewportArea.Point2.Y = DisplayInfo.ViewportY + DisplayInfo.ViewportHeight;

  EwPrint( "Create Embedded Wizard Viewport...           " );
  Viewport = EwInitViewport( EwScreenSize, viewportArea,
    EW_VIEWPORT_ROTATION, 255, DisplayInfo.FrameBuffer, 0, 0, EwViewportProc );
  CHECK_RESULT( Viewport );

  EwPrint( "Starting Embedded Wizard main loop - press <p> to shutdown application...\n" );

  return 1;
}


/*******************************************************************************
* FUNCTION:
*   EwDone
*
* DESCRIPTION:
*   EwDone() is responsible to shutdown the application and to release all
*   used resources.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None.
*
*******************************************************************************/
void EwDone( void )
{
  /* destroy the applications root object and release unused resources and memory */
  EwPrint( "Shutting down Application...                 " );
  EwDoneViewport( Viewport );
  EwUnlockObject( RootObject );
  EwReclaimMemory();
  EwPrint( "[OK]\n" );

  /* optional: de-initialize your device driver(s) */
  DeviceDriver_Deinitialize();

  /* deinitialize the invocation queue */
  EwPrint( "Deinitialize Invocation Queue...             " );
  EwDoneInvocations();
  EwPrint( "[OK]\n" );

  /* deinitialize Runtime Environment and Graphics Engine */
  EwPrint( "Deinitialize Platform Package...             " );
  EwDoneGraphicsEngine();
  EwDoneRuntimeEnvironment();
  EwPrint( "[OK]\n" );

  #if EW_MEMORY_POOL_SIZE > 0
    /* deinitialize heap manager */
    EwDoneHeap();
  #endif

  /* deinitialize mouse */
  EwPrint( "Deinitialize Mouse Driver...                 " );
  EwBspCursorDone();
  EwPrint( "[OK]\n" );

  /* deinitialize touch screen */
  EwPrint( "Deinitialize Touch Driver...                 " );
  EwBspTouchDone();
  EwPrint( "[OK]\n" );

  /* deinitialize keybaord */
  EwPrint( "Deinitialize Keyboard Driver...              " );
  EwBspKeyboardDone();
  EwPrint( "[OK]\n" );

  /* deinitialize display */
  EwPrint( "Deinitialize Display Driver...               " );
  EwBspDisplayDone( &DisplayInfo );
  EwPrint( "[OK]\n" );

  Viewport   = 0;
  RootObject = 0;
}


/*******************************************************************************
* FUNCTION:
*   EwProcess
*
* DESCRIPTION:
*   EwProcess() implements one cycle of the main loop. This function has to be
*   called in an (endless) loop and contains typically the following steps:
*   1. Process data from your device driver(s)
*   2. Process recorded function invocations stored in the invocation queue
*   3. Process key events
*   4. Process cursor or touch screen events
*   5. Process timers
*   6. Process signals
*   7. Update the screen
*   8. Start the garbage collection
*   For more information concerning the integration of an Embedded Wizard
*   generated GUI application into your main application, please see
*   https://doc.embedded-wizard.de/main-loop
*
* ARGUMENTS:
*   None.
*
* RETURN VALUE:
*   1, if further processing is needed, 0 otherwise.
*
*******************************************************************************/
int EwProcess( void )
{
  int            timers  = 0;
  int            signals = 0;
  int            events  = 0;
  int            invokes = 0;
  int            devices = 0;
  XEnum          cmd     = CoreKeyCodeNoKey;
  int            noOfTouch;
  XTouchEvent*   touchEvent;
  int            touch;
  int            finger;
  XPoint         touchPos;
  XCursorEvent   cursorEvent;
  XKeyboardEvent keyboardEvent;

  /* process data of your device driver(s) and update the GUI
     application by setting properties or by triggering events */
  devices = DeviceDriver_ProcessData();

  /* process function invocations that have been recorded in the context of
     foreign threads, tasks or interrupt service routines */
  invokes = EwProcessInvocations();

  /* receive keyboard inputs */
  cmd = EwGetKeyCodeConsole();

  if ( cmd != CoreKeyCodeNoKey )
  {
    if ( cmd == CoreKeyCodePower )
      return 0;

    /* feed the application with a 'press' and 'release' event */
    events |= CoreRoot__DriveKeyboardHitting( RootObject, cmd, 0, 1 );
    events |= CoreRoot__DriveKeyboardHitting( RootObject, cmd, 0, 0 );
  }

  if ( EwBspKeyboardGetEvent( &keyboardEvent ))
  {
    events |= EwHandleKeyboardEvent( keyboardEvent );
  }

  /* receive (multi-) touch inputs and provide it to the application */
  noOfTouch = EwBspTouchGetEvents( &touchEvent );

  if ( noOfTouch > 0 )
  {
    for ( touch = 0; touch < noOfTouch; touch++ )
    {
      /* get data out of the touch event */
      finger     = touchEvent[ touch ].Finger;
      touchPos.X = touchEvent[ touch ].XPos;
      touchPos.Y = touchEvent[ touch ].YPos;

      /* begin of touch cycle */
      if ( touchEvent[ touch ].State == EW_BSP_TOUCH_DOWN )
        events |= CoreRoot__DriveMultiTouchHitting(  RootObject, 1, finger, touchPos );

      /* movement during touch cycle */
      else if ( touchEvent[ touch ].State == EW_BSP_TOUCH_MOVE )
        events |= CoreRoot__DriveMultiTouchMovement( RootObject, finger, touchPos );

      /* end of touch cycle */
      else if ( touchEvent[ touch ].State == EW_BSP_TOUCH_UP )
        events |= CoreRoot__DriveMultiTouchHitting(  RootObject, 0, finger, touchPos );
    }
  }

  if ( EwBspCursorGetEvent( &cursorEvent ))
  {
    XPoint cursorPos = EwNewPoint( cursorEvent.X, cursorEvent.Y );
    switch ( cursorEvent.Type )
    {
      case EW_BSP_CURSOR_EVENT_MOVE:
        CoreRoot__DriveCursorMovement( RootObject, cursorPos );
        break;

      case EW_BSP_CURSOR_EVENT_BUTTON_PRESSED:
        CoreRoot__DriveCursorHitting( RootObject, 1, cursorEvent.Button, cursorPos);
        break;

      case EW_BSP_CURSOR_EVENT_BUTTON_RELEASED:
        CoreRoot__DriveCursorHitting( RootObject, 0, cursorEvent.Button, cursorPos);
        break;
    }
  }

  /* process expired timers */
  timers = EwProcessTimers();

  /* process the pending signals */
  signals = EwProcessSignals();

  /* refresh the screen, if something has changed and draw its content */
  if ( devices || invokes || timers || signals || events )
  {
    if ( CoreRoot__DoesNeedUpdate( RootObject ))
      EwUpdate( Viewport, RootObject );

    /* just for debugging purposes: check the memory structure */
    EwVerifyHeap();

    /* after each processed message start the garbage collection */
    EwReclaimMemory();

    /* print current memory statistic to console interface */
    #ifdef EW_PRINT_MEMORY_USAGE
      EwPrintProfilerStatistic( 0 );
    #endif

    /* evaluate memory pools and print report */
    #ifdef EW_DUMP_HEAP
      EwDumpHeap( 0 );
    #endif
  }
  else
  {
    /* otherwise sleep/suspend the UI application until a certain event occurs or a timer expires... */
    EwBspOsDelay( 1 );
  }

  return 1;
}


/*******************************************************************************
* FUNCTION:
*   EwUpdate
*
* DESCRIPTION:
*   The function EwUpdate performs the screen update of the dirty area.
*
* ARGUMENTS:
*   aViewPort    - Viewport used for the screen update.
*   aApplication - Root object used for the screen update.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
static void EwUpdate( XViewport* aViewport, CoreRoot aApplication )
{
  XBitmap*       bitmap     = EwBeginUpdate( aViewport );
  GraphicsCanvas canvas     = EwNewObject( GraphicsCanvas, 0 );
  XRect          updateRect = {{ 0, 0 }, { 0, 0 }};

  /* let's redraw the dirty area of the screen. Cover the returned bitmap
     objects within a canvas, so Mosaic can draw to it. */
  if ( bitmap && canvas )
  {
    GraphicsCanvas__AttachBitmap( canvas, (XHandle)bitmap );
    updateRect = CoreRoot__UpdateGE20( aApplication, canvas );
    GraphicsCanvas__DetachBitmap( canvas );
  }

  /* complete the update */
  if ( bitmap )
    EwEndUpdate( aViewport, updateRect );
}


/*******************************************************************************
* FUNCTION:
*   EwViewportProc
*
* DESCRIPTION:
*  Completion callback for the viewport. If EwEndUpdate() is called, the
*  callback ensures, that the screen content is flipped
*
* ARGUMENTS:
*   aViewport - Viewport which is performing the screen update.
*   aHandle   - Reference to the real viewport, the framebuffer, display, etc.
*    This value depends on the underlying graphics subsystem.
*   aDisplay1,
*   aDisplay2,
*   aDisplay3 - Platform dependent values, where already existing framebuffer
*     or drawing context, etc. are stored. These values are passed during the
*     initialization of the viewport (see EwInitViewport()).
*   aArea     - Area modified by the update relative to the top-left corner of
*     the viewport.
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
static void EwViewportProc( XViewport* aViewport, void* aHandle,
  void* aDisplay1, void* aDisplay2, void* aDisplay3, XRect aArea )
{
  /* Perform the swap if there was something drawn on the screen */
  EwBspDisplayUpdate( aDisplay2, aArea );
}


/*******************************************************************************
* FUNCTION:
*   EwGetKeyCodeConsole
*
* DESCRIPTION:
*   The function EwGetKeyCodeConsole reads the next key code from the console and
*   translates it into an Embedded Wizard key code. The mapping between the key
*   code from the console and the resulting Embedded Wizard key code can be
*   adapted to the needs of your application.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   Returns the next EmWi key code or CoreKeyCodeNoKey if no key code available.
*
*******************************************************************************/
static XEnum EwGetKeyCodeConsole( void )
{
  #if EW_USE_TERMINAL_INPUT == 1
    switch ( EwBspConsoleGetCharacter() )
    {
      case 0xE0 :
      {
        switch ( EwBspConsoleGetCharacter() )
        {
          case 0x00 : return CoreKeyCodeExit;
          case 0x48 : return CoreKeyCodeUp;
          case 0x50 : return CoreKeyCodeDown;
          case 0x4D : return CoreKeyCodeRight;
          case 0x4B : return CoreKeyCodeLeft;
        }
      }
      break;

      case 0x1B : return CoreKeyCodeExit;
      case 0x0D : return CoreKeyCodeOk;
      case 'm'  : return CoreKeyCodeMenu;
      case 'p'  : return CoreKeyCodePower;
    }
  #endif
  return CoreKeyCodeNoKey;
}


/* This helper function verifies, whether the passed universal key code does
   match a TV key code. If true, the TV code variant is returned. Otherwise
   the original key code without being modified. This conversion exists for
   compatibility with older EmWi version used for the development of TV or
   set-top boxes. */
static XEnum TranslateToTVKeyCode( XEnum aCode )
{
  const XEnum list1[] = {
    CoreKeyCodeEnter,           CoreKeyCodeEscape,             CoreKeyCodeBackspace,

    CoreKeyCodeCtrlShiftPageUp, CoreKeyCodeCtrlShiftPageDown,  CoreKeyCodeCtrlShiftUp,
    CoreKeyCodeCtrlShiftDown,   CoreKeyCodeCtrlShiftKeyP,      CoreKeyCodeCtrlShiftKeyR,
    CoreKeyCodeCtrlShiftLeft,   CoreKeyCodeCtrlShiftRight,     CoreKeyCodeCtrlShiftBackspace,
    CoreKeyCodeCtrlShiftKeyE,   CoreKeyCodeCtrlShiftKeyT,      CoreKeyCodeCtrlShiftKeyN,
    CoreKeyCodeCtrlShiftKeyK,   CoreKeyCodeCtrlShiftKeyG,      CoreKeyCodeCtrlShiftKeyU,
    CoreKeyCodeCtrlShiftKeyA,   CoreKeyCodeCtrlShiftKeyD,      CoreKeyCodeCtrlShiftKeyM,
    CoreKeyCodeCtrlShiftKey0,   CoreKeyCodeCtrlShiftKey1,      CoreKeyCodeCtrlShiftKey2,
    CoreKeyCodeCtrlShiftKey3,   CoreKeyCodeCtrlShiftKey4,      CoreKeyCodeCtrlShiftKey5,
    CoreKeyCodeCtrlShiftKey6,   CoreKeyCodeCtrlShiftKey7,      CoreKeyCodeCtrlShiftKey8,
    CoreKeyCodeCtrlShiftKey9,

    CoreKeyCodeCtrlKeyM,        CoreKeyCodeCtrlPageUp,         CoreKeyCodeCtrlPageDown,
    CoreKeyCodeCtrlInsert,      CoreKeyCodeCtrlDelete,         CoreKeyCodeCtrlKeyP,
    CoreKeyCodeCtrlKeyS,        CoreKeyCodeCtrlLeft,           CoreKeyCodeCtrlRight,
    CoreKeyCodeCtrlUp,          CoreKeyCodeCtrlDown,           CoreKeyCodeCtrlKeyH,
    CoreKeyCodeCtrlKeyR,        CoreKeyCodeCtrlKeyG,           CoreKeyCodeCtrlKeyB,
    CoreKeyCodeCtrlKeyY,        CoreKeyCodeCtrlKeyL,           CoreKeyCodeCtrlKeyN,
    CoreKeyCodeCtrlKeyW,        CoreKeyCodeCtrlKeyD,           CoreKeyCodeCtrlKeyV,
    CoreKeyCodeCtrlKeyE,        CoreKeyCodeCtrlKeyO,           CoreKeyCodeCtrlKeyT,
    CoreKeyCodeCtrlKeyQ,        CoreKeyCodeCtrlKeyA,           CoreKeyCodeCtrlKeyC,
    CoreKeyCodeCtrlKeyU,        CoreKeyCodeCtrlKeyZ,           CoreKeyCodeCtrlKeyX,
    CoreKeyCodeCtrlKeyI,        CoreKeyCodeCtrlHome,           CoreKeyCodeCtrlEnd,
    CoreKeyCodeCtrlKey0,        CoreKeyCodeCtrlKey1,           CoreKeyCodeCtrlKey2,
    CoreKeyCodeCtrlKey3,        CoreKeyCodeCtrlKey4,           CoreKeyCodeCtrlKey5,
    CoreKeyCodeCtrlKey6,        CoreKeyCodeCtrlKey7,           CoreKeyCodeCtrlKey8,
    CoreKeyCodeCtrlKey9, 0 };

  const XEnum list2[] = {
    CoreKeyCodeOk,              CoreKeyCodeExit,               CoreKeyCodeClear,

    CoreKeyCodeChannelUp,       CoreKeyCodeChannelDown,        CoreKeyCodeSkipPrev,
    CoreKeyCodeSkipNext,        CoreKeyCodePause,              CoreKeyCodeRecord,
    CoreKeyCodeSlowRev,         CoreKeyCodeSlowFwd,            CoreKeyCodeEject,
    CoreKeyCodeRepeat,          CoreKeyCodeTimer,              CoreKeyCodeNavigation,
    CoreKeyCodeKaraoke,         CoreKeyCodeGame,               CoreKeyCodeSetup,
    CoreKeyCodeAngle,           CoreKeyCodeMode,               CoreKeyCodeMute,
    CoreKeyCodeUser10,          CoreKeyCodeUser11,             CoreKeyCodeUser12,
    CoreKeyCodeUser13,          CoreKeyCodeUser14,             CoreKeyCodeUser15,
    CoreKeyCodeUser16,          CoreKeyCodeUser17,             CoreKeyCodeUser18,
    CoreKeyCodeUser19,

    CoreKeyCodeMenu,            CoreKeyCodeVolumeUp,           CoreKeyCodeVolumeDown,
    CoreKeyCodeShow,            CoreKeyCodeHide,               CoreKeyCodePlay,
    CoreKeyCodeStop,            CoreKeyCodeRev,                CoreKeyCodeFwd,
    CoreKeyCodeSkipBwd,         CoreKeyCodeSkipFwd,            CoreKeyCodeHelp,
    CoreKeyCodeRed,             CoreKeyCodeGreen,              CoreKeyCodeBlue,
    CoreKeyCodeYellow,          CoreKeyCodeWhite,              CoreKeyCodeMagenta,
    CoreKeyCodeTV,              CoreKeyCodeDVD,                CoreKeyCodeVCR,
    CoreKeyCodeEPG,             CoreKeyCodeOSD,                CoreKeyCodeText,
    CoreKeyCodePIP,             CoreKeyCodeAudio,              CoreKeyCodeClock,
    CoreKeyCodeSubtitle,        CoreKeyCodeZoom,               CoreKeyCodeIndex,
    CoreKeyCodeInfo,            CoreKeyCodeDisplay,            CoreKeyCodePower,
    CoreKeyCodeUser0,           CoreKeyCodeUser1,              CoreKeyCodeUser2,
    CoreKeyCodeUser3,           CoreKeyCodeUser4,              CoreKeyCodeUser5,
    CoreKeyCodeUser6,           CoreKeyCodeUser7,              CoreKeyCodeUser8,
    CoreKeyCodeUser9 };

  const XEnum* ptr = list1;

  /* Is the passed key code convertible to TV code? Search the list. */
  while ( *ptr && ( *ptr != aCode ))
    ptr++;

  /* Found? Then convert to TV code */
  if ( *ptr )
    aCode = list2[ ptr - list1 ];

  return aCode;
}


/*******************************************************************************
* FUNCTION:
*   EwHandleKeyboardEvent
*
* DESCRIPTION:
*   The function EwGetKeyCodeKeyboard reads the next key code from the keyboard and
*   translates it into an Embedded Wizard key code. The mapping between the key
*   code from the console and the resulting Embedded Wizard key code can be
*   adapted to the needs of your application.
*
* ARGUMENTS:
*   aKeyboardEvent - The keyboard event.
*
* RETURN VALUE:
*   Returns 1, if a GUI update is needed.
*
*******************************************************************************/
static int EwHandleKeyboardEvent( XKeyboardEvent aKeyboardEvent )
{
  static XEnum code         = CoreKeyCodeNoKey;
  static int   charCode     = 0;
  int          updateNeeded = 0;
  XEnum        tvCode       = CoreKeyCodeNoKey;

  if ( aKeyboardEvent.Type == EW_BSP_KEY_EVENT_DOWN )
  {
    int prevCode = code;
    code         = CoreKeyCodeNoKey;

    switch ( aKeyboardEvent.State )
    {
      case EW_BSP_KEY_STATE_NORMAL:
      switch ( aKeyboardEvent.Data )
      {
        case EW_BSP_KEY_CODE_RETURN : code = CoreKeyCodeEnter;    break;
        case EW_BSP_KEY_CODE_ESCAPE : code = CoreKeyCodeEscape;   break;
        case EW_BSP_KEY_CODE_BACK   : code = CoreKeyCodeBackspace;break;
        case EW_BSP_KEY_CODE_TAB    : code = CoreKeyCodeTab;      break;
        case EW_BSP_KEY_CODE_DOWN   : code = CoreKeyCodeDown;     break;
        case EW_BSP_KEY_CODE_UP     : code = CoreKeyCodeUp;       break;
        case EW_BSP_KEY_CODE_LEFT   : code = CoreKeyCodeLeft;     break;
        case EW_BSP_KEY_CODE_RIGHT  : code = CoreKeyCodeRight;    break;
        case EW_BSP_KEY_CODE_HOME   : code = CoreKeyCodeHome;     break;
        case EW_BSP_KEY_CODE_END    : code = CoreKeyCodeEnd;      break;
        case EW_BSP_KEY_CODE_PRIOR  : code = CoreKeyCodePageUp;   break;
        case EW_BSP_KEY_CODE_NEXT   : code = CoreKeyCodePageDown; break;
        case EW_BSP_KEY_CODE_INSERT : code = CoreKeyCodeInsert;   break;
        case EW_BSP_KEY_CODE_DELETE : code = CoreKeyCodeDelete;   break;
        case EW_BSP_KEY_CODE_F1     : code = CoreKeyCodeF1;       break;
        case EW_BSP_KEY_CODE_F2     : code = CoreKeyCodeF2;       break;
        case EW_BSP_KEY_CODE_F3     : code = CoreKeyCodeF3;       break;
        case EW_BSP_KEY_CODE_F4     : code = CoreKeyCodeF4;       break;
        case EW_BSP_KEY_CODE_F5     : code = CoreKeyCodeF5;       break;
        case EW_BSP_KEY_CODE_F6     : code = CoreKeyCodeF6;       break;
        case EW_BSP_KEY_CODE_F7     : code = CoreKeyCodeF7;       break;
        case EW_BSP_KEY_CODE_F8     : code = CoreKeyCodeF8;       break;
        case EW_BSP_KEY_CODE_F9     : code = CoreKeyCodeF9;       break;
        case EW_BSP_KEY_CODE_F10    : code = CoreKeyCodeF10;      break;
      }
      break;

      case EW_BSP_KEY_STATE_SHIFT:
      switch ( aKeyboardEvent.Data )
      {
        case EW_BSP_KEY_CODE_RETURN : code = CoreKeyCodeShiftEnter;    break;
        case EW_BSP_KEY_CODE_ESCAPE : code = CoreKeyCodeShiftEscape;   break;
        case EW_BSP_KEY_CODE_BACK   : code = CoreKeyCodeShiftBackspace;break;
        case EW_BSP_KEY_CODE_TAB    : code = CoreKeyCodeShiftTab;      break;
        case EW_BSP_KEY_CODE_DOWN   : code = CoreKeyCodeShiftDown;     break;
        case EW_BSP_KEY_CODE_UP     : code = CoreKeyCodeShiftUp;       break;
        case EW_BSP_KEY_CODE_LEFT   : code = CoreKeyCodeShiftLeft;     break;
        case EW_BSP_KEY_CODE_RIGHT  : code = CoreKeyCodeShiftRight;    break;
        case EW_BSP_KEY_CODE_HOME   : code = CoreKeyCodeShiftHome;     break;
        case EW_BSP_KEY_CODE_END    : code = CoreKeyCodeShiftEnd;      break;
        case EW_BSP_KEY_CODE_PRIOR  : code = CoreKeyCodeShiftPageUp;   break;
        case EW_BSP_KEY_CODE_NEXT   : code = CoreKeyCodeShiftPageDown; break;
        case EW_BSP_KEY_CODE_INSERT : code = CoreKeyCodeShiftInsert;   break;
        case EW_BSP_KEY_CODE_DELETE : code = CoreKeyCodeShiftDelete;   break;
        case EW_BSP_KEY_CODE_F1     : code = CoreKeyCodeShiftF1;       break;
        case EW_BSP_KEY_CODE_F2     : code = CoreKeyCodeShiftF2;       break;
        case EW_BSP_KEY_CODE_F3     : code = CoreKeyCodeShiftF3;       break;
        case EW_BSP_KEY_CODE_F4     : code = CoreKeyCodeShiftF4;       break;
        case EW_BSP_KEY_CODE_F5     : code = CoreKeyCodeShiftF5;       break;
        case EW_BSP_KEY_CODE_F6     : code = CoreKeyCodeShiftF6;       break;
        case EW_BSP_KEY_CODE_F7     : code = CoreKeyCodeShiftF7;       break;
        case EW_BSP_KEY_CODE_F8     : code = CoreKeyCodeShiftF8;       break;
        case EW_BSP_KEY_CODE_F9     : code = CoreKeyCodeShiftF9;       break;
        case EW_BSP_KEY_CODE_F10    : code = CoreKeyCodeShiftF10;      break;
      }
      break;

      case EW_BSP_KEY_STATE_CTRL:
      switch ( aKeyboardEvent.Data )
      {
        case EW_BSP_KEY_CODE_RETURN : code = CoreKeyCodeCtrlEnter;    break;
        case EW_BSP_KEY_CODE_ESCAPE : code = CoreKeyCodeCtrlEscape;   break;
        case EW_BSP_KEY_CODE_BACK   : code = CoreKeyCodeCtrlBackspace;break;
        case EW_BSP_KEY_CODE_TAB    : code = CoreKeyCodeCtrlTab;      break;
        case EW_BSP_KEY_CODE_DOWN   : code = CoreKeyCodeCtrlDown;     break;
        case EW_BSP_KEY_CODE_UP     : code = CoreKeyCodeCtrlUp;       break;
        case EW_BSP_KEY_CODE_LEFT   : code = CoreKeyCodeCtrlLeft;     break;
        case EW_BSP_KEY_CODE_RIGHT  : code = CoreKeyCodeCtrlRight;    break;
        case EW_BSP_KEY_CODE_HOME   : code = CoreKeyCodeCtrlHome;     break;
        case EW_BSP_KEY_CODE_END    : code = CoreKeyCodeCtrlEnd;      break;
        case EW_BSP_KEY_CODE_PRIOR  : code = CoreKeyCodeCtrlPageUp;   break;
        case EW_BSP_KEY_CODE_NEXT   : code = CoreKeyCodeCtrlPageDown; break;
        case EW_BSP_KEY_CODE_INSERT : code = CoreKeyCodeCtrlInsert;   break;
        case EW_BSP_KEY_CODE_DELETE : code = CoreKeyCodeCtrlDelete;   break;
        case EW_BSP_KEY_CODE_F1     : code = CoreKeyCodeCtrlF1;       break;
        case EW_BSP_KEY_CODE_F2     : code = CoreKeyCodeCtrlF2;       break;
        case EW_BSP_KEY_CODE_F3     : code = CoreKeyCodeCtrlF3;       break;
        case EW_BSP_KEY_CODE_F4     : code = CoreKeyCodeCtrlF4;       break;
        case EW_BSP_KEY_CODE_F5     : code = CoreKeyCodeCtrlF5;       break;
        case EW_BSP_KEY_CODE_F6     : code = CoreKeyCodeCtrlF6;       break;
        case EW_BSP_KEY_CODE_F7     : code = CoreKeyCodeCtrlF7;       break;
        case EW_BSP_KEY_CODE_F8     : code = CoreKeyCodeCtrlF8;       break;
        case EW_BSP_KEY_CODE_F9     : code = CoreKeyCodeCtrlF9;       break;
        case EW_BSP_KEY_CODE_F10    : code = CoreKeyCodeCtrlF10;      break;
        case ' '                    : code = CoreKeyCodeCtrlSpace;    break;
        case '0'                    : code = CoreKeyCodeCtrlKey0;     break;
        case '1'                    : code = CoreKeyCodeCtrlKey1;     break;
        case '2'                    : code = CoreKeyCodeCtrlKey2;     break;
        case '3'                    : code = CoreKeyCodeCtrlKey3;     break;
        case '4'                    : code = CoreKeyCodeCtrlKey4;     break;
        case '5'                    : code = CoreKeyCodeCtrlKey5;     break;
        case '6'                    : code = CoreKeyCodeCtrlKey6;     break;
        case '7'                    : code = CoreKeyCodeCtrlKey7;     break;
        case '8'                    : code = CoreKeyCodeCtrlKey8;     break;
        case '9'                    : code = CoreKeyCodeCtrlKey9;     break;
        case EW_BSP_KEY_CODE_NUMPAD0: code = CoreKeyCodeCtrlKey0;     break;
        case EW_BSP_KEY_CODE_NUMPAD1: code = CoreKeyCodeCtrlKey1;     break;
        case EW_BSP_KEY_CODE_NUMPAD2: code = CoreKeyCodeCtrlKey2;     break;
        case EW_BSP_KEY_CODE_NUMPAD3: code = CoreKeyCodeCtrlKey3;     break;
        case EW_BSP_KEY_CODE_NUMPAD4: code = CoreKeyCodeCtrlKey4;     break;
        case EW_BSP_KEY_CODE_NUMPAD5: code = CoreKeyCodeCtrlKey5;     break;
        case EW_BSP_KEY_CODE_NUMPAD6: code = CoreKeyCodeCtrlKey6;     break;
        case EW_BSP_KEY_CODE_NUMPAD7: code = CoreKeyCodeCtrlKey7;     break;
        case EW_BSP_KEY_CODE_NUMPAD8: code = CoreKeyCodeCtrlKey8;     break;
        case EW_BSP_KEY_CODE_NUMPAD9: code = CoreKeyCodeCtrlKey9;     break;
        case 'A'                    : code = CoreKeyCodeCtrlKeyA;     break;
        case 'B'                    : code = CoreKeyCodeCtrlKeyB;     break;
        case 'C'                    : code = CoreKeyCodeCtrlKeyC;     break;
        case 'D'                    : code = CoreKeyCodeCtrlKeyD;     break;
        case 'E'                    : code = CoreKeyCodeCtrlKeyE;     break;
        case 'F'                    : code = CoreKeyCodeCtrlKeyF;     break;
        case 'G'                    : code = CoreKeyCodeCtrlKeyG;     break;
        case 'H'                    : code = CoreKeyCodeCtrlKeyH;     break;
        case 'I'                    : code = CoreKeyCodeCtrlKeyI;     break;
        case 'J'                    : code = CoreKeyCodeCtrlKeyJ;     break;
        case 'K'                    : code = CoreKeyCodeCtrlKeyK;     break;
        case 'L'                    : code = CoreKeyCodeCtrlKeyL;     break;
        case 'M'                    : code = CoreKeyCodeCtrlKeyM;     break;
        case 'N'                    : code = CoreKeyCodeCtrlKeyN;     break;
        case 'O'                    : code = CoreKeyCodeCtrlKeyO;     break;
        case 'P'                    : code = CoreKeyCodeCtrlKeyP;     break;
        case 'Q'                    : code = CoreKeyCodeCtrlKeyQ;     break;
        case 'R'                    : code = CoreKeyCodeCtrlKeyR;     break;
        case 'S'                    : code = CoreKeyCodeCtrlKeyS;     break;
        case 'T'                    : code = CoreKeyCodeCtrlKeyT;     break;
        case 'U'                    : code = CoreKeyCodeCtrlKeyU;     break;
        case 'V'                    : code = CoreKeyCodeCtrlKeyV;     break;
        case 'W'                    : code = CoreKeyCodeCtrlKeyW;     break;
        case 'X'                    : code = CoreKeyCodeCtrlKeyX;     break;
        case 'Y'                    : code = CoreKeyCodeCtrlKeyY;     break;
        case 'Z'                    : code = CoreKeyCodeCtrlKeyZ;     break;
      }
      break;

      case EW_BSP_KEY_STATE_ALT:
      switch ( aKeyboardEvent.Data )
      {
        case EW_BSP_KEY_CODE_RETURN : code = CoreKeyCodeAltEnter;    break;
        case EW_BSP_KEY_CODE_ESCAPE : code = CoreKeyCodeAltEscape;   break;
        case EW_BSP_KEY_CODE_BACK   : code = CoreKeyCodeAltBackspace;break;
        case EW_BSP_KEY_CODE_TAB    : code = CoreKeyCodeAltTab;      break;
        case EW_BSP_KEY_CODE_DOWN   : code = CoreKeyCodeAltDown;     break;
        case EW_BSP_KEY_CODE_UP     : code = CoreKeyCodeAltUp;       break;
        case EW_BSP_KEY_CODE_LEFT   : code = CoreKeyCodeAltLeft;     break;
        case EW_BSP_KEY_CODE_RIGHT  : code = CoreKeyCodeAltRight;    break;
        case EW_BSP_KEY_CODE_HOME   : code = CoreKeyCodeAltHome;     break;
        case EW_BSP_KEY_CODE_END    : code = CoreKeyCodeAltEnd;      break;
        case EW_BSP_KEY_CODE_PRIOR  : code = CoreKeyCodeAltPageUp;   break;
        case EW_BSP_KEY_CODE_NEXT   : code = CoreKeyCodeAltPageDown; break;
        case EW_BSP_KEY_CODE_INSERT : code = CoreKeyCodeAltInsert;   break;
        case EW_BSP_KEY_CODE_DELETE : code = CoreKeyCodeAltDelete;   break;
        case EW_BSP_KEY_CODE_F1     : code = CoreKeyCodeAltF1;       break;
        case EW_BSP_KEY_CODE_F2     : code = CoreKeyCodeAltF2;       break;
        case EW_BSP_KEY_CODE_F3     : code = CoreKeyCodeAltF3;       break;
        case EW_BSP_KEY_CODE_F4     : code = CoreKeyCodeAltF4;       break;
        case EW_BSP_KEY_CODE_F5     : code = CoreKeyCodeAltF5;       break;
        case EW_BSP_KEY_CODE_F6     : code = CoreKeyCodeAltF6;       break;
        case EW_BSP_KEY_CODE_F7     : code = CoreKeyCodeAltF7;       break;
        case EW_BSP_KEY_CODE_F8     : code = CoreKeyCodeAltF8;       break;
        case EW_BSP_KEY_CODE_F9     : code = CoreKeyCodeAltF9;       break;
        case EW_BSP_KEY_CODE_F10    : code = CoreKeyCodeAltF10;      break;
      }
      break;

      case EW_BSP_KEY_STATE_CTRL | EW_BSP_KEY_STATE_SHIFT:
      switch ( aKeyboardEvent.Data )
      {
        case EW_BSP_KEY_CODE_RETURN : code = CoreKeyCodeCtrlShiftEnter;    break;
        case EW_BSP_KEY_CODE_ESCAPE : code = CoreKeyCodeCtrlShiftEscape;   break;
        case EW_BSP_KEY_CODE_BACK   : code = CoreKeyCodeCtrlShiftBackspace;break;
        case EW_BSP_KEY_CODE_TAB    : code = CoreKeyCodeCtrlShiftTab;      break;
        case EW_BSP_KEY_CODE_DOWN   : code = CoreKeyCodeCtrlShiftDown;     break;
        case EW_BSP_KEY_CODE_UP     : code = CoreKeyCodeCtrlShiftUp;       break;
        case EW_BSP_KEY_CODE_LEFT   : code = CoreKeyCodeCtrlShiftLeft;     break;
        case EW_BSP_KEY_CODE_RIGHT  : code = CoreKeyCodeCtrlShiftRight;    break;
        case EW_BSP_KEY_CODE_HOME   : code = CoreKeyCodeCtrlShiftHome;     break;
        case EW_BSP_KEY_CODE_END    : code = CoreKeyCodeCtrlShiftEnd;      break;
        case EW_BSP_KEY_CODE_PRIOR  : code = CoreKeyCodeCtrlShiftPageUp;   break;
        case EW_BSP_KEY_CODE_NEXT   : code = CoreKeyCodeCtrlShiftPageDown; break;
        case EW_BSP_KEY_CODE_INSERT : code = CoreKeyCodeCtrlShiftInsert;   break;
        case EW_BSP_KEY_CODE_DELETE : code = CoreKeyCodeCtrlShiftDelete;   break;
        case EW_BSP_KEY_CODE_F1     : code = CoreKeyCodeCtrlShiftF1;       break;
        case EW_BSP_KEY_CODE_F2     : code = CoreKeyCodeCtrlShiftF2;       break;
        case EW_BSP_KEY_CODE_F3     : code = CoreKeyCodeCtrlShiftF3;       break;
        case EW_BSP_KEY_CODE_F4     : code = CoreKeyCodeCtrlShiftF4;       break;
        case EW_BSP_KEY_CODE_F5     : code = CoreKeyCodeCtrlShiftF5;       break;
        case EW_BSP_KEY_CODE_F6     : code = CoreKeyCodeCtrlShiftF6;       break;
        case EW_BSP_KEY_CODE_F7     : code = CoreKeyCodeCtrlShiftF7;       break;
        case EW_BSP_KEY_CODE_F8     : code = CoreKeyCodeCtrlShiftF8;       break;
        case EW_BSP_KEY_CODE_F9     : code = CoreKeyCodeCtrlShiftF9;       break;
        case EW_BSP_KEY_CODE_F10    : code = CoreKeyCodeCtrlShiftF10;      break;
        case ' '                    : code = CoreKeyCodeCtrlShiftSpace;    break;
        case '0'                    : code = CoreKeyCodeCtrlShiftKey0;     break;
        case '1'                    : code = CoreKeyCodeCtrlShiftKey1;     break;
        case '2'                    : code = CoreKeyCodeCtrlShiftKey2;     break;
        case '3'                    : code = CoreKeyCodeCtrlShiftKey3;     break;
        case '4'                    : code = CoreKeyCodeCtrlShiftKey4;     break;
        case '5'                    : code = CoreKeyCodeCtrlShiftKey5;     break;
        case '6'                    : code = CoreKeyCodeCtrlShiftKey6;     break;
        case '7'                    : code = CoreKeyCodeCtrlShiftKey7;     break;
        case '8'                    : code = CoreKeyCodeCtrlShiftKey8;     break;
        case '9'                    : code = CoreKeyCodeCtrlShiftKey9;     break;
        case EW_BSP_KEY_CODE_NUMPAD0: code = CoreKeyCodeCtrlShiftKey0;     break;
        case EW_BSP_KEY_CODE_NUMPAD1: code = CoreKeyCodeCtrlShiftKey1;     break;
        case EW_BSP_KEY_CODE_NUMPAD2: code = CoreKeyCodeCtrlShiftKey2;     break;
        case EW_BSP_KEY_CODE_NUMPAD3: code = CoreKeyCodeCtrlShiftKey3;     break;
        case EW_BSP_KEY_CODE_NUMPAD4: code = CoreKeyCodeCtrlShiftKey4;     break;
        case EW_BSP_KEY_CODE_NUMPAD5: code = CoreKeyCodeCtrlShiftKey5;     break;
        case EW_BSP_KEY_CODE_NUMPAD6: code = CoreKeyCodeCtrlShiftKey6;     break;
        case EW_BSP_KEY_CODE_NUMPAD7: code = CoreKeyCodeCtrlShiftKey7;     break;
        case EW_BSP_KEY_CODE_NUMPAD8: code = CoreKeyCodeCtrlShiftKey8;     break;
        case EW_BSP_KEY_CODE_NUMPAD9: code = CoreKeyCodeCtrlShiftKey9;     break;
        case 'A'                    : code = CoreKeyCodeCtrlShiftKeyA;     break;
        case 'B'                    : code = CoreKeyCodeCtrlShiftKeyB;     break;
        case 'C'                    : code = CoreKeyCodeCtrlShiftKeyC;     break;
        case 'D'                    : code = CoreKeyCodeCtrlShiftKeyD;     break;
        case 'E'                    : code = CoreKeyCodeCtrlShiftKeyE;     break;
        case 'F'                    : code = CoreKeyCodeCtrlShiftKeyF;     break;
        case 'G'                    : code = CoreKeyCodeCtrlShiftKeyG;     break;
        case 'H'                    : code = CoreKeyCodeCtrlShiftKeyH;     break;
        case 'I'                    : code = CoreKeyCodeCtrlShiftKeyI;     break;
        case 'J'                    : code = CoreKeyCodeCtrlShiftKeyJ;     break;
        case 'K'                    : code = CoreKeyCodeCtrlShiftKeyK;     break;
        case 'L'                    : code = CoreKeyCodeCtrlShiftKeyL;     break;
        case 'M'                    : code = CoreKeyCodeCtrlShiftKeyM;     break;
        case 'N'                    : code = CoreKeyCodeCtrlShiftKeyN;     break;
        case 'O'                    : code = CoreKeyCodeCtrlShiftKeyO;     break;
        case 'P'                    : code = CoreKeyCodeCtrlShiftKeyP;     break;
        case 'Q'                    : code = CoreKeyCodeCtrlShiftKeyQ;     break;
        case 'R'                    : code = CoreKeyCodeCtrlShiftKeyR;     break;
        case 'S'                    : code = CoreKeyCodeCtrlShiftKeyS;     break;
        case 'T'                    : code = CoreKeyCodeCtrlShiftKeyT;     break;
        case 'U'                    : code = CoreKeyCodeCtrlShiftKeyU;     break;
        case 'V'                    : code = CoreKeyCodeCtrlShiftKeyV;     break;
        case 'W'                    : code = CoreKeyCodeCtrlShiftKeyW;     break;
        case 'X'                    : code = CoreKeyCodeCtrlShiftKeyX;     break;
        case 'Y'                    : code = CoreKeyCodeCtrlShiftKeyY;     break;
        case 'Z'                    : code = CoreKeyCodeCtrlShiftKeyZ;     break;
      }
      break;

      case EW_BSP_KEY_STATE_SHIFT | EW_BSP_KEY_STATE_ALT:
      switch ( aKeyboardEvent.Data )
      {
      }
      break;
    }

    /* finish an ongoing key cycle before a new key cycle is started */
    if ((( prevCode != CoreKeyCodeNoKey ) && ( prevCode != code )) || charCode )
    {
      CoreRoot__DriveKeyboardHitting( RootObject, prevCode, charCode, 0 );
      charCode = 0;
    }
  }

  if ( aKeyboardEvent.Type == EW_BSP_KEY_EVENT_CHAR )
  {
    /* finish an ongoing key cycle before a new key cycle is started */
    if ((( charCode != 0 ) && ( aKeyboardEvent.Data != charCode )) || ( code != CoreKeyCodeNoKey ))
    {
      CoreRoot__DriveKeyboardHitting( RootObject, code, charCode, 0 );
      code     = CoreKeyCodeNoKey;
    }
    charCode = aKeyboardEvent.Data;
  }

  if (( code == CoreKeyCodeNoKey ) && ( charCode == 0 ))
    return 0;

  if ( aKeyboardEvent.Type == EW_BSP_KEY_EVENT_UP )
  {
    updateNeeded = CoreRoot__DriveKeyboardHitting( RootObject, code, charCode, 0 );
    code     = CoreKeyCodeNoKey;
    charCode = 0;
    return updateNeeded;
  }

  /* Translate the universal key code to the older TV key code schema.
     This is important to be compatible with older versions. */
  tvCode = TranslateToTVKeyCode( code );

  /* At first try with the translated TV code. This is essential for older
      applications using the TV specific key code schema like CTRL+M is 'Menu'
      key */
  if (( tvCode != code ) && ( tvCode != CoreKeyCodeNoKey ) &&
    CoreRoot__DriveKeyboardHitting( RootObject, tvCode, 0, 1 ))
  {
    code = tvCode;
    updateNeeded = 1;
  }
  else
  {
    /* The application has not processed the TV specific code. Now feed the
      application with the universal key code */
    updateNeeded = CoreRoot__DriveKeyboardHitting( RootObject, code, charCode, 1 );
  }

  if ( ! updateNeeded  )
  {
    code     = CoreKeyCodeNoKey;
    charCode = 0;
  }
  return updateNeeded;
}


/*******************************************************************************
* FUNCTION:
*   EwPrintSystemInfo
*
* DESCRIPTION:
*   This function prints system and configuration information - very helpful in
*   case of any support issues.
*
* ARGUMENTS:
*   None
*
* RETURN VALUE:
*   None
*
*******************************************************************************/
void EwPrintSystemInfo( void )
{
  const XGraphicsEngineInfo*     gfxInfo;
  const XRuntimeEnvironmentInfo* rteInfo;

  /* get configuration of Graphics Engine and Runtime Environment */
  gfxInfo = EwGetGraphicsEngineInfo();
  rteInfo = EwGetRuntimeEnvironmentInfo();

  EwPrint( "---------------------------------------------\n" );
  EwPrint( "Embedded Wizard System Info                  \n" );
  EwPrint( "---------------------------------------------\n" );
  EwPrint( "Target system                                %s      \n", EW_PLATFORM_STRING );
  EwPrint( "Color format                                 %s      \n", EW_FRAME_BUFFER_COLOR_FORMAT_STRING );
  EwPrint( "Build Environment version                    %s      \n", EW_BUILD_ENV_VERSION );
  EwPrint( "Runtime Environment (RTE) version            V%u.%02u\n", rteInfo->Version >> 16, rteInfo->Version & 0xFF );
  EwPrint( "Graphics Engine (GFX) version                V%u.%02u\n", gfxInfo->Version >> 16, gfxInfo->Version & 0xFF );

  #if EW_MEMORY_POOL_SIZE > 0
  EwPrint( "MemoryPool address                           0x%08X  \n", EW_MEMORY_POOL_ADDR );
  EwPrint( "MemoryPool size                              %u bytes\n", EW_MEMORY_POOL_SIZE );
  #endif
  #if EW_EXTRA_POOL_SIZE > 0
  EwPrint( "ExtraPool address                            0x%08X  \n", EW_EXTRA_POOL_ADDR );
  EwPrint( "ExtraPool size                               %u bytes\n", EW_EXTRA_POOL_SIZE );
  #endif

  EwPrint( "Display size                                 %u x %u \n", DisplayInfo.DisplayWidth, DisplayInfo.DisplayHeight );
  EwPrint( "Viewport size                                %d x %d \n", DisplayInfo.ViewportWidth, DisplayInfo.ViewportHeight );
  EwPrint( "Surface rotation                             %u      \n", EW_SURFACE_ROTATION );
  EwPrint( "EwScreenSize                                 %d x %d \n", EwScreenSize.X, EwScreenSize.Y );

  EwPrint( "Graphics accelerator                         %s      \n", GRAPHICS_ACCELERATOR_STRING );
  EwPrint( "Warp function support                        %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportWarp ));
  EwPrint( "Vector graphics support                      %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportPaths ));
  EwPrint( "Gradients support                            %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportGradients ));
  EwPrint( "Blur support                                 %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportBlur ));
  EwPrint( "Mask support                                 %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportMask ));
  EwPrint( "Tint support                                 %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportTint ));
  EwPrint( "Bidirectional text support                   %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportBIDI ));
  EwPrint( "Compression support                          %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportCompression ));
  EwPrint( "Index8 bitmap resource support               %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportIndex8Surfaces ));
  EwPrint( "RGB565 bitmap resource support               %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportRGB565Surfaces ));
  EwPrint( "Native bitmap resource support               %s      \n", PRINT_ENABLED( gfxInfo->DoesSupportNativeSurfaces ));
  EwPrint( "Max surface cache size                       %u bytes\n", EwMaxSurfaceCacheSize );
  EwPrint( "Glyph cache size                             %u x %u \n", EwMaxGlyphSurfaceWidth, EwMaxGlyphSurfaceHeight );
  EwPrint( "Max issue tasks                              %u      \n", EwMaxIssueTasks );

  EwPrint( "Operating system                             %s      \n", EwBspOsGetName() );
  EwPrint( "Toolchain                                    %s      \n", TOOLCHAIN_STRING );
  #ifdef COMPILER_VERSION_STRING
  EwPrint( "C-Compiler version                           %s      \n", COMPILER_VERSION_STRING );
  #endif
  EwPrint( "Build date and time                          %s, %s  \n", __DATE__, __TIME__ );
  EwPrint( "---------------------------------------------\n" );
}


/* msy, mli */
